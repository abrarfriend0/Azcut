"""Auto PNG icon system for Az Cut Smart Explainer (v2.18).

Three-tier icon sourcing:
  1. User override: %LOCALAPPDATA%/AzCut/icons/<keyword>.png (his own PNGs)
  2. AI generate: Pollinations with claymorphism-optimized prompts, cached
  3. Emoji fallback: render a 3D-style emoji as PNG (always works)

The cache makes the library self-building: each keyword is generated once,
then reused instantly in later videos.
"""
import os
import re
import urllib.request
import urllib.parse

from PIL import Image, ImageDraw, ImageFont

# Cache dir (per-user, persists across updates)
_cache_base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
ICON_DIR = os.path.join(_cache_base, "AzCut", "icons")
os.makedirs(ICON_DIR, exist_ok=True)

# Claymorphism style prompt (matches his reference images)
STYLE_PROMPT = ("3d clay render icon of {kw}, soft claymorphism, pastel colors, "
                "cute stylized, smooth rounded shapes, soft studio lighting, "
                "isolated on pure white background, centered, minimal, "
                "high quality 3d icon")

# keyword -> emoji fallback map (common concepts)
EMOJI_MAP = {
    "brain": "🧠", "artificial": "🧠", "intelligence": "🧠",
    "computer": "💻", "laptop": "💻", "algorithm": "💻",
    "robot": "🤖", "machine": "🤖",
    "money": "💰", "cash": "💰", "payment": "💰", "economic": "💰",
    "house": "🏠", "home": "🏠",
    "car": "🚗", "factory": "🏭", "hospital": "🏥",
    "law": "⚖️", "legal": "⚖️", "court": "⚖️",
    "globe": "🌍", "world": "🌍", "global": "🌍", "map": "🗺️",
    "book": "📚", "document": "📄", "file": "📁",
    "phone": "📱", "mobile": "📱",
    "clock": "⏰", "time": "⏰",
    "idea": "💡", "light": "💡",
    "network": "🌐", "internet": "🌐", "web": "🌐",
    "data": "📊", "chart": "📊",
    "security": "🔒", "lock": "🔒",
    "tool": "🔨", "hammer": "🔨",
    "landscape": "🏔️", "mountain": "🏔️",
    "city": "🏙️", "civilization": "🏙️",
    "evolution": "🧬", "human": "🧑",
    "task": "📋", "workflow": "📋", "clipboard": "📋",
    "neural": "🧬", "deep": "🧠",
    "revolution": "🚀",
}


def _safe_kw(keyword):
    kw = re.sub(r"[^a-z0-9]+", "_", (keyword or "").lower()).strip("_")
    return kw[:40] or "icon"


def user_icon(keyword):
    """Tier 1: user's own PNG (AzCut/icons/<keyword>.png)."""
    p = os.path.join(ICON_DIR, _safe_kw(keyword) + ".png")
    return p if os.path.exists(p) else None


def cached_icon(keyword):
    """Check the auto-generated cache."""
    p = os.path.join(ICON_DIR, "auto_" + _safe_kw(keyword) + ".png")
    return p if os.path.exists(p) else None


def generate_icon(keyword, size=512):
    """Tier 2: AI-generate a claymorphism icon via Pollinations, then cache.
    v2.19.1: retry with longer waits (anonymous tier = 15s+ between requests)."""
    import time as _time
    import urllib.error as _urlerr
    kw = _safe_kw(keyword)
    out = os.path.join(ICON_DIR, "auto_" + kw + ".png")
    if os.path.exists(out):
        return out
    prompt = STYLE_PROMPT.format(kw=keyword)
    url = ("https://image.pollinations.ai/prompt/"
           + urllib.parse.quote(prompt)
           + f"?width={size}&height={size}&nologo=true&seed={abs(hash(kw)) % 999999}")
    for attempt in range(3):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "AzCut/2.19"})
            with urllib.request.urlopen(req, timeout=90) as r:
                data = r.read()
            if len(data) < 5000:
                return None
            with open(out, "wb") as f:
                f.write(data)
            # validate it's a real image
            Image.open(out).verify()
            return out
        except _urlerr.HTTPError as e:
            # 402 = rate limit: wait 20s before retry
            if e.code == 402 and attempt < 2:
                _time.sleep(20)
                continue
            break
        except Exception:
            if attempt < 2:
                _time.sleep(5)
                continue
            break
    try:
        if os.path.exists(out):
            os.remove(out)
    except Exception:
        pass
    return None


def emoji_icon(keyword, size=512):
    """Tier 3: render a 3D-style emoji as PNG (always works)."""
    kw = _safe_kw(keyword)
    out = os.path.join(ICON_DIR, "emoji_" + kw + ".png")
    if os.path.exists(out):
        return out
    emoji = None
    kl = (keyword or "").lower()
    for k, e in EMOJI_MAP.items():
        if k in kl:
            emoji = e
            break
    if not emoji:
        emoji = "✨"
    try:
        img = Image.new("RGBA", (size, size), (255, 255, 255, 0))
        d = ImageDraw.Draw(img)
        # try Segoe UI Emoji (Windows) then DejaVu
        font = None
        for fp in ["seguiemj.ttf",
                   "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]:
            try:
                font = ImageFont.truetype(fp, int(size * 0.72))
                break
            except Exception:
                continue
        if font is None:
            font = ImageFont.load_default()
        # center the emoji
        try:
            bbox = d.textbbox((0, 0), emoji, font=font)
            tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        except Exception:
            tw, th = size // 2, size // 2
        d.text(((size - tw) / 2, (size - th) / 2 - th * 0.08),
               emoji, font=font, fill=(255, 255, 255, 255),
               embedded_color=True)
        img.save(out)
        return out
    except Exception:
        return None


def get_icon(keyword):
    """v2.20: 2-tier resolution (Pollinations removed — quality issues).
    Returns a PNG path or None."""
    for fn in (user_icon, cached_icon):
        p = fn(keyword)
        if p:
            return p
    return emoji_icon(keyword)


def list_icons():
    """All available icons (user + auto + emoji) for the UI gallery."""
    out = []
    if not os.path.isdir(ICON_DIR):
        return out
    for f in sorted(os.listdir(ICON_DIR)):
        if f.endswith(".png"):
            out.append({"file": f,
                        "path": os.path.join(ICON_DIR, f),
                        "auto": f.startswith("auto_"),
                        "emoji": f.startswith("emoji_")})
    return out
