"""CapCut-style color filters for Az Cut (v2.17).

Converts the 100 CSS filter chains from the CapCut guide to ffmpeg
filter strings. Preview uses the original CSS (exact); render uses
the converted ffmpeg chain.
"""
import json
import os
import re

_HERE = os.path.dirname(os.path.abspath(__file__))
FILTERS_PATH = os.path.join(_HERE, "assets", "filters.json")

_SEPIA = ((0.393, 0.769, 0.189),
          (0.349, 0.686, 0.168),
          (0.272, 0.534, 0.131))


def css_to_ffmpeg(css):
    """Convert a CSS filter chain to an ffmpeg filter string."""
    if not css or css.strip() == "none":
        return ""
    fns = re.findall(r'([a-z-]+)\(([^)]*)\)', css)
    eq = {}
    ccm = None
    hue = None
    for name, arg in fns:
        arg = arg.strip()
        if name == "saturate":
            eq["saturation"] = float(arg)
        elif name == "contrast":
            eq["contrast"] = float(arg)
        elif name == "brightness":
            eq["brightness"] = float(arg) - 1.0
        elif name == "grayscale":
            g = float(arg)
            eq["saturation"] = eq.get("saturation", 1.0) * (1.0 - g)
        elif name == "sepia":
            x = max(0.0, min(1.0, float(arg)))
            if x > 0:
                m = [[(1 - x) * (1 if i == j else 0) + x * _SEPIA[i][j]
                      for j in range(3)] for i in range(3)]
                flat = [f"{v:.3f}" for row in m for v in row]
                ccm = "colorchannelmixer=" + ":".join(
                    f"{c}={v}" for c, v in zip(
                        ["rr", "rg", "rb", "gr", "gg", "gb", "br", "bg", "bb"],
                        flat))
        elif name == "hue-rotate":
            hue = float(arg.replace("deg", ""))
    parts = []
    if eq:
        parts.append("eq=" + ":".join(f"{k}={v:.3f}" for k, v in eq.items()))
    if ccm:
        parts.append(ccm)
    if hue:
        parts.append(f"hue=h={hue:.1f}")
    return ",".join(parts)


def list_filters():
    with open(FILTERS_PATH, encoding="utf-8") as f:
        return json.load(f)


def build_ffmpeg_map():
    """(Re)generate assets/filters_ffmpeg.json — run when filters.json changes."""
    out = {}
    for flt in list_filters():
        out[flt["name"]] = css_to_ffmpeg(flt["css"])
    with open(os.path.join(_HERE, "assets", "filters_ffmpeg.json"),
              "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1)
    return out


def ffmpeg_for(name):
    try:
        with open(os.path.join(_HERE, "assets", "filters_ffmpeg.json"),
                  encoding="utf-8") as f:
            return json.load(f).get(name, "")
    except Exception:
        return ""
