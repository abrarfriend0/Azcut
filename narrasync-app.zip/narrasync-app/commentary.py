"""Commentary Cut (v2.3) — clip + voiceover -> auto-synced commentary video.

Pipeline:
  1. Voiceover transcribe (word timestamps, faster-whisper).
  2. Silence removal: speech gaps auto-cut, word timings remapped.
  3. Video speed auto-fit: video ko slow/fast karke audio duration par lao.
  4. Scene-cut detection -> max 3-4 CapCut-style transitions (xfade).
  5. Script markers [o]/[a] -> red circle/arrow PNG overlay (difflib aligned).
  6. Har marker par camera-shutter / bottle-cap SFX.
  7. Fixed captions: white, black stroke, center, max 2 words/line, pop-up.

Stdlib + pipeline.py reuse (transcribe, SFX synth, ASS captions).
"""

import difflib
import os
import re
import subprocess

from pipeline import (
    transcribe, synthesize_sfx, _write_wav_mono, SFX_SR, build_ass_file,
    audio_duration,
)

TRANS_CHOICES = {
    "flash": "fadewhite",     # Flash
    "fade": "dissolve",       # Fade in/out
    "fadeblack": "fadeblack", # Fade to Black
    "pull_in": "slideleft",   # Pull In
    "pull_out": "slideright", # Pull Out
    "wipe": "wipeleft",       # Wipe
    "zoom": "distance",       # Zoom punch
    "blur": "hblur",          # Blur shutter
}
TRANS_LABELS = {
    "flash": "⚡ Flash", "fade": "🌅 Fade", "fadeblack": "⬛ Fade to Black",
    "pull_in": "➡ Pull In", "pull_out": "⬅ Pull Out", "wipe": "🧹 Wipe",
    "zoom": "🔍 Zoom", "blur": "💧 Blur Shutter",
}

MARKER_DUR = 1.5


class CommentaryError(Exception):
    pass


def _run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise CommentaryError(f"ffmpeg failed: {r.stderr[-400:]}")
    return r


def probe_duration(path):
    r = subprocess.run(["ffmpeg", "-i", path], capture_output=True, text=True)
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", r.stderr)
    if not m:
        return 0.0
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))


def video_dims(path):
    r = subprocess.run(
        ["ffmpeg", "-i", path], capture_output=True, text=True)
    m = re.search(r"Video:.*?, (\d+)x(\d+)", r.stderr)
    if m:
        return int(m.group(1)), int(m.group(2))
    return 1280, 720


def has_audio(path):
    r = subprocess.run(["ffmpeg", "-i", path], capture_output=True, text=True)
    return "Audio:" in r.stderr


# ----------------------------------------------------------------------------
# 1-2. Silence removal (word gaps -> cut, timings remapped)
# ----------------------------------------------------------------------------

def remove_silences(audio_path, words, out_path, min_gap=0.7, pad=0.12):
    """Cut speech gaps; return (out_path, new_words with remapped times)."""
    if not words:
        raise CommentaryError("No speech found in the voiceover.")
    segs = []
    for w in words:
        s = max(0.0, w["start"] - pad)
        e = w["end"] + pad
        if segs and s - segs[-1][1] < min_gap:
            segs[-1][1] = max(segs[-1][1], e)
        else:
            segs.append([s, e])

    def cut_before(t):
        c = 0.0
        prev_end = 0.0
        for s, e in segs:
            if t >= e:
                c += s - prev_end
            elif t > s:
                c += t - prev_end if t < s else 0.0
                break
            else:
                break
            prev_end = e
        return c

    # simpler exact map: removed = sum of gaps before t
    def removed_before(t):
        rem = 0.0
        prev = 0.0
        for s, e in segs:
            if s >= t:
                break
            rem += max(0.0, s - prev)
            prev = e
        return rem

    new_words = []
    for w in words:
        ns = w["start"] - removed_before(w["start"])
        ne = w["end"] - removed_before(w["end"])
        new_words.append({"word": w["word"], "start": max(0.0, ns),
                          "end": max(0.0, ne)})

    if len(segs) == 1:
        _run(["ffmpeg", "-y", "-v", "error", "-ss", f"{segs[0][0]:.2f}",
              "-t", f"{segs[0][1] - segs[0][0]:.2f}", "-i", audio_path,
              "-c:a", "aac", "-b:a", "128k", out_path])
    else:
        parts = []
        for i, (s, e) in enumerate(segs):
            p = out_path + f".p{i}.wav"
            _run(["ffmpeg", "-y", "-v", "error", "-ss", f"{s:.2f}",
                  "-t", f"{e - s:.2f}", "-i", audio_path, p])
            parts.append(p)
        lst = out_path + ".txt"
        with open(lst, "w") as f:
            for p in parts:
                f.write(f"file '{p}'\n")
        _run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0",
              "-i", lst, "-c:a", "aac", "-b:a", "128k", out_path])
        for p in parts + [lst]:
            try:
                os.remove(p)
            except OSError:
                pass
    return out_path, new_words


# ----------------------------------------------------------------------------
# 3. Video speed fit to audio duration
# ----------------------------------------------------------------------------

def fit_video_to_audio(video_path, audio_dur, out_path):
    """setpts video (and atempo factor for its audio) -> duration match.

    Returns (out_path, n) where n is the setpts factor.
    """
    vdur = probe_duration(video_path)
    if vdur <= 0 or audio_dur <= 0:
        raise CommentaryError("Could not get the duration.")
    n = audio_dur / vdur
    if not 0.5 <= n <= 2.0:
        raise CommentaryError(
            f"Speed {n:.2f}x had se bahar hai (0.5x-2x). "
            "Voiceover aur clip ki duration qareeb rakhein.")
    af = []
    if has_audio(video_path):
        atempo = 1.0 / n
        af = ["-filter:a", f"atempo={atempo:.4f}"]
    _run(["ffmpeg", "-y", "-v", "error", "-i", video_path,
          "-filter:v", f"setpts={n:.4f}*PTS", "-r", "30"] + af +
         ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
          "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart",
          "-shortest", out_path])
    return out_path, n


# ----------------------------------------------------------------------------
# 4. Scene-cut detection + xfade transitions
# ----------------------------------------------------------------------------

def detect_scene_cuts(video_path, max_n=4, threshold=0.35, min_gap=2.0):
    """Return up to max_n scene-change timestamps (seconds)."""
    r = subprocess.run(
        ["ffmpeg", "-v", "info", "-i", video_path,
         "-filter:v", f"select='gt(scene,{threshold})',showinfo",
         "-f", "null", "-"], capture_output=True, text=True)
    times = []
    for m in re.finditer(r"pts_time:([\d.]+)", r.stderr):
        t = float(m.group(1))
        if not times or t - times[-1] >= min_gap:
            times.append(t)
    dur = probe_duration(video_path)
    times = [t for t in times if 1.0 < t < dur - 1.0]
    return times[:max_n]


def apply_transitions(video_path, cuts, trans_keys, t_dur, out_path):
    """Split at cuts, xfade-chain with cycling transitions. Returns out.

    Also returns shift(t): original-time -> post-xfade time mapper.
    """
    if not cuts or not trans_keys:
        _run(["ffmpeg", "-y", "-v", "error", "-i", video_path,
              "-c", "copy", out_path])
        return out_path, lambda t: t
    dur = probe_duration(video_path)
    bounds = [0.0] + cuts + [dur]
    n = len(bounds) - 1
    seg_paths = []
    for i in range(n):
        # extend segments so xfades center on cuts (like studio)
        s = max(0.0, bounds[i] - (t_dur if i > 0 else 0))
        e = min(dur, bounds[i + 1] + (t_dur if i < n - 1 else 0))
        p = out_path + f".s{i}.mp4"
        _run(["ffmpeg", "-y", "-v", "error", "-ss", f"{s:.3f}",
              "-t", f"{e - s:.3f}", "-i", video_path,
              "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
              "-c:a", "aac", p])
        seg_paths.append(p)
    in_durs = [probe_duration(p) for p in seg_paths]
    filters = []
    for i, p in enumerate(seg_paths):
        filters.append(f"[{i}:v]setpts=PTS-STARTPTS,fps=30,format=yuv420p[v{i}]")
    cur = "[v0]"
    offset = in_durs[0] - t_dur
    for i in range(1, n):
        tr = TRANS_CHOICES[trans_keys[(i - 1) % len(trans_keys)]]
        out = f"[x{i}]"
        filters.append(f"{cur}[v{i}]xfade=transition={tr}:"
                       f"duration={t_dur:.3f}:offset={offset:.3f}{out}")
        cur = out
        offset += in_durs[i] - t_dur
    cmd = ["ffmpeg", "-y", "-v", "error"]
    for p in seg_paths:
        cmd += ["-i", p]
    cmd += ["-filter_complex", ";".join(filters),
            "-map", cur, "-c:v", "libx264", "-preset", "veryfast",
            "-crf", "20", "-movflags", "+faststart", out_path]
    _run(cmd)
    for p in seg_paths:
        try:
            os.remove(p)
        except OSError:
            pass

    def shift(t):
        return t - t_dur * sum(1 for c in cuts if c < t)
    return out_path, shift


# ----------------------------------------------------------------------------
# 5. Script markers [o]/[a] -> timestamps via difflib alignment
# ----------------------------------------------------------------------------

def _norm_w(w):
    return re.sub(r"[^a-z0-9\u0600-\u06ff]", "", w.lower())


def align_markers(script, words):
    """Return [(time, kind)] for [o] (circle) / [a] (arrow) markers."""
    if not script:
        return []
    tokens = []   # (word, marker_after or None)
    for tok in script.split():
        m = re.fullmatch(r"\[(o|a|!)\]", tok.strip().lower())
        if m:
            if tokens:
                tokens[-1] = (tokens[-1][0], m.group(1))
            continue
        tokens.append((tok, None))
    if not tokens:
        return []
    script_words = [_norm_w(t[0]) for t in tokens]
    trans_words = [_norm_w(w["word"]) for w in words]
    sm = difflib.SequenceMatcher(None, script_words, trans_words,
                                 autojunk=False)
    # map script idx -> trans idx via matching blocks
    mapping = {}
    for a, b, size in sm.get_matching_blocks():
        for k in range(size):
            mapping[a + k] = b + k
    markers = []
    for i, (tok, mark) in enumerate(tokens):
        if not mark:
            continue
        ti = mapping.get(i)
        if ti is None:
            # nearest mapped neighbour
            near = [mapping[j] for j in sorted(mapping)
                    if abs(j - i) <= 3]
            ti = near[0] if near else None
        if ti is None or ti >= len(words):
            continue
        kind = "circle" if mark in ("o", "!") else "arrow"
        markers.append((words[ti]["start"], kind))
    return sorted(markers)


def make_marker_png(kind, out_path, size=340):
    """Red circle ring / red arrow on transparent PNG (PIL)."""
    from PIL import Image, ImageDraw
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    dr = ImageDraw.Draw(img)
    red = (255, 45, 45, 255)
    if kind == "arrow":
        # bold down-arrow
        w = size
        dr.polygon([(w * 0.38, w * 0.08), (w * 0.62, w * 0.08),
                    (w * 0.62, w * 0.55), (w * 0.88, w * 0.55),
                    (w * 0.50, w * 0.92), (w * 0.12, w * 0.55),
                    (w * 0.38, w * 0.55)], fill=red,
                   outline=(0, 0, 0, 255), width=6)
    else:
        dr.ellipse([14, 14, size - 14, size - 14], outline=red, width=26)
    img.save(out_path)
    return out_path


def overlay_markers(video_path, markers, workdir, out_path,
                    marker_dur=MARKER_DUR):
    """Overlay marker PNGs centered, each for marker_dur seconds."""
    if not markers:
        _run(["ffmpeg", "-y", "-v", "error", "-i", video_path,
              "-c", "copy", out_path])
        return out_path
    W, H = video_dims(video_path)
    size = min(340, W // 3)
    pngs = {}
    for kind in {k for _, k in markers}:
        p = os.path.join(workdir, f"marker_{kind}.png")
        make_marker_png(kind, p, size=size)
        pngs[kind] = p
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", video_path]
    for _, kind in markers:
        cmd += ["-i", pngs[kind]]
    filters = []
    cur = "[0:v]"
    for i, (t, kind) in enumerate(markers):
        nxt = f"[m{i}]"
        x, y = "(main_w-overlay_w)/2", "(main_h-overlay_h)/2"
        filters.append(
            f"{cur}[{i + 1}:v]overlay=x={x}:y={y}:"
            f"enable='between(t,{t:.2f},{t + marker_dur:.2f})'{nxt}")
        cur = nxt
    cmd += ["-filter_complex", ";".join(filters),
            "-map", cur, "-map", "0:a?",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-c:a", "copy", "-movflags", "+faststart",
            "-shortest", out_path]
    _run(cmd)
    return out_path


# ----------------------------------------------------------------------------
# 6. Marker SFX track
# ----------------------------------------------------------------------------

def build_marker_sfx(times, total_dur, out_path, mode="alternate", gain=0.6):
    """Mix shutter/cap_open SFX at marker times. Returns wav path/None."""
    if not times:
        return None
    modes = {"shutter": ["shutter"], "cap": ["cap_open"],
             "alternate": ["shutter", "cap_open"]}[mode]
    total = int(total_dur * SFX_SR) + SFX_SR
    import numpy as np
    mix = np.zeros(total, dtype=np.float32)
    for i, t in enumerate(times):
        sfx = synthesize_sfx(modes[i % len(modes)])
        s = int(t * SFX_SR)
        e = min(total, s + len(sfx))
        mix[s:e] += sfx[:e - s] * gain
    _write_wav_mono(out_path, mix)
    return out_path


# ----------------------------------------------------------------------------
# 7. Fixed captions (white, black stroke, center, 2 wpl, pop)
# ----------------------------------------------------------------------------

def build_fixed_captions(words, W, H, out_ass):
    """CapCut-style fixed captions: white/black-stroke/center/2wpl/pop."""
    segs = []
    for i in range(0, len(words), 4):
        chunk = words[i:i + 4]
        segs.append((chunk[0]["start"], chunk[-1]["end"]))
    opts = {"preset": "pop", "font": "Montserrat", "bold": True, "size": 30,
            "color": "#FFFFFF", "hl": "#FFFFFF",
            "outline": 2, "outline_color": "#000000", "shadow": 1,
            "grid": "middle-center", "dx": 0, "dy": 70,
            "wpl": 2, "lines": 2, "karaoke": "word", "anim": "pop",
            "uppercase": False, "box": False}
    build_ass_file(words, segs, opts, W, H, out_ass)
    return out_ass


# ----------------------------------------------------------------------------
# Main build
# ----------------------------------------------------------------------------

def build_commentary(video_path, audio_path, out_path, script="",
                     marker_dur=MARKER_DUR, sfx_mode="alternate",
                     trans_keys=("flash", "fade", "pull_in", "blur"),
                     orig_gain=0.12, min_gap=0.7, captions_on=True,
                     progress_cb=None):
    """Full pipeline. Returns final mp4 path."""
    workdir = os.path.dirname(out_path)
    os.makedirs(workdir, exist_ok=True)

    def prog(m):
        if progress_cb:
            progress_cb(m)

    prog("Voiceover transcribe ho raha hai...")
    tr = transcribe(audio_path)
    words = tr["words"]
    if not words:
        raise CommentaryError("No speech found in the voiceover.")

    prog("Khamoshi (gaps) remove ho rahi hai...")
    clean_audio = os.path.join(workdir, "voice_clean.m4a")
    clean_audio, words = remove_silences(audio_path, words, clean_audio,
                                        min_gap=min_gap)
    audio_dur = audio_duration(clean_audio)

    prog("Video speed adjust ho rahi hai...")
    fitted = os.path.join(workdir, "fitted.mp4")
    fitted, _n = fit_video_to_audio(video_path, audio_dur, fitted)

    prog("Transitions lag rahe hain...")
    cuts = detect_scene_cuts(fitted, max_n=4)
    trans_keys = [k for k in (trans_keys or []) if k in TRANS_CHOICES][:4]
    transitioned = os.path.join(workdir, "trans.mp4")
    transitioned, shift = apply_transitions(fitted, cuts, trans_keys, 0.45,
                                            transitioned)
    words = [{"word": w["word"], "start": shift(w["start"]),
              "end": shift(w["end"])} for w in words]

    prog("Focus markers lag rahe hain...")
    markers = [(shift(t), k) for t, k in align_markers(script, words)]
    marked = os.path.join(workdir, "marked.mp4")
    overlay_markers(transitioned, markers, workdir, marked,
                    marker_dur=marker_dur)

    W, H = video_dims(marked)
    if captions_on:
        prog("Captions ban rahe hain...")
        ass = os.path.join(workdir, "caps.ass")
        build_fixed_captions(words, W, H, ass)
    else:
        ass = None

    prog("Audio mix ho raha hai...")
    final_dur = probe_duration(marked)
    sfx_wav = os.path.join(workdir, "sfx.wav")
    sfx_path = build_marker_sfx([t for t, _ in markers], final_dur, sfx_wav,
                                mode=sfx_mode)
    W, H = video_dims(marked)
    return _assemble(marked, clean_audio,
                     fitted if (has_audio(video_path) and orig_gain > 0)
                     else None,
                     sfx_path, ass, out_path, orig_gain)


def _assemble(marked, voice, fitted_with_audio, sfx_path, ass,
              out_path, orig_gain):
    """Final mux: subtitles burn-in + voiceover + orig audio + SFX.

    Sab kuch aik hi -filter_complex mein (vf+filter_complex ikathay
    ffmpeg mein masla karte hain). Subtitles path single quotes mein —
    yehi pattern caption tools mein kaam karta hai.
    """
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", marked, "-i", voice]
    filters = []
    if ass:
        esc = ass.replace("\\", "/").replace(":", "\\:")
        filters.append(f"[0:v]subtitles='{esc}'[vout]")
        vmap = "[vout]"
    else:
        vmap = "0:v"
    ains = ["[av]"]
    filters.append("[1:a]aresample=44100[av]")
    idx = 2
    if fitted_with_audio:
        cmd += ["-i", fitted_with_audio]
        filters.append(f"[{idx}:a]aresample=44100,volume={orig_gain}[ao]")
        ains.append("[ao]")
        idx += 1
    if sfx_path:
        cmd += ["-i", sfx_path]
        ains.append(f"[{idx}:a]")
        idx += 1
    if len(ains) > 1:
        filters.append(f"{''.join(ains)}amix=inputs={len(ains)}:"
                       "normalize=0[aout]")
        amap = "[aout]"
    else:
        amap = "[av]"
    cmd += ["-filter_complex", ";".join(filters),
            "-map", vmap, "-map", amap,
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-c:a", "aac", "-b:a", "160k",
            "-movflags", "+faststart", "-shortest", out_path]
    _run(cmd)
    return out_path
