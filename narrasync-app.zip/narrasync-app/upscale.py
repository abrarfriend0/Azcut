"""AI Upscale — Real-ESRGAN (ncnn-vulkan) se video/image ko bara aur
saaf karna (Full HD tak). Binary aur models zip halki rakhne ke
liye app ke sath NAHI aate — Upscale page par pehli dafa app khud
official release (~45 MB) download karke DATA/tools mein rakhta
hai; us ke baad hamesha wahi se chalta hai.

Video flow: frames nikalo (ffmpeg) -> har frame AI upscale ->
usi fps par dobara jodo (audio same) -> Turbo encoder se final.
Progress frames ki asal ginti par banta hai — andaza nahi.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

MODELS = {
    "quality": {"name": "realesrgan-x4plus", "scales": (4,),
                "label": "Quality — RealESRGAN x4plus (best detail, slower)"},
    "fast": {"name": "realesr-animevideov3", "scales": (2, 4),
             "label": "Fast — AnimeVideo v3 (made for video)"},
}


class UpscaleError(Exception):
    pass


class UpscaleCancelled(Exception):
    pass


# --- v2.56: AI engine ka pehli-dafa download ---
ENGINE_URL = ("https://github.com/xinntao/Real-ESRGAN/releases/"
              "download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-windows.zip")
ENGINE_FILES = [
    "realesrgan-ncnn-vulkan.exe",
    "vcomp140.dll",
    "models/realesrgan-x4plus.param",
    "models/realesrgan-x4plus.bin",
    "models/realesr-animevideov3-x2.param",
    "models/realesr-animevideov3-x2.bin",
    "models/realesr-animevideov3-x4.param",
    "models/realesr-animevideov3-x4.bin",
]

_DATA_TOOLS = None


def set_data_dir(data):
    """app.py apna DATA folder deta hai — engine wahan utrega."""
    global _DATA_TOOLS
    _DATA_TOOLS = os.path.join(data, "tools", "realesrgan")


def _download_file(url, tmp_path, progress=None):
    req = urllib.request.Request(url, headers={"User-Agent": "AzCut"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        total = int(resp.headers.get("Content-Length") or 0)
        done = 0
        with open(tmp_path, "wb") as fh:
            while True:
                chunk = resp.read(256 * 1024)
                if not chunk:
                    break
                fh.write(chunk)
                done += len(chunk)
                if progress:
                    progress(done / 1048576.0, total / 1048576.0)


def ensure_engine(progress=None):
    """Jo engine is PC par chal sakta hai woh download karo:
    Vulkan ho to ncnn (graphics card), warna ONNX compatibility
    model (processor par chalta hai). progress(done_mb, total_mb)."""
    if any_engine_ready():
        return True
    if vulkan_available():
        exe, models = find_tool()
        if exe:
            return True
        root = _DATA_TOOLS
        if not root:
            raise UpscaleError("Engine download location is not set.")
        os.makedirs(os.path.join(root, "models"), exist_ok=True)
        tmp = os.path.join(root, "_engine.zip.part")
        try:
            _download_file(ENGINE_URL, tmp, progress)
            with zipfile.ZipFile(tmp) as zf:
                names = set(zf.namelist())
                for want in ENGINE_FILES:
                    if want not in names:
                        raise UpscaleError(
                            f"Engine package is missing {want}.")
                    dst = os.path.join(root, *want.split("/"))
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    with open(dst, "wb") as fh:
                        fh.write(zf.read(want))
        except UpscaleError:
            raise
        except Exception as e:  # noqa: BLE001
            raise UpscaleError(
                "AI engine download failed. Check your internet "
                f"connection and try again. ({str(e)[:120]})")
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass
        if find_tool()[0] is None:
            raise UpscaleError("AI engine download finished but the "
                               "tool was not found afterwards.")
        return True
    # Vulkan nahi — ONNX compatibility model (32 MB nahi, fp32 64 MB:
    # processor par yehi tez aur mazboot chalta hai)
    d = _onnx_dir()
    if not d:
        raise UpscaleError("Engine download location is not set.")
    os.makedirs(d, exist_ok=True)
    tmp = os.path.join(d, "_model.part")
    try:
        _download_file(ONNX_URL, tmp, progress)
        os.replace(tmp, os.path.join(d, ONNX_NAME))
    except Exception as e:  # noqa: BLE001
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise UpscaleError(
            "Compatibility engine download failed. Check your "
            f"internet connection and try again. ({str(e)[:120]})")
    if onnx_model_path() is None:
        raise UpscaleError("Compatibility engine download finished "
                           "but the model was not found afterwards.")
    return True


# --- v2.57: ONNX compatibility engine (Vulkan na ho to) ---
ONNX_URL = ("https://huggingface.co/imgdesignart/realesrgan-x4-onnx/"
            "resolve/main/onnx/model.onnx")
ONNX_NAME = "realesrgan-x4plus.onnx"


def vulkan_available():
    """Windows par vulkan-1.dll (graphics driver ka hissa) hai ya
    nahi. Na ho to ncnn exe chal hi nahi sakta (Windows DLL error
    deta hai) — is liye pehle check karke ONNX rasta lo."""
    if os.environ.get("AZCUT_NO_VULKAN"):
        return False
    if os.name == "nt":
        sys32 = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"),
                             "System32", "vulkan-1.dll")
        return os.path.isfile(sys32)
    return True


def _onnx_dir():
    if not _DATA_TOOLS:
        return None
    return os.path.join(os.path.dirname(_DATA_TOOLS), "onnx")


def onnx_model_path():
    d = _onnx_dir()
    if not d:
        return None
    p = os.path.join(d, ONNX_NAME)
    return p if os.path.isfile(p) else None


def any_engine_ready():
    """Koi chalne wala engine tayyar hai? (ncnn sirf tab jab is PC
    par Vulkan bhi ho, warna ONNX model.)"""
    if find_tool()[0] is not None and vulkan_available():
        return True
    return onnx_model_path() is not None


_ONNX_SESS = None


def _onnx_session():
    global _ONNX_SESS
    if _ONNX_SESS is not None:
        return _ONNX_SESS
    import onnxruntime as ort
    path = onnx_model_path()
    if not path:
        raise UpscaleError("The compatibility engine is not "
                           "downloaded yet.")
    providers = []
    if "DmlExecutionProvider" in ort.get_available_providers():
        providers.append("DmlExecutionProvider")
    providers.append("CPUExecutionProvider")
    opts = ort.SessionOptions()
    opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    _ONNX_SESS = ort.InferenceSession(path, sess_options=opts,
                                      providers=providers)
    return _ONNX_SESS


def _onnx_upscale_rgb(arr):
    """uint8 RGB array -> 4x uint8 RGB. Model fixed 64x64 tiles
    mangta hai — 8px overlap ke sath weighted blending."""
    import numpy as np
    sess = _onnx_session()
    inp_name = sess.get_inputs()[0].name
    TILE, STEP, SCALE = 64, 56, 4
    h, w = arr.shape[:2]
    img = arr.astype(np.float32) / 255.0
    pad_h = max(0, TILE - h)
    pad_w = max(0, TILE - w)
    if pad_h or pad_w:
        img = np.pad(img, ((0, pad_h), (0, pad_w), (0, 0)),
                     mode="reflect")
    H, W = img.shape[:2]
    out = np.zeros((H * SCALE, W * SCALE, 3), dtype=np.float32)
    wsum = np.zeros((H * SCALE, W * SCALE, 1), dtype=np.float32)
    ov = TILE - STEP
    ramp = (np.arange(ov, dtype=np.float32) + 1) / (ov + 1)
    win1d = np.ones(TILE, dtype=np.float32)
    win1d[:ov] = ramp
    win1d[-ov:] = ramp[::-1]
    wout1d = np.repeat(win1d, SCALE)
    win_out = (wout1d[:, None] * wout1d[None, :])[:, :, None]
    ys = list(range(0, H - TILE + 1, STEP))
    if not ys or ys[-1] != H - TILE:
        ys.append(H - TILE)
    xs = list(range(0, W - TILE + 1, STEP))
    if not xs or xs[-1] != W - TILE:
        xs.append(W - TILE)
    for y in ys:
        for x in xs:
            patch = img[y:y + TILE, x:x + TILE].transpose(2, 0, 1)[None]
            res = sess.run(None, {inp_name: patch})[0]
            tile = res[0].transpose(1, 2, 0)
            oy, ox = y * SCALE, x * SCALE
            out[oy:oy + TILE * SCALE, ox:ox + TILE * SCALE] += tile * win_out
            wsum[oy:oy + TILE * SCALE, ox:ox + TILE * SCALE] += win_out
    res = out / np.maximum(wsum, 1e-6)
    res = res[:h * SCALE, :w * SCALE]
    return (np.clip(res, 0, 1) * 255).round().astype(np.uint8)


def _onnx_upscale_pil(img, want_scale):
    """PIL image -> upscale (4x model; 2x chahiye to pehle aadha
    karke 4x — natija theek 2x aur 4 guna tez)."""
    import numpy as np
    from PIL import Image
    src = img.convert("RGB")
    work = src
    if want_scale == 2:
        work = src.resize((max(1, src.width // 2),
                           max(1, src.height // 2)), Image.LANCZOS)
    out = Image.fromarray(_onnx_upscale_rgb(np.asarray(work)))
    want = (src.width * want_scale, src.height * want_scale)
    if out.size != want:
        out = out.resize(want, Image.LANCZOS)
    return out


def _upscale_image_onnx(in_path, out_path, want_scale):
    from PIL import Image
    with Image.open(in_path) as im:
        res = _onnx_upscale_pil(im, want_scale)
    if out_path.lower().endswith((".jpg", ".jpeg")):
        res.save(out_path, quality=92)
    else:
        res.save(out_path)
    return res.size


def _onnx_frames(fin, fout, want_scale, prog, cancel):
    from PIL import Image
    names = sorted(f for f in os.listdir(fin) if f.endswith(".png"))
    for i, name in enumerate(names):
        if cancel is not None and cancel.is_set():
            raise UpscaleCancelled()
        with Image.open(os.path.join(fin, name)) as im:
            res = _onnx_upscale_pil(im, want_scale)
        res.save(os.path.join(fout, name))
        prog(i + 1)


def normalize(model_key, scale):
    """Model ke hisab se scale theek karo (quality sirf 4x hai)."""
    if model_key not in MODELS:
        model_key = "fast"
    scales = MODELS[model_key]["scales"]
    if scale not in scales:
        scale = scales[0] if model_key == "quality" else 2
    return model_key, scale


def find_tool():
    """Bundled Real-ESRGAN binary dhoondo. (path, models_dir) ya (None, None)."""
    exe_name = ("realesrgan-ncnn-vulkan.exe" if os.name == "nt"
                else "realesrgan-ncnn-vulkan")
    candidates = []
    env = os.environ.get("AZCUT_REALESRGAN")
    if env:
        candidates.append(env)
    if _DATA_TOOLS:
        candidates.append(os.path.join(_DATA_TOOLS, exe_name))
    roots = []
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        roots.append(meipass)
    roots.append(os.path.dirname(os.path.abspath(__file__)))
    if getattr(sys, "frozen", False):
        roots.append(os.path.dirname(os.path.abspath(sys.executable)))
    for r in roots:
        candidates.append(os.path.join(r, "assets", "realesrgan", exe_name))
    found = shutil.which("realesrgan-ncnn-vulkan")
    if found:
        candidates.append(found)
    for c in candidates:
        if c and os.path.isfile(c):
            return c, os.path.join(os.path.dirname(os.path.abspath(c)), "models")
    return None, None


def _tool_or_raise():
    exe, models = find_tool()
    if not exe:
        raise UpscaleError(
            "The AI Upscale tool (Real-ESRGAN) was not found in this "
            "install. Please reinstall Az Cut.")
    return exe, models


def _run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def probe(path):
    """Video info: width/height/fps/duration/has_audio."""
    r = _run(["ffprobe", "-v", "error", "-show_streams", "-show_format",
              "-of", "json", path])
    if r.returncode != 0:
        raise UpscaleError("This file could not be read as a video.")
    info = json.loads(r.stdout or "{}")
    v = next((s for s in info.get("streams", [])
              if s.get("codec_type") == "video"), None)
    if not v:
        raise UpscaleError("No video stream found in this file.")
    fps = 30.0
    try:
        num, den = (v.get("avg_frame_rate") or "30/1").split("/")
        fps = float(num) / max(1.0, float(den))
    except Exception:  # noqa: BLE001
        pass
    dur = 0.0
    try:
        dur = float(info.get("format", {}).get("duration")
                    or v.get("duration") or 0)
    except Exception:  # noqa: BLE001
        pass
    return {"width": int(v.get("width") or 0),
            "height": int(v.get("height") or 0),
            "fps": fps, "duration": dur,
            "has_audio": any(s.get("codec_type") == "audio"
                             for s in info.get("streams", []))}


def _ncnn_cmd(exe, models, model_key, scale, src, dst):
    return [exe, "-i", src, "-o", dst, "-s", str(scale),
            "-m", models, "-n", MODELS[model_key]["name"], "-f", "png"]


def upscale_image(in_path, out_path, model_key="quality", scale=4):
    """Ek image upscale karo. (out_w, out_h) return karta hai.
    Vulkan ho to ncnn (GPU), warna ONNX compatibility engine."""
    model_key, scale = normalize(model_key, scale)
    exe, models = find_tool()
    if exe and vulkan_available():
        try:
            return _upscale_image_ncnn(exe, models, in_path, out_path,
                                       model_key, scale)
        except UpscaleError:
            if onnx_model_path() is None:
                raise
    if onnx_model_path() is not None:
        return _upscale_image_onnx(in_path, out_path, scale)
    if exe:
        raise UpscaleError(
            "Your PC has no Vulkan graphics support and the "
            "compatibility engine is not downloaded yet. Press "
            "Download AI Engine on this page first.")
    raise UpscaleError(
        "The AI Upscale engine is not downloaded yet. Press "
        "Download AI Engine on this page first.")


def _upscale_image_ncnn(exe, models, in_path, out_path, model_key, scale):
    cmd = _ncnn_cmd(exe, models, model_key, scale, in_path, out_path)
    if os.path.splitext(out_path)[1].lower() in (".jpg", ".jpeg"):
        cmd[-1] = "jpg"
    r = _run(cmd)
    if r.returncode != 0:
        # GPU/Vulkan fail par ek dafa CPU device par try
        r = _run(cmd + ["-g", "-1"])
    if r.returncode != 0 or not os.path.isfile(out_path):
        raise UpscaleError(
            "AI upscale failed on this image. Your graphics driver may "
            "need an update (the tool needs Vulkan).")
    from PIL import Image
    with Image.open(out_path) as im:
        return im.size


def _ncnn_folder(exe, models, model_key, scale, fin, fout, prog, cancel):
    """Folder ke saare frames upscale karo. Progress = bani hui files
    ki ginti. GPU fail (0 frames) par CPU (-g -1) retry."""
    base = _ncnn_cmd(exe, models, model_key, scale, fin, fout)
    for cmd in (base, base + ["-g", "-1"]):
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True)
        while proc.poll() is None:
            if cancel is not None and cancel.is_set():
                proc.terminate()
                raise UpscaleCancelled()
            prog(len([f for f in os.listdir(fout) if f.endswith(".png")]))
            time.sleep(1.0)
        done = len([f for f in os.listdir(fout) if f.endswith(".png")])
        prog(done)
        if proc.returncode == 0 and done > 0:
            return
        if done > 0:
            raise UpscaleError(
                "AI upscale stopped partway. Try the Fast model or a "
                "smaller scale.")
        # 0 frames bane aur fail — agla attempt (CPU) try hoga
    raise UpscaleError(
        "AI upscale could not start on this PC (graphics / Vulkan "
        "issue). Update your graphics driver and try again.")


def upscale_video(in_path, out_path, model_key="fast", scale=2,
                  fit_hd=True, progress=None, cancel=None):
    """Puri video upscale karo. progress(stage, done, total, note).
    Vulkan ho to ncnn (GPU), warna ONNX compatibility engine."""
    model_key, scale = normalize(model_key, scale)
    exe, models = find_tool()
    if exe and vulkan_available():
        try:
            return _upscale_video_impl(
                in_path, out_path, model_key, scale, fit_hd=fit_hd,
                progress=progress, cancel=cancel, engine="ncnn",
                exe=exe, models=models)
        except UpscaleError:
            if onnx_model_path() is None:
                raise
    if onnx_model_path() is not None:
        return _upscale_video_impl(
            in_path, out_path, model_key, scale, fit_hd=fit_hd,
            progress=progress, cancel=cancel, engine="onnx")
    if exe:
        raise UpscaleError(
            "Your PC has no Vulkan graphics support and the "
            "compatibility engine is not downloaded yet. Press "
            "Download AI Engine on this page first.")
    raise UpscaleError(
        "The AI Upscale engine is not downloaded yet. Press "
        "Download AI Engine on this page first.")


def _upscale_video_impl(in_path, out_path, model_key, scale,
                        fit_hd=True, progress=None, cancel=None,
                        engine="ncnn", exe=None, models=None):
    info = probe(in_path)
    fps = info["fps"] or 30.0
    workdir = tempfile.mkdtemp(prefix="azcut-upscale-")
    fin = os.path.join(workdir, "fin")
    fout = os.path.join(workdir, "fout")
    os.makedirs(fin)
    os.makedirs(fout)
    try:
        if progress:
            progress("extract", 0, 0, "Reading video frames…")
        r = _run(["ffmpeg", "-y", "-v", "error", "-i", in_path,
                  "-vf", f"fps={fps:.4f}", "-vsync", "cfr",
                  os.path.join(fin, "%06d.png")])
        if r.returncode != 0:
            raise UpscaleError("Frames could not be extracted from "
                               "this video.")
        total = len([f for f in os.listdir(fin) if f.endswith(".png")])
        if total == 0:
            raise UpscaleError("No frames were found in this video.")
        if cancel is not None and cancel.is_set():
            raise UpscaleCancelled()

        def _prog(done):
            if progress:
                progress("upscale", done, total,
                         f"AI upscaling frame {done} of {total}…")
        if engine == "ncnn":
            _ncnn_folder(exe, models, model_key, scale, fin, fout,
                         _prog, cancel)
        else:
            _onnx_frames(fin, fout, scale, _prog, cancel)
        if cancel is not None and cancel.is_set():
            raise UpscaleCancelled()
        if progress:
            progress("assemble", total, total, "Building the final video…")

        from pipeline import _enc_args
        cmd = ["ffmpeg", "-y", "-v", "error", "-framerate", f"{fps:.4f}",
               "-i", os.path.join(fout, "%06d.png")]
        if info["has_audio"]:
            cmd += ["-i", in_path]
        if fit_hd and info["height"] * scale > 1080:
            cmd += ["-vf", "scale=-2:1080"]
        cmd += ["-map", "0:v:0"]
        if info["has_audio"]:
            cmd += ["-map", "1:a:0"]
        cmd += _enc_args("turbo", "18") + ["-pix_fmt", "yuv420p"]
        if info["has_audio"]:
            cmd += ["-c:a", "aac", "-b:a", "160k", "-shortest"]
        cmd += [out_path]
        r = _run(cmd)
        if r.returncode != 0:
            raise UpscaleError("The final video could not be built.")
        out = probe(out_path)
        return {"width": out["width"], "height": out["height"],
                "frames": total}
    finally:
        shutil.rmtree(workdir, ignore_errors=True)
