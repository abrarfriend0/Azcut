"""AI Upscale — Real-ESRGAN (ncnn-vulkan) se video/image ko bara aur
saaf karna (Full HD tak). Binary aur models zip halki rakhne ke
liye app ke sath NAHI aate — Upscale page par pehli dafa app khud
official release (~45 MB) download karke DATA/tools mein rakhta
hai; us ke baad hamesha wahi se chalta hai.

Video flow: frames nikalo (ffmpeg) -> har frame AI upscale ->
usi fps par dobara jodo (audio same) -> Turbo encoder se final.
Progress frames ki asal ginti par banta hai — andaza nahi.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

MODELS = {
    "quality": {"name": "realesrgan-x4plus", "scales": (4,),
                "label": "Quality — RealESRGAN x4plus (best detail, slower)"},
    "fast": {"name": "realesr-animevideov3", "scales": (2, 4),
             "label": "Fast — AnimeVideo v3 (made for video)"},
}


class UpscaleError(Exception):
    pass


class UpscaleCancelled(Exception):
    pass


# --- v2.56: AI engine ka pehli-dafa download ---
ENGINE_URL = ("https://github.com/xinntao/Real-ESRGAN/releases/"
              "download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-windows.zip")
ENGINE_FILES = [
    "realesrgan-ncnn-vulkan.exe",
    "vcomp140.dll",
    "models/realesrgan-x4plus.param",
    "models/realesrgan-x4plus.bin",
    "models/realesr-animevideov3-x2.param",
    "models/realesr-animevideov3-x2.bin",
    "models/realesr-animevideov3-x4.param",
    "models/realesr-animevideov3-x4.bin",
]

_DATA_TOOLS = None


def set_data_dir(data):
    """app.py apna DATA folder deta hai — engine wahan utrega."""
    global _DATA_TOOLS
    _DATA_TOOLS = os.path.join(data, "tools", "realesrgan")


def ensure_engine(progress=None):
    """Engine na ho to official release zip download karke sirf
    zaroori files DATA/tools/realesrgan mein rakho.
    progress(done_mb, total_mb). (exe, models_dir) return."""
    exe, models = find_tool()
    if exe:
        return exe, models
    root = _DATA_TOOLS
    if not root:
        raise UpscaleError("Engine download location is not set.")
    os.makedirs(os.path.join(root, "models"), exist_ok=True)
    tmp = os.path.join(root, "_engine.zip.part")
    try:
        req = urllib.request.Request(ENGINE_URL,
                                     headers={"User-Agent": "AzCut"})
        with urllib.request.urlopen(req, timeout=60) as resp:
            total = int(resp.headers.get("Content-Length") or 0)
            done = 0
            with open(tmp, "wb") as fh:
                while True:
                    chunk = resp.read(256 * 1024)
                    if not chunk:
                        break
                    fh.write(chunk)
                    done += len(chunk)
                    if progress:
                        progress(done / 1048576.0, total / 1048576.0)
        with zipfile.ZipFile(tmp) as zf:
            names = set(zf.namelist())
            for want in ENGINE_FILES:
                if want not in names:
                    raise UpscaleError(
                        f"Engine package is missing {want}.")
                dst = os.path.join(root, *want.split("/"))
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with open(dst, "wb") as fh:
                    fh.write(zf.read(want))
    except UpscaleError:
        raise
    except Exception as e:  # noqa: BLE001
        raise UpscaleError(
            "AI engine download failed. Check your internet "
            f"connection and try again. ({str(e)[:120]})")
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    exe, models = find_tool()
    if not exe:
        raise UpscaleError("AI engine download finished but the tool "
                           "was not found afterwards.")
    return exe, models


def normalize(model_key, scale):
    """Model ke hisab se scale theek karo (quality sirf 4x hai)."""
    if model_key not in MODELS:
        model_key = "fast"
    scales = MODELS[model_key]["scales"]
    if scale not in scales:
        scale = scales[0] if model_key == "quality" else 2
    return model_key, scale


def find_tool():
    """Bundled Real-ESRGAN binary dhoondo. (path, models_dir) ya (None, None)."""
    exe_name = ("realesrgan-ncnn-vulkan.exe" if os.name == "nt"
                else "realesrgan-ncnn-vulkan")
    candidates = []
    env = os.environ.get("AZCUT_REALESRGAN")
    if env:
        candidates.append(env)
    if _DATA_TOOLS:
        candidates.append(os.path.join(_DATA_TOOLS, exe_name))
    roots = []
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        roots.append(meipass)
    roots.append(os.path.dirname(os.path.abspath(__file__)))
    if getattr(sys, "frozen", False):
        roots.append(os.path.dirname(os.path.abspath(sys.executable)))
    for r in roots:
        candidates.append(os.path.join(r, "assets", "realesrgan", exe_name))
    found = shutil.which("realesrgan-ncnn-vulkan")
    if found:
        candidates.append(found)
    for c in candidates:
        if c and os.path.isfile(c):
            return c, os.path.join(os.path.dirname(os.path.abspath(c)), "models")
    return None, None


def _tool_or_raise():
    exe, models = find_tool()
    if not exe:
        raise UpscaleError(
            "The AI Upscale tool (Real-ESRGAN) was not found in this "
            "install. Please reinstall Az Cut.")
    return exe, models


def _run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def probe(path):
    """Video info: width/height/fps/duration/has_audio."""
    r = _run(["ffprobe", "-v", "error", "-show_streams", "-show_format",
              "-of", "json", path])
    if r.returncode != 0:
        raise UpscaleError("This file could not be read as a video.")
    info = json.loads(r.stdout or "{}")
    v = next((s for s in info.get("streams", [])
              if s.get("codec_type") == "video"), None)
    if not v:
        raise UpscaleError("No video stream found in this file.")
    fps = 30.0
    try:
        num, den = (v.get("avg_frame_rate") or "30/1").split("/")
        fps = float(num) / max(1.0, float(den))
    except Exception:  # noqa: BLE001
        pass
    dur = 0.0
    try:
        dur = float(info.get("format", {}).get("duration")
                    or v.get("duration") or 0)
    except Exception:  # noqa: BLE001
        pass
    return {"width": int(v.get("width") or 0),
            "height": int(v.get("height") or 0),
            "fps": fps, "duration": dur,
            "has_audio": any(s.get("codec_type") == "audio"
                             for s in info.get("streams", []))}


def _ncnn_cmd(exe, models, model_key, scale, src, dst):
    return [exe, "-i", src, "-o", dst, "-s", str(scale),
            "-m", models, "-n", MODELS[model_key]["name"], "-f", "png"]


def upscale_image(in_path, out_path, model_key="quality", scale=4):
    """Ek image upscale karo. (out_w, out_h) return karta hai."""
    exe, models = _tool_or_raise()
    model_key, scale = normalize(model_key, scale)
    cmd = _ncnn_cmd(exe, models, model_key, scale, in_path, out_path)
    if os.path.splitext(out_path)[1].lower() in (".jpg", ".jpeg"):
        cmd[-1] = "jpg"
    r = _run(cmd)
    if r.returncode != 0:
        # GPU/Vulkan fail par ek dafa CPU device par try
        r = _run(cmd + ["-g", "-1"])
    if r.returncode != 0 or not os.path.isfile(out_path):
        raise UpscaleError(
            "AI upscale failed on this image. Your graphics driver may "
            "need an update (the tool needs Vulkan).")
    from PIL import Image
    with Image.open(out_path) as im:
        return im.size


def _ncnn_folder(exe, models, model_key, scale, fin, fout, prog, cancel):
    """Folder ke saare frames upscale karo. Progress = bani hui files
    ki ginti. GPU fail (0 frames) par CPU (-g -1) retry."""
    base = _ncnn_cmd(exe, models, model_key, scale, fin, fout)
    for cmd in (base, base + ["-g", "-1"]):
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True)
        while proc.poll() is None:
            if cancel is not None and cancel.is_set():
                proc.terminate()
                raise UpscaleCancelled()
            prog(len([f for f in os.listdir(fout) if f.endswith(".png")]))
            time.sleep(1.0)
        done = len([f for f in os.listdir(fout) if f.endswith(".png")])
        prog(done)
        if proc.returncode == 0 and done > 0:
            return
        if done > 0:
            raise UpscaleError(
                "AI upscale stopped partway. Try the Fast model or a "
                "smaller scale.")
        # 0 frames bane aur fail — agla attempt (CPU) try hoga
    raise UpscaleError(
        "AI upscale could not start on this PC (graphics / Vulkan "
        "issue). Update your graphics driver and try again.")


def upscale_video(in_path, out_path, model_key="fast", scale=2,
                  fit_hd=True, progress=None, cancel=None):
    """Puri video upscale karo. progress(stage, done, total, note)."""
    exe, models = _tool_or_raise()
    model_key, scale = normalize(model_key, scale)
    info = probe(in_path)
    fps = info["fps"] or 30.0
    workdir = tempfile.mkdtemp(prefix="azcut-upscale-")
    fin = os.path.join(workdir, "fin")
    fout = os.path.join(workdir, "fout")
    os.makedirs(fin)
    os.makedirs(fout)
    try:
        if progress:
            progress("extract", 0, 0, "Reading video frames…")
        r = _run(["ffmpeg", "-y", "-v", "error", "-i", in_path,
                  "-vf", f"fps={fps:.4f}", "-vsync", "cfr",
                  os.path.join(fin, "%06d.png")])
        if r.returncode != 0:
            raise UpscaleError("Frames could not be extracted from "
                               "this video.")
        total = len([f for f in os.listdir(fin) if f.endswith(".png")])
        if total == 0:
            raise UpscaleError("No frames were found in this video.")
        if cancel is not None and cancel.is_set():
            raise UpscaleCancelled()

        def _prog(done):
            if progress:
                progress("upscale", done, total,
                         f"AI upscaling frame {done} of {total}…")
        _ncnn_folder(exe, models, model_key, scale, fin, fout, _prog,
                     cancel)
        if cancel is not None and cancel.is_set():
            raise UpscaleCancelled()
        if progress:
            progress("assemble", total, total, "Building the final video…")

        from pipeline import _enc_args
        cmd = ["ffmpeg", "-y", "-v", "error", "-framerate", f"{fps:.4f}",
               "-i", os.path.join(fout, "%06d.png")]
        if info["has_audio"]:
            cmd += ["-i", in_path]
        if fit_hd and info["height"] * scale > 1080:
            cmd += ["-vf", "scale=-2:1080"]
        cmd += ["-map", "0:v:0"]
        if info["has_audio"]:
            cmd += ["-map", "1:a:0"]
        cmd += _enc_args("turbo", "18") + ["-pix_fmt", "yuv420p"]
        if info["has_audio"]:
            cmd += ["-c:a", "aac", "-b:a", "160k", "-shortest"]
        cmd += [out_path]
        r = _run(cmd)
        if r.returncode != 0:
            raise UpscaleError("The final video could not be built.")
        out = probe(out_path)
        return {"width": out["width"], "height": out["height"],
                "frames": total}
    finally:
        shutil.rmtree(workdir, ignore_errors=True)
