"""Az Cut web app — narration-synced video builder.

Run:  python app.py   ->  http://127.0.0.1:5000
"""
import os
import json
import re
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import uuid

# v2.20: Windows par har subprocess (ffmpeg waghera) ke liye console window
# blink na ho — CREATE_NO_WINDOW lagao
if os.name == "nt":
    _orig_popen = subprocess.Popen

    def _hidden_popen(*args, **kwargs):
        kwargs.setdefault("creationflags", subprocess.CREATE_NO_WINDOW)
        return _orig_popen(*args, **kwargs)

    subprocess.Popen = _hidden_popen

from flask import Flask, jsonify, request, send_file
from werkzeug.utils import secure_filename  # noqa: F401  (kept for clarity)

from pipeline import (
    PIPELINE_VERSION, TRANSITIONS, MOTIONS, EFFECTS, CAPTION_STYLES, VIDEO_EXTS,
    SFX_KINDS, SFX_KINDS_ALL, valid_sfx_kind, CAPTION_PRESETS, TOP_PRESETS, CAPTION_FONTS, CAPTION_GRIDS,
    CAPTION_ANIMS, TRANSCRIBE_MODELS,
    CueError, audio_duration, build_video, burn_captions, draft_cues,
    locate_cues, make_auto_clips, make_title_card, parse_cue_times,
    parse_cues, parse_script_times, preview_caption_clip,
    preview_studio_clip, reframe_916, transcribe, words_to_srt,
    words_to_txt, words_to_vtt, words_to_stamped, EXPORT_FORMATS,
    prepend_intro,
)
from pipeline import TITLECARD_THEMES
from pipeline import split_scenes, extract_keywords, DOODLE_PROMPT_SUFFIX
from pexels import PexelsError, download as pexels_download, search as pexels_search
from pixabay import PixabayError, download as pixabay_download, search as pixabay_search
from imggen import (
    IMGGEN_ASPECTS, IMGGEN_MODELS, IMAGE_STYLES, FAL_MODELS,
    POLLINATION_MODELS, ImgGenError,
    bulk_generate, generate_image,
    parse_bulk_prompts,
)
from commentary import TRANS_CHOICES, TRANS_LABELS
import broll as broll_mod

ASPECTS = {
    "16:9": (1280, 720),
    "9:16": (720, 1280),
    "1:1": (1080, 1080),
    "4:5": (1080, 1350),
}
from updater import check_for_updates

FROZEN = getattr(sys, "frozen", False)
if FROZEN:
    # Running from PyInstaller bundle (installed under Program Files):
    # read-only resources live next to the exe, user data goes to LocalAppData.
    BASE = sys._MEIPASS
    _local = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    DATA = os.path.join(_local, "AzCut", "data")
else:
    BASE = os.path.dirname(os.path.abspath(__file__))
    DATA = os.path.join(BASE, "data")
STATIC_DIR = os.path.join(BASE, "static")
os.makedirs(DATA, exist_ok=True)

app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="")
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024 * 1024  # 1 GB

audios = {}  # audio_id -> {path, status, result?, error?}
jobs = {}    # job_id   -> {status, durations?, error?}
_caption_words = {}  # caption job_id -> {words, language, video_path} (for fast re-burn)


def _cap_cache_trim():
    while len(_caption_words) > 6:
        _caption_words.pop(next(iter(_caption_words)))

AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".ogg", ".flac", ".aac", ".wma", ".opus"}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp",
              ".mp4", ".mov", ".m4v", ".webm", ".mkv", ".avi"}


def _save_upload(f, exts):
    ext = os.path.splitext(f.filename or "")[1].lower()
    if ext not in exts:
        raise CueError(f"File type '{ext or '?'}' is not supported.")
    path = os.path.join(DATA, f"{uuid.uuid4().hex}{ext}")
    f.save(path)
    return path


def _quick_duration(path):
    """Audio duration in seconds via ffprobe — instant (<1s), no decode."""
    try:
        r = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", path],
            capture_output=True, text=True, timeout=15)
        d = float(r.stdout.strip())
        return d if d > 0 else 0.0
    except Exception:  # noqa: BLE001
        return 0.0


def _transcribe_bg(audio_id, groq_key=None):
    try:
        model = audios[audio_id].get("model")
        result = transcribe(audios[audio_id]["path"], model=model, groq_key=groq_key)
        audios[audio_id].update(status="ready", result=result)
    except Exception as e:  # noqa: BLE001
        audios[audio_id].update(status="error", error=str(e))


@app.route("/intro-splash")
def intro_splash():
    """v2.18: app launch splash screen — plays the AZ Studio intro."""
    return """<!DOCTYPE html><html><head><meta charset="utf-8">
<title>Az Cut</title>
<style>html,body{margin:0;padding:0;background:#0a0a0e;height:100%;overflow:hidden;cursor:pointer}
video{width:100vw;height:100vh;object-fit:contain}</style></head>
<body onclick="window.close()" title="Click to skip">
<video autoplay muted playsinline><source src="/intro-video.mp4" type="video/mp4"></video>
</body></html>"""


@app.route("/intro-video.mp4")
def intro_video():
    """v2.18: serve the silent intro mp4 for the splash screen."""
    from pipeline import INTRO_ASSET
    if not os.path.exists(INTRO_ASSET):
        return "Intro not found", 404
    return send_file(INTRO_ASSET, mimetype="video/mp4")


@app.route("/")
def index():
    return app.send_static_file("home.html")


@app.after_request
def _no_cache_html(resp):
    # v2.17.1: never let the webview cache HTML pages — after an update the
    # old cached UI (theme/tabs) would keep showing instead of the new one.
    ct = resp.headers.get("Content-Type", "")
    if "text/html" in ct:
        resp.headers["Cache-Control"] = \
            "no-store, no-cache, must-revalidate, max-age=0"
        resp.headers["Pragma"] = "no-cache"
    return resp


@app.route("/studio")
def studio():
    return app.send_static_file("studio.html")


@app.route("/workflow")
def workflow():
    """v2.21: Workflow Wizard — topic se final video tak step by step."""
    return app.send_static_file("workflow.html")


@app.route("/bulk-studio")
def bulk_studio():
    """v2.21: Bulk Image Studio — style+character reference, ZIP download."""
    return app.send_static_file("bulk-studio.html")


@app.route("/transcriber")
def page_transcriber():
    return app.send_static_file("transcriber.html")


@app.route("/captions")
def page_captions():
    return app.send_static_file("captions.html")


@app.route("/clipper")
def page_clipper():
    return app.send_static_file("clipper.html")


@app.route("/image-lab")
def page_image_lab():
    return app.send_static_file("image-lab.html")


@app.route("/doodle")
def page_doodle():
    return app.send_static_file("doodle.html")


@app.route("/brolls")
def page_brolls():
    return app.send_static_file("brolls.html")


@app.route("/rank")
def page_rank():
    return app.send_static_file("rank.html")


@app.route("/commentary")
def page_commentary():
    return app.send_static_file("commentary.html")


def _commentary_bg(job_id, video_path, audio_path, script, marker_dur,
                   sfx_mode, trans_keys, orig_on, captions_on, model):
    import commentary as comm
    try:
        workdir = os.path.join(DATA, f"comm_{job_id}")
        os.makedirs(workdir, exist_ok=True)
        jobs[job_id]["status"] = "building"

        def _prog(msg):
            jobs[job_id]["doing"] = msg

        out = os.path.join(workdir, "commentary.mp4")
        comm.build_commentary(
            video_path, audio_path, out, script=script,
            marker_dur=marker_dur, sfx_mode=sfx_mode,
            trans_keys=trans_keys, orig_gain=0.12 if orig_on else 0.0,
            captions_on=captions_on, model=model, progress_cb=_prog)
        jobs[job_id].update(status="done", file=out)
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=str(e))


@app.post("/api/commentary/build")
def api_commentary_build():
    vf = request.files.get("video")
    af = request.files.get("audio")
    if not vf or not vf.filename:
        return jsonify(error="Pehle video clip upload karein."), 400
    if not af or not af.filename:
        return jsonify(error="Phir voiceover audio upload karein."), 400
    try:
        video_path = _save_upload(vf, VIDEO_EXTS)
        audio_path = _save_upload(af, AUDIO_EXTS)
    except CueError as e:
        return jsonify(error=str(e)), 400
    script = request.form.get("script", "")
    try:
        marker_dur = max(0.5, min(3.0,
                                  float(request.form.get("marker_dur", 1.5))))
    except (ValueError, TypeError):
        marker_dur = 1.5
    sfx_mode = request.form.get("sfx_mode", "alternate")
    if sfx_mode not in ("shutter", "cap", "alternate",
                        "shutter_real", "cap_real", "alternate_real"):
        sfx_mode = "alternate"
    trans = [t for t in request.form.getlist("trans")
             if t in TRANS_CHOICES][:4]
    if not trans:
        trans = ["flash", "fade", "pull_in", "blur"]
    orig_on = request.form.get("orig_on", "1") == "1"
    captions_on = request.form.get("captions_on", "1") == "1"
    model = request.form.get("model") or None
    if model not in TRANSCRIBE_MODELS:
        model = None
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "commentary"}
    threading.Thread(
        target=_commentary_bg,
        args=(job_id, video_path, audio_path, script, marker_dur,
              sfx_mode, trans, orig_on, captions_on, model),
        daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/commentary/<job_id>")
def api_commentary_status(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Unknown job."), 404
    out = {"status": j["status"], "doing": j.get("doing", "")}
    if j["status"] == "error":
        out["error"] = j.get("error")
    return jsonify(out)


@app.get("/api/commentary/<job_id>/download")
def api_commentary_download(job_id):
    j = jobs.get(job_id)
    if not j or j.get("status") != "done" or not os.path.exists(j.get("file", "")):
        return jsonify(error="Video is not ready yet."), 404
    return send_file(j["file"], as_attachment=True,
                     download_name="azcut-commentary.mp4")


@app.get("/api/commentary/<job_id>/preview")
def api_commentary_preview(job_id):
    """Inline stream for the mini preview player (not a download)."""
    j = jobs.get(job_id)
    if not j or j.get("status") != "done" or not os.path.exists(j.get("file", "")):
        return jsonify(error="Video is not ready yet."), 404
    return send_file(j["file"], as_attachment=False,
                     download_name="azcut-commentary.mp4")


def _rank_bg(job_id, topic, title_prefix, title_keyword, n_clips, seconds,
             sources, pexels_key, pixabay_key, order, mood_extra=""):
    import rank as rankmod
    try:
        workdir = os.path.join(DATA, f"rank_{job_id}")
        os.makedirs(workdir, exist_ok=True)
        jobs[job_id]["status"] = "fetching"
        jobs[job_id]["doing"] = "Sab se engaging clips dhoondhe ja rahe hain..."
        clips = []

        def _warn(msg):
            jobs[job_id]["warn"] = (jobs[job_id].get("warn", "") + " " + msg).strip()

        def _dlprog(msg):
            jobs[job_id]["doing"] = msg

        if "pexels" in sources:
            try:
                jobs[job_id]["doing"] = "Pexels se clips download ho rahe hain..."
                clips += rankmod.fetch_pexels_clips(
                    pexels_key, f"{topic} {mood_extra}".strip(), n_clips,
                    workdir, progress_cb=_dlprog)
            except Exception as e:  # noqa: BLE001
                _warn(f"Pexels: {e}")
        if "pixabay" in sources and len(clips) < n_clips:
            try:
                jobs[job_id]["doing"] = "Pixabay se clips download ho rahe hain..."
                clips += rankmod.fetch_pixabay_clips(
                    pixabay_key, f"{topic} {mood_extra}".strip(),
                    n_clips - len(clips), workdir, progress_cb=_dlprog)
            except Exception as e:  # noqa: BLE001
                _warn(f"Pixabay: {e}")
        if "youtube" in sources and len(clips) < n_clips:
            try:
                jobs[job_id]["doing"] = "YouTube se clips download ho rahe hain..."
                clips += rankmod.fetch_youtube_clips(
                    topic, n_clips - len(clips), workdir,
                    query_extra=mood_extra, engaging=True,
                    progress_cb=_dlprog)
            except Exception as e:  # noqa: BLE001
                w = f"YouTube: {e}"
                jobs[job_id]["warn"] = (jobs[job_id].get("warn", "") + " " + w).strip()
        if len(clips) < 2:
            raise rankmod.RankError(
                "Clips nahi mil sake - topic badal kar ya source badal kar "
                "dobara try karein.")
        jobs[job_id]["status"] = "building"

        def _prog(msg):
            jobs[job_id]["doing"] = msg

        out = os.path.join(workdir, "ranking.mp4")
        rankmod.build_rank_video(
            clips, out, title_prefix=title_prefix,
            title_keyword=title_keyword, n_clips=n_clips,
            seconds_per_clip=seconds, order=order, progress_cb=_prog)
        jobs[job_id].update(status="done", file=out)
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=str(e))


@app.post("/api/rank/build")
def api_rank_build():
    data = request.get_json(force=True, silent=True) or {}
    topic = (data.get("topic") or "").strip()
    if not topic:
        return jsonify(error="Pehle topic likhein (masalan: pool fails)."), 400
    sources = data.get("sources") or []
    sources = [s for s in sources if s in ("pexels", "pixabay", "youtube")]
    if not sources:
        return jsonify(error="Kam az kam aik source chunein."), 400
    pexels_key = (data.get("pexels_key") or "").strip()
    pixabay_key = (data.get("pixabay_key") or "").strip()
    if "pexels" in sources and not pexels_key:
        return jsonify(error="Pexels key dalein ya koi aur source chunein."), 400
    if "pixabay" in sources and not pixabay_key:
        return jsonify(error="Pixabay key dalein ya koi aur source chunein."), 400
    try:
        n_clips = max(2, min(8, int(data.get("n_clips", 5))))
    except (ValueError, TypeError):
        n_clips = 5
    try:
        seconds = max(2, min(8, int(data.get("seconds", 4))))
    except (ValueError, TypeError):
        seconds = 4
    order = data.get("order", "asc")
    if order not in ("asc", "desc"):
        order = "asc"
    mood = data.get("mood", "any")
    mood_extra = {"funny": "funny",
                  "shocking": "shocking insane moments",
                  "viral": "viral trending"}.get(mood, "")
    title_prefix = (data.get("title_prefix") or "Ranking Best").strip()
    title_keyword = (data.get("title_keyword")
                     or topic.title()).strip()
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "rank"}
    threading.Thread(
        target=_rank_bg,
        args=(job_id, topic, title_prefix, title_keyword, n_clips, seconds,
              sources, pexels_key, pixabay_key, order, mood_extra),
        daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/rank/<job_id>")
def api_rank_status(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Unknown job."), 404
    out = {"status": j["status"], "doing": j.get("doing", "")}
    if j.get("warn"):
        out["warn"] = j["warn"]
    if j["status"] == "error":
        out["error"] = j.get("error")
    return jsonify(out)


@app.get("/api/rank/<job_id>/download")
def api_rank_download(job_id):
    j = jobs.get(job_id)
    if not j or j.get("status") != "done" or not os.path.exists(j.get("file", "")):
        return jsonify(error="Video is not ready yet."), 404
    return send_file(j["file"], as_attachment=True,
                     download_name="azcut-ranking-video.mp4")


@app.get("/api/rank/<job_id>/preview")
def api_rank_preview(job_id):
    """Inline stream for the mini preview player (not a download)."""
    j = jobs.get(job_id)
    if not j or j.get("status") != "done" or not os.path.exists(j.get("file", "")):
        return jsonify(error="Video is not ready yet."), 404
    return send_file(j["file"], as_attachment=False,
                     download_name="azcut-ranking-video.mp4")


# ----------------------------------------------------------------------------
# Clip Grabber: celebrity name / video link -> clean 1080p moment clips
# (no captions, no overlays)
# ----------------------------------------------------------------------------

@app.route("/clips")
def page_clips():
    return app.send_static_file("clips.html")


@app.post("/api/clipgrab/faceref")
def api_clipgrab_faceref():
    """Celebrity ki reference photo upload karo — chehra detect karke save."""
    import clipgrab as cg
    f = request.files.get("photo")
    if not f or not f.filename:
        return jsonify(error="Please select a photo."), 400
    ext = os.path.splitext(f.filename or "")[1].lower()
    if ext not in (".jpg", ".jpeg", ".png", ".webp", ".bmp"):
        return jsonify(error="Sirf image file (JPG/PNG)."), 400
    tmp = os.path.join(DATA, f"faceref_up_{uuid.uuid4().hex}{ext}")
    f.save(tmp)
    try:
        face = cg.extract_ref_face(tmp)
    finally:
        try:
            os.remove(tmp)
        except OSError:  # noqa: BLE001
            pass
    if face is None:
        return jsonify(error="No face found in the photo — please give a clear front-facing photo."), 400
    import cv2
    fid = uuid.uuid4().hex
    cv2.imwrite(os.path.join(DATA, f"faceref_{fid}.png"), face)
    return jsonify(faceref_id=fid)


def _clips_bg(job_id, mode, query, n_clips, seconds, ratio, faceref_id=None,
               extra_keywords=None, strict_identity=True):
    import clipgrab as cg
    import rank as rankmod
    try:
        workdir = os.path.join(DATA, f"clips_{job_id}")
        os.makedirs(workdir, exist_ok=True)
        recognizer = None
        if faceref_id:
            ref_path = os.path.join(DATA, f"faceref_{faceref_id}.png")
            if os.path.exists(ref_path):
                import cv2
                ref = cv2.imread(ref_path, cv2.IMREAD_GRAYSCALE)
                if ref is not None:
                    recognizer = cg.train_face_recognizer(ref)
                    jobs[job_id]["doing"] = "Chehra pehchan liya gaya..."
        jobs[job_id]["status"] = "fetching"
        jobs[job_id]["doing"] = "Videos dhoondi ja rahi hain..."
        if mode == "link":
            urls = [(query, 0)]
        else:
            urls = cg.search_videos(
                query, min(10, max(1, (n_clips + 2) // 3)), workdir,
                extra_keywords=extra_keywords)
        paths = []
        tag = 0
        for u, dur in urls:
            if len(paths) >= n_clips:
                break
            tag += 1
            jobs[job_id]["doing"] = (
                f"Video download ho rahi hai... ({len(paths)}/{n_clips} clips)")
            src = cg.download_1080(u, workdir, f"v{tag}")
            if not src:
                continue
            need = n_clips - len(paths)
            # v2.20: 20+ min videos se 20 clips, warna max 6
            if dur >= 1200:
                per_video = max(1, min(need, 20))
            else:
                per_video = max(1, min(need, 6))
            jobs[job_id]["doing"] = "Best moments dhoonde ja rahe hain..."
            try:
                cands = rankmod.find_moment_windows(src, seconds,
                                                    per_video * 3)
            except Exception:  # noqa: BLE001
                cands = [0.0]
            # v2.20: face handling — recognizer mile to STRICT identity
            # (sirf wahi person jahan dikhe); warna solo-chehra preference
            try:
                if recognizer is not None:
                    ranked = cg.rank_windows_by_identity(
                        src, cands, seconds, recognizer)
                    ranked.sort(key=lambda x: -x[1])
                    if strict_identity:
                        # sirf wahi windows jahan reference person dikha (score>=0.5)
                        good = [(s, sc) for s, sc in ranked if sc >= 0.5]
                        if good:
                            ranked = good
                        # agar koi match na mile to bhi best wale lo (empty se behtar)
                    starts = sorted(s for s, _ in ranked[:per_video])
                else:
                    ranked = cg.rank_windows_by_face(src, cands, seconds)
                    ranked.sort(key=lambda x: -x[1])
                    starts = sorted(s for s, _ in ranked[:per_video])
            except Exception:  # noqa: BLE001
                starts = cands[:per_video]
            for s in starts:
                if len(paths) >= n_clips:
                    break
                out = os.path.join(workdir, f"clip_{len(paths) + 1:02d}.mp4")
                try:
                    cg.cut_clean_clip(src, out, s, seconds, ratio,
                                      recognizer=recognizer)
                    paths.append(out)
                except Exception:  # noqa: BLE001
                    continue
            try:
                os.remove(src)  # disk bachao
            except OSError:  # noqa: BLE001
                pass
        if not paths:
            raise cg.ClipError(
                "Koi clip nahi ban saki - naam/link badal kar dobara try karo.")
        jobs[job_id]["status"] = "zipping"
        jobs[job_id]["doing"] = "ZIP ban raha hai..."
        zpath = os.path.join(workdir, "clips.zip")
        cg.make_zip(paths, zpath)
        jobs[job_id].update(status="done", files=paths, zip=zpath,
                            count=len(paths))
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=str(e))


@app.post("/api/clipgrab/build")
def api_clipgrab_build():
    import clipgrab as cg
    data = request.get_json(force=True, silent=True) or {}
    raw = (data.get("input") or "").strip()
    if not raw:
        return jsonify(
            error="Pehle celebrity ka naam ya video ka link likhein."), 400
    mode = "link" if cg.is_youtube_url(raw) else "name"
    try:
        n_clips = max(1, min(200, int(data.get("n_clips", 5))))
    except (ValueError, TypeError):
        n_clips = 5
    try:
        seconds = max(3, min(10, int(data.get("seconds", 6))))
    except (ValueError, TypeError):
        seconds = 6
    ratio = data.get("ratio", "16:9")
    if ratio not in ("16:9", "9:16", "1:1"):
        ratio = "16:9"
    faceref_id = (data.get("faceref_id") or "").strip() or None
    # v2.20: multiple keywords (comma-separated)
    extra_keywords = [k.strip() for k in (data.get("keywords") or "").split(",") if k.strip()][:5]
    strict_identity = data.get("strict_identity", True)
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "clips"}
    threading.Thread(
        target=_clips_bg,
        args=(job_id, mode, raw, n_clips, seconds, ratio, faceref_id,
              extra_keywords, strict_identity),
        daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/clipgrab/<job_id>")
def api_clipgrab_status(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Job not found."), 404
    out = {"status": j.get("status"), "doing": j.get("doing"),
           "count": j.get("count", 0)}
    if j.get("status") == "error":
        out["error"] = j.get("error")
    if j.get("status") == "done":
        out["clips"] = list(range(j.get("count", 0)))
    return jsonify(out)


@app.get("/api/clipgrab/<job_id>/preview/<int:i>")
def api_clipgrab_preview(job_id, i):
    j = jobs.get(job_id)
    files = (j or {}).get("files") or []
    if (not j or j.get("status") != "done" or not 0 <= i < len(files)
            or not os.path.exists(files[i])):
        return jsonify(error="Clip is not ready."), 404
    return send_file(files[i], as_attachment=False,
                     download_name=f"clip_{i + 1:02d}.mp4")


@app.get("/api/clipgrab/<job_id>/download/<int:i>")
def api_clipgrab_download(job_id, i):
    j = jobs.get(job_id)
    files = (j or {}).get("files") or []
    if (not j or j.get("status") != "done" or not 0 <= i < len(files)
            or not os.path.exists(files[i])):
        return jsonify(error="Clip is not ready."), 404
    return send_file(files[i], as_attachment=True,
                     download_name=f"clip_{i + 1:02d}.mp4")


@app.get("/api/clipgrab/<job_id>/download-all")
def api_clipgrab_download_all(job_id):
    j = jobs.get(job_id)
    z = (j or {}).get("zip")
    if not j or j.get("status") != "done" or not z or not os.path.exists(z):
        return jsonify(error="ZIP is not ready."), 404
    return send_file(z, as_attachment=True,
                     download_name="azcut-clips.zip")


# ----------------------------------------------------------------------------
# Voiceover Video: voiceover -> auto YouTube-clip video (Ken Burns + fades)
# ----------------------------------------------------------------------------

@app.post("/api/vv/analyze")
def api_vv_analyze():
    import voicevideo as vv
    data = request.get_json(force=True, silent=True) or {}
    a = audios.get(data.get("audio_id"))
    if not a:
        return jsonify(error="Audio not found."), 404
    if a["status"] == "transcribing":
        return jsonify(status="transcribing"), 202
    if a["status"] == "error":
        return jsonify(error=a.get("error") or "Transcription fail ho gayi."), 400
    try:
        words = [(w["word"], w["start"], w["end"])
                 for w in a["result"]["words"]]
        dur = a["result"].get("duration") or 0
        if not dur:
            import rank as rankmod
            dur = rankmod.probe_duration(a["path"])
        scenes = vv.split_scenes(words, dur)
    except Exception as e:  # noqa: BLE001
        return jsonify(error=str(e)), 400
    return jsonify(status="ready", duration=round(dur, 1),
                   transcription=a["result"].get("text", ""),
                   scenes=scenes)


def _vv_bg(job_id, audio_id, scenes, ratio):
    import voicevideo as vv
    try:
        a = audios.get(audio_id)
        if not a or a["status"] != "ready":
            raise vv.VVError("Audio is not ready.")
        workdir = os.path.join(DATA, f"vv_{job_id}")
        os.makedirs(workdir, exist_ok=True)
        jobs[job_id]["status"] = "building"

        def _prog(msg):
            jobs[job_id]["doing"] = msg

        out = vv.build_voiceover_video(a["path"], scenes, ratio, workdir,
                                       progress_cb=_prog)
        jobs[job_id].update(status="done", file=out,
                            transcription=a["result"].get("text", ""),
                            scenes=scenes)
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=str(e))


@app.post("/api/vv/build")
def api_vv_build():
    import voicevideo as vv
    data = request.get_json(force=True, silent=True) or {}
    audio_id = data.get("audio_id")
    a = audios.get(audio_id)
    if not a or a["status"] != "ready":
        return jsonify(error="Please upload and transcribe the voiceover first."), 400
    scenes = data.get("scenes") or []
    scenes = [s for s in scenes
              if isinstance(s, dict) and s.get("keyword")
              and float(s.get("end", 0)) > float(s.get("start", 0))]
    if not scenes:
        return jsonify(error="No scenes found."), 400
    if len(scenes) > 12:
        return jsonify(error="Zyada se zyada 12 scenes."), 400
    ratio = data.get("ratio", "16:9")
    if ratio not in ("16:9", "9:16", "1:1"):
        ratio = "16:9"
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "vv"}
    threading.Thread(target=_vv_bg,
                     args=(job_id, audio_id, scenes, ratio),
                     daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/vv/<job_id>")
def api_vv_status(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Job not found."), 404
    out = {"status": j.get("status"), "doing": j.get("doing")}
    if j.get("status") == "error":
        out["error"] = j.get("error")
    if j.get("status") == "done":
        out["transcription"] = j.get("transcription", "")
        out["scenes"] = j.get("scenes", [])
    return jsonify(out)


@app.get("/api/vv/<job_id>/preview")
def api_vv_preview(job_id):
    j = jobs.get(job_id)
    if not j or j.get("status") != "done" or not os.path.exists(j.get("file", "")):
        return jsonify(error="Video is not ready."), 404
    return send_file(j["file"], as_attachment=False,
                     download_name="azcut-voiceover-video.mp4")


@app.get("/api/vv/<job_id>/download")
def api_vv_download(job_id):
    j = jobs.get(job_id)
    if not j or j.get("status") != "done" or not os.path.exists(j.get("file", "")):
        return jsonify(error="Video is not ready."), 404
    return send_file(j["file"], as_attachment=True,
                     download_name="azcut-voiceover-video.mp4")


@app.get("/api/options")
def api_options():
    from capcut_sfx import list_sfx as _cc_list
    try:
        _cc = [{"id": "cc_" + i, "label": l, "cat": c} for i, l, c in _cc_list()]
    except Exception:
        _cc = []
    try:
        from capcut_filters import list_filters as _fl
        _filters = _fl()
    except Exception:
        _filters = []
    try:
        import json as _js
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "assets", "voices.json"), encoding="utf-8") as _vf:
            _voices = _js.load(_vf)
    except Exception:
        _voices = []
    return jsonify(
        transitions=TRANSITIONS, motions=MOTIONS, effects=EFFECTS,
        caption_styles=CAPTION_STYLES,
        caption_presets={k: v["label"] for k, v in CAPTION_PRESETS.items()},
        top_presets=TOP_PRESETS,
        preset_details={k: {kk: vv for kk, vv in v.items() if kk != "label"}
                        for k, v in CAPTION_PRESETS.items()},
        caption_fonts=CAPTION_FONTS, caption_grids=CAPTION_GRIDS,
        caption_anims=CAPTION_ANIMS,
        transcribe_models=TRANSCRIBE_MODELS,
        imggen_models=IMGGEN_MODELS, imggen_aspects=IMGGEN_ASPECTS,
        fal_models=FAL_MODELS, poll_models=POLLINATION_MODELS,
        commentary_trans=TRANS_LABELS,
        image_styles={k: v[0] for k, v in IMAGE_STYLES.items()},
        sfx_kinds=SFX_KINDS_ALL,
        capcut_sfx=_cc,
        color_filters=_filters,
        voices=_voices,
        titlecard_themes={k: v["label"] for k, v in TITLECARD_THEMES.items()},
        aspects={k: {"w": w, "h": h} for k, (w, h) in ASPECTS.items()})


@app.get("/api/sfx/preview/<sid>")
def api_sfx_preview(sid):
    """v2.17: render any SFX kind to WAV for the library preview player."""
    from pipeline import synthesize_sfx, _write_wav_mono, SFX_SR
    kind = (sid or "").strip()
    if not valid_sfx_kind(kind):
        return jsonify(error="Unknown sound."), 404
    try:
        buf = synthesize_sfx(kind)
    except Exception as e:  # noqa: BLE001
        return jsonify(error=str(e)), 500
    if buf is None:
        return jsonify(error="Could not render sound."), 500
    safe = re.sub(r"[^a-z0-9_]+", "_", kind.lower())[:32] or "sfx"
    path = os.path.join(DATA, f"sfxprev_{safe}.wav")
    _write_wav_mono(path, buf, SFX_SR)
    return send_file(path, mimetype="audio/wav")


@app.post("/api/titlecard")
def api_titlecard():
    """Render a kinetic-typography title card to MP4 (doodle-video style)."""
    text = request.form.get("text", "").strip()
    theme = request.form.get("theme", "black-yellow")
    if theme not in TITLECARD_THEMES:
        theme = "black-yellow"
    try:
        duration = max(1.0, min(30.0, float(request.form.get("duration", 5))))
    except (ValueError, TypeError):
        duration = 5.0
    try:
        width = int(request.form.get("width", 1280))
        height = int(request.form.get("height", 720))
    except (ValueError, TypeError):
        width, height = 1280, 720
    if not text:
        return jsonify(error="Please write the card text first."), 400
    out = os.path.join(DATA, f"card_{uuid.uuid4().hex}.mp4")
    try:
        make_title_card(text, out, duration=duration, width=width,
                        height=height, theme=theme)
    except (CueError, RuntimeError) as e:
        return jsonify(error=str(e)), 400
    return send_file(out, as_attachment=True, download_name="titlecard.mp4")


@app.get("/api/stock/search")
def api_stock_search():
    """Search Pexels stock photos/videos (free API key)."""
    key = request.args.get("key", "")
    q = request.args.get("q", "")
    kind = request.args.get("kind", "photo")
    if kind not in ("photo", "video"):
        kind = "photo"
    try:
        page = max(1, int(request.args.get("page", 1)))
    except (ValueError, TypeError):
        page = 1
    try:
        return jsonify(pexels_search(key, q, kind, page))
    except PexelsError as e:
        return jsonify(error=str(e)), 400


@app.post("/api/stock/fetch")
def api_stock_fetch():
    """Download one Pexels file to the server and return it."""
    url = request.form.get("url", "")
    name = request.form.get("name", "stock")
    kind = request.form.get("kind", "photo")
    ext = "mp4" if kind == "video" else "jpg"
    safe = re.sub(r"[^a-zA-Z0-9_-]+", "_", name)[:40] or "stock"
    out = os.path.join(DATA, f"stock_{uuid.uuid4().hex[:8]}_{safe}.{ext}")
    try:
        pexels_download(url, out)
    except PexelsError as e:
        return jsonify(error=str(e)), 400
    return send_file(out, as_attachment=True,
                     download_name=f"{safe}.{ext}")


# ---------------- Auto Doodle Video ----------------

@app.post("/api/doodle/plan")
def api_doodle_plan():
    """Split transcribed voiceover into scenes + keywords (fast, no visuals)."""
    audio_id = request.form.get("audio_id")
    a = audios.get(audio_id)
    if not a:
        return jsonify(error="Please upload a voiceover first."), 400
    if a["status"] != "ready":
        return jsonify(error="Please wait for transcription to finish."), 400
    try:
        n = max(2, min(30, int(request.form.get("scenes", 8))))
    except (ValueError, TypeError):
        n = 8
    scenes = split_scenes(a["result"]["words"], n)
    out = [{"i": i, "text": s["text"],
            "keywords": extract_keywords(s["text"]),
            "start": round(s["start"], 2), "end": round(s["end"], 2)}
           for i, s in enumerate(scenes)]
    return jsonify(scenes=out, duration=a["result"]["duration"])


def _doodle_fetch_visual(keyword, visual, pexels_key, pixabay_key, gemini_key,
                         aspect, tag, style=None):
    """Return (path, vsrc). Raises on hard failure (bad key / quota).

    style: IMAGE_STYLES id; its suffix replaces the default doodle suffix.
    Stock order: Pexels first (if key given), then Pixabay (if key given) —
    Pexels paused new API keys, so Pixabay is the working fallback.
    """
    if visual in ("stock", "mix"):
        got = False
        if pexels_key:
            try:
                r = pexels_search(pexels_key, keyword, "photo")
                if r["items"]:
                    p = os.path.join(DATA, f"doodle_{tag}.jpg")
                    pexels_download(r["items"][0]["url"], p)
                    return p, "stock"
            except PexelsError:
                pass
        if pixabay_key and not got:
            try:
                r = pixabay_search(pixabay_key, keyword, "photo")
                if r["items"]:
                    p = os.path.join(DATA, f"doodle_{tag}.jpg")
                    pixabay_download(r["items"][0]["url"], p)
                    return p, "stock"
            except PixabayError:
                pass
        if visual == "stock" and not got:
            raise PexelsError(
                "Stock photo nahi mil saki — Pexels/Pixabay key check karein.")
    if visual in ("doodle", "mix"):
        suffix = (IMAGE_STYLES[style][1] if style in IMAGE_STYLES
                  else DOODLE_PROMPT_SUFFIX)
        prompt = f"{keyword}, {suffix}"
        img = None
        if gemini_key:
            img = generate_image(gemini_key, prompt, aspect=aspect)
        if img is None:
            raise ImgGenError(
                "Gemini key chahiye — Dashboard mein Gemini key lagao, "
                "ya Image Lab mein Bulk Prompt Generator se Gemini (browser) use karo.")
        p = os.path.join(DATA, f"doodle_{tag}.png")
        with open(p, "wb") as f:
            f.write(img)
        return p, "doodle"
    return None, None


def _doodle_bg(job_id, scenes, visual, pexels_key, pixabay_key, gemini_key,
               aspect, style=None):
    try:
        jobs[job_id]["status"] = "building"
        out = []
        for sc in scenes:
            i = sc["i"]
            jobs[job_id]["doing"] = f"{i + 1}/{len(scenes)}"
            kws = sc.get("keywords") or []
            kw = kws[0] if kws else (sc.get("text") or "")[:40]
            path, vsrc, err = None, None, ""
            try:
                path, vsrc = _doodle_fetch_visual(
                    kw, visual, pexels_key, pixabay_key, gemini_key, aspect,
                    f"{job_id}_{i}", style=style)
            except (PexelsError, PixabayError, ImgGenError) as e:
                err = str(e)
                if i == 0:
                    raise  # bad key etc. — fail fast with a clear message
                if "(429)" in err or "quota" in err.lower():
                    out.append({"i": i, "keyword": kw, "path": None,
                                "vsrc": None, "start": sc["start"],
                                "end": sc["end"], "text": sc.get("text", ""),
                                "error": err})
                    break  # quota exhausted — stop gracefully
            out.append({"i": i, "keyword": kw, "path": path, "vsrc": vsrc,
                        "start": sc["start"], "end": sc["end"],
                        "text": sc.get("text", ""), "error": err})
        jobs[job_id].update(status="done", scenes=out)
    except Exception as e:  # noqa: BLE001
        _job_error(job_id, e)


@app.post("/api/doodle/storyboard")
def api_doodle_storyboard():
    """Background job: fetch one visual per scene. Returns job_id."""
    data = request.get_json(force=True, silent=True) or {}
    scenes = data.get("scenes") or []
    visual = data.get("visual", "mix")
    if visual not in ("stock", "doodle", "mix"):
        visual = "mix"
    if not scenes:
        return jsonify(error="No scenes to build."), 400
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "doodle"}
    threading.Thread(
        target=_doodle_bg,
        args=(job_id, scenes, visual, data.get("pexels_key", ""),
              data.get("pixabay_key", ""),
              data.get("gemini_key", ""), data.get("aspect", "16:9"),
              data.get("img_style")),
        daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/doodle/<job_id>")
def api_doodle_status(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Unknown job."), 404
    out = {"status": j["status"], "doing": j.get("doing", "")}
    if j["status"] == "done":
        out["scenes"] = [{k: v for k, v in s.items() if k != "path"}
                         for s in j.get("scenes", [])]
    if j["status"] == "error":
        out["error"] = j.get("error")
    return jsonify(out)


@app.get("/api/doodle/<job_id>/<int:i>/preview")
def api_doodle_preview(job_id, i):
    j = jobs.get(job_id)
    sc = next((s for s in (j or {}).get("scenes", []) if s["i"] == i), None)
    if not sc or not sc.get("path") or not os.path.exists(sc["path"]):
        return jsonify(error="Visual not ready."), 404
    ext = os.path.splitext(sc["path"])[1].lower()
    mt = "image/png" if ext == ".png" else "image/jpeg"
    return send_file(sc["path"], mimetype=mt)


@app.post("/api/doodle/scene-visual")
def api_doodle_scene_visual():
    """Regenerate one scene's visual; updates the job and returns the file."""
    data = request.get_json(force=True, silent=True) or {}
    job_id, i = data.get("job_id"), data.get("i")
    j = jobs.get(job_id)
    sc = next((s for s in (j or {}).get("scenes", [])
               if s["i"] == i), None) if j else None
    if not sc:
        return jsonify(error="Scene not found."), 404
    kw = (data.get("keyword") or sc.get("keyword") or "").strip()
    if not kw:
        return jsonify(error="Please type a keyword first."), 400
    visual = data.get("visual", "mix")
    if visual not in ("stock", "doodle", "mix"):
        visual = "mix"
    try:
        path, vsrc = _doodle_fetch_visual(
            kw, visual, data.get("pexels_key", ""),
            data.get("pixabay_key", ""),
            data.get("gemini_key", ""), data.get("aspect", "16:9"),
            f"{job_id}_{i}_r{uuid.uuid4().hex[:4]}",
            style=data.get("img_style"))
    except (PexelsError, PixabayError, ImgGenError) as e:
        return jsonify(error=str(e)), 400
    if not path:
        return jsonify(error="No visual found for that keyword."), 400
    sc.update(keyword=kw, path=path, vsrc=vsrc, error="")
    ext = os.path.splitext(path)[1].lower()
    return send_file(path,
                     mimetype="image/png" if ext == ".png" else "image/jpeg")


def _doodle_render_bg(job_id, audio_id, image_paths, starts, width, height,
                      transition, motion, effect, captions, sfx_on,
                      sfx_kind, sfx_vol, labels=None, draw_time=0.8, kinds=None):
    try:
        jobs[job_id]["status"] = "building"
        a = audios[audio_id]
        total = a["result"]["duration"]
        words = a["result"]["words"]
        if starts[-1] >= total:
            raise CueError("A scene starts beyond the audio length.")
        out = os.path.join(DATA, f"{job_id}.mp4")
        info = build_video(a["path"], image_paths, starts, out,
                           total_duration=total,
                           width=width, height=height,
                           transition=transition, motion=motion,
                           effect=effect, captions=captions,
                           words=words, sfx_on=sfx_on,
                           sfx_kind=sfx_kind, sfx_vol=sfx_vol,
                           labels=labels, draw_time=draw_time, kinds=kinds)
        jobs[job_id].update(status="done", durations=info["durations"])
    except (CueError, RuntimeError) as e:
        jobs[job_id].update(status="error", error=str(e))
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=f"Unexpected error: {e}")


@app.get("/api/recent")
def api_recent():
    """v2.19: recent rendered videos for the dashboard Recent Projects."""
    items = []
    try:
        import glob, time
        mp4s = sorted(glob.glob(os.path.join(DATA, "*.mp4")),
                      key=os.path.getmtime, reverse=True)
        for p in mp4s[:8]:
            if os.path.getsize(p) < 50000:
                continue
            mt = time.strftime("%d %b", time.localtime(os.path.getmtime(p)))
            # duration via ffprobe (best effort)
            dur = ""
            try:
                import subprocess, json as _j
                pr = subprocess.run(
                    ["ffprobe", "-v", "error", "-show_entries",
                     "format=duration", "-of", "json", p],
                    capture_output=True, text=True, timeout=10)
                dd = float(_j.loads(pr.stdout)["format"]["duration"])
                dur = f"{int(dd//60)}:{int(dd%60):02d}"
            except Exception:
                pass
            items.append({"name": os.path.splitext(os.path.basename(p))[0][:32],
                          "meta": f"Rendered {mt} • {dur}",
                          "dur": dur})
    except Exception:
        pass
    return jsonify(items=items)


@app.post("/api/doodle/smartexplainer")
def api_doodle_smartexplainer():
    """v2.18: one-shot Smart Explainer — audio in, full auto video out."""
    audio_id = request.form.get("audio_id")
    a = audios.get(audio_id)
    if not a:
        return jsonify(error="Voiceover not found."), 400
    try:
        width = int(request.form.get("width", 1280))
        height = int(request.form.get("height", 720))
    except (ValueError, TypeError):
        width, height = 1280, 720
    job_id = new_job_id()
    jobs[job_id] = {"status": "working", "pct": 0, "msg": "Starting…"}
    from smartexplainer import build_smart_explainer
    import threading

    def _run():
        try:
            out = os.path.join(DATA, f"{job_id}.mp4")
            os.makedirs(DATA, exist_ok=True)

            def _pg(txt, frac):
                jobs[job_id].update(status="working", pct=int(frac * 100),
                                    msg=txt)
            build_smart_explainer(a["path"], out, progress=_pg,
                                  width=width, height=height)
            jobs[job_id].update(status="done", pct=100, msg="Done!",
                                video=os.path.basename(out))
        except Exception as e:
            jobs[job_id].update(status="error", msg=str(e)[:300])
    threading.Thread(target=_run, daemon=True).start()
    return jsonify(job_id=job_id)


@app.post("/api/doodle/render")
def api_doodle_render():
    """Render the final video from a finished storyboard job."""
    audio_id = request.form.get("audio_id")
    job_id = request.form.get("job_id")
    a = audios.get(audio_id)
    j = jobs.get(job_id)
    if not a:
        return jsonify(error="Voiceover not found."), 400
    if not j or j.get("status") != "done":
        return jsonify(error="Storyboard is not ready yet."), 400
    scenes = [s for s in j.get("scenes", [])
              if s.get("path") and os.path.exists(s["path"])]
    if not scenes:
        return jsonify(error="No visuals — generate the storyboard first."), 400
    try:
        width = int(request.form.get("width", 1280))
        height = int(request.form.get("height", 720))
    except (ValueError, TypeError):
        width, height = 1280, 720
    transition = request.form.get("transition", "dissolve")
    motion = request.form.get("motion", "zoomin")
    effect = request.form.get("effect", "none")
    if transition not in TRANSITIONS:
        transition = "dissolve"
    if motion not in MOTIONS:
        motion = "zoomin"
    if effect not in EFFECTS:
        effect = "none"
    captions = (_caption_opts(request.form)
                if request.form.get("captions_on", "1") == "1" else None)
    sfx_on = request.form.get("sfx_on", "1") == "1"
    draw_speed = {"fast": 0.6, "normal": 1.0, "slow": 1.5}.get(
        request.form.get("draw_speed", "fast"), 0.6)
    labels = [(s.get("keyword") or "") for s in scenes]
    kinds = []
    for s in scenes:
        ext = os.path.splitext(s["path"])[1].lower()
        if ext in VIDEO_EXTS:
            kinds.append("video")
        elif (s.get("vsrc") or "") in ("doodle", "gemini"):
            kinds.append("doodle")
        else:
            kinds.append("photo")
    rjob = uuid.uuid4().hex
    jobs[rjob] = {"status": "queued", "kind": "doodle-render"}
    threading.Thread(
        target=_doodle_render_bg,
        args=(rjob, audio_id, [s["path"] for s in scenes],
              [s["start"] for s in scenes], width, height,
              transition, motion, effect, captions, sfx_on, None, 0.5,
              labels, draw_speed, kinds),
        daemon=True).start()
    return jsonify(job_id=rjob)


@app.get("/api/version")
def api_version():
    out = {"app": "Az Cut", "version": PIPELINE_VERSION,
           "pipeline": PIPELINE_VERSION}
    # v2.20: update check — dashboard banner ke liye
    try:
        info = check_for_updates(PIPELINE_VERSION)
        if info.get("ok") and info.get("update_available"):
            out["update"] = info.get("latest_version", "").lstrip("v")
    except Exception:  # noqa: BLE001
        pass
    return jsonify(out)


# ---------------- API keys: disk persistence ----------------
# Keys are ALSO saved to a JSON file on disk, so they survive even if the
# embedded browser wipes localStorage (fresh profile). Saved only on this PC.
KEYS_FILE = os.path.join(DATA, "api_keys.json")
_KEY_NAMES = ("pixabay", "pexels", "gemini", "fal", "groq", "openrouter", "elevenlabs", "stability")


def _load_keys():
    try:
        with open(KEYS_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return {k: str(d.get(k) or "") for k in _KEY_NAMES}
    except (OSError, ValueError):
        return {k: "" for k in _KEY_NAMES}


def _save_keys(d):
    clean = {k: str((d or {}).get(k) or "").strip() for k in _KEY_NAMES}
    tmp = KEYS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(clean, f)
    os.replace(tmp, KEYS_FILE)
    return clean


def _groq_key(form=None):
    """v2.20: Groq key — form se ya saved keys se. Ek dafa lagao, har jagah kaam."""
    if form:
        k = (form.get("groq_key") or "").strip()
        if k:
            return k
    return (_load_keys().get("groq") or "").strip() or None


@app.get("/api/keys")
def api_keys_get():
    """Return saved API keys (so pages can restore them if localStorage is empty)."""
    return jsonify(_load_keys())


@app.post("/api/keys")
def api_keys_post():
    """Save API keys to disk. Body: {pixabay, pexels, gemini, fal}."""
    data = request.get_json(force=True, silent=True) or {}
    return jsonify(_save_keys(data))


@app.post("/api/audio")
def api_audio():
    f = request.files.get("audio")
    if not f or not f.filename:
        return jsonify(error="Please upload an audio file."), 400
    try:
        path = _save_upload(f, AUDIO_EXTS)
    except CueError as e:
        return jsonify(error=str(e)), 400
    model = request.form.get("model") or None
    if model not in TRANSCRIBE_MODELS:
        model = None
    # v2.21 fix: groq key yahan se lo (request context mein), bg thread mein nahi
    keys = _load_keys()
    gkey = (request.form.get("groq_key") or keys.get("groq") or "").strip() or None
    audio_id = uuid.uuid4().hex
    audios[audio_id] = {"path": path, "status": "transcribing", "model": model,
                        "duration": _quick_duration(path)}
    threading.Thread(target=_transcribe_bg, args=(audio_id, gkey), daemon=True).start()
    return jsonify(audio_id=audio_id, duration=audios[audio_id]["duration"])


@app.get("/api/audio/<audio_id>")
def api_audio_status(audio_id):
    a = audios.get(audio_id)
    if not a:
        return jsonify(error="Audio not found."), 404
    out = {"status": a["status"]}
    if a.get("duration"):
        out["duration"] = a["duration"]
    if a["status"] == "ready":
        out.update(duration=a["result"]["duration"],
                   text=a["result"]["text"],
                   words=a["result"]["words"])
    elif a["status"] == "error":
        out["error"] = a.get("error", "Transcription fail ho gayi.")
    return jsonify(out)


@app.post("/api/cue-draft")
def api_cue_draft():
    data = request.get_json(force=True, silent=True) or {}
    a = audios.get(data.get("audio_id"))
    if not a or a["status"] != "ready":
        return jsonify(error="Please wait for transcription to finish."), 400
    count = max(1, min(50, int(data.get("count", 3))))
    return jsonify(cues=draft_cues(a["result"]["words"], count))


@app.post("/api/validate")
def api_validate():
    data = request.get_json(force=True, silent=True) or {}
    a = audios.get(data.get("audio_id"))
    if not a or a["status"] != "ready":
        return jsonify(error="Please wait for transcription to finish."), 400
    try:
        cues = parse_cues(data.get("cues", ""))
        starts = locate_cues(a["result"]["words"], cues)
    except CueError as e:
        return jsonify(ok=False, error=str(e))
    return jsonify(ok=True, cues=[
        {"img": n, "start": round(s, 2)} for (n, _), s in zip(cues, starts)
    ])


def _caption_opts(form):
    """Validate caption options from a form dict; return None if disabled."""
    if form.get("cap_on") != "1":
        return None

    def _int(key, default, lo, hi):
        try:
            return max(lo, min(hi, int(form.get(key, default))))
        except (ValueError, TypeError):
            return default

    def _color(key, default):
        v = (form.get(key) or "").strip()
        return v if re.match(r"^#[0-9a-fA-F]{6}$", v) else default

    opts = {
        "preset": form.get("cap_preset", "hormozi"),
        "font": form.get("cap_font", "Montserrat"),
        "size": _int("cap_size", 64, 20, 160),
        "bold": form.get("cap_bold", "1") == "1",
        "color": _color("cap_color", "#FFFFFF"),
        "hl": _color("cap_hl", "#FFE600"),
        "outline": _int("cap_outline", 2, 0, 8),
        "outline_color": _color("cap_oline", "#000000"),
        "shadow": _int("cap_shadow", 1, 0, 8),
        "glow": _color("cap_glow", "") or None,
        "grid": form.get("cap_grid", "bottom-center"),
        "dx": _int("cap_dx", 0, -600, 600),
        "dy": _int("cap_dy", 0, -400, 400),
        # v2.20: X%/Y% sliders (clipper + captions page)
        "pos_x": float(form.get("pos_x", 50) or 50),
        "pos_y": float(form.get("pos_y", 84) or 84),
        "wpl": _int("cap_wpl", 4, 1, 20),
        "lines": 2 if form.get("cap_lines") == "2" else 1,
        "karaoke": form.get("cap_karaoke", "word"),
        "anim": form.get("cap_anim", "pop"),
        "uppercase": form.get("cap_upper") == "1",
        "box": form.get("cap_box") == "1",
        "aspect": form.get("cap_aspect") if form.get("cap_aspect") in ("source", "9:16", "16:9", "1:1") else "source",
        "fps": int(form.get("cap_fps") or 0) if str(form.get("cap_fps") or "0") in ("0", "24", "30", "60") else 0,
    }
    if opts["font"] not in CAPTION_FONTS:
        opts["font"] = "Montserrat"
    return opts
def _auto_arrange_media(image_paths, cue_texts):
    """v2.15 "Auto Both Clips Sync": match each media file to the script
    segment whose keywords overlap its filename best. No filename sorting —
    purely script-relevance driven; unmatched media fills remaining slots
    in upload order."""
    n = len(image_paths)
    if n < 2 or not cue_texts:
        return image_paths
    media_toks = []
    for p in image_paths:
        base = os.path.splitext(os.path.basename(p))[0]
        toks = set(t for t in re.findall(r"[a-z]+", base.lower()) if len(t) > 2)
        media_toks.append(toks)
    seg_kws = []
    for c in cue_texts:
        kws = set(extract_keywords(c, top_k=4))
        kws |= set(t for t in re.findall(r"[a-z]+", (c or "").lower())
                   if len(t) > 3)
        seg_kws.append(kws)
    used = [False] * n
    order = []
    for kws in seg_kws:
        best, best_score = -1, 0
        for j in range(n):
            if used[j]:
                continue
            score = len(kws & media_toks[j])
            if score > best_score:
                best, best_score = j, score
        if best < 0:
            best = next((j for j in range(n) if not used[j]), -1)
        if best < 0:
            break
        used[best] = True
        order.append(image_paths[best])
    for j in range(n):
        if not used[j]:
            order.append(image_paths[j])
    return order[:n]


@app.post("/api/studio/broll/plan")
def api_broll_plan():
    """v2.15: keywords + stock preview per script segment (no download yet)."""
    data = request.get_json(force=True, silent=True) or {}
    segments = data.get("segments") or []
    pixabay_key = (data.get("pixabay_key") or "").strip()
    if not segments:
        return jsonify(error="No script segments."), 400
    try:
        plan = broll_mod.plan_broll(pixabay_key, segments[:24])
    except Exception as e:  # noqa: BLE001
        return jsonify(error=f"B-roll plan failed: {e}"), 500
    return jsonify(plan=plan)


def _segment_texts(sync_mode, cues_text, cues):
    """Per-segment script text for B-roll / auto-arrange, in segment order."""
    if sync_mode in ("audio", "script-times"):
        return [(t or "") for _, t in cues]
    texts = []
    for line in (cues_text or "").splitlines():
        m = re.match(r"\[img\d+\]\s*\d+:\d+(?:\.\d+)?\s*(.*)", line.strip())
        texts.append((m.group(1) if m else "").strip())
    return texts


def _apply_broll(job_id, image_paths, starts, total, seg_texts,
                 width, height, broll, transition, broll_marked=None):
    """v2.15: replace segment visuals with Pixabay stock, add typewriter
    text overlays (ASS) + typing SFX. Returns (paths, ass_extra, sfx_extra)."""
    n = len(image_paths)
    density = broll.get("density", "every")
    style = broll.get("style", "smallcaps")
    if style not in broll_mod.TEXT_STYLES:
        style = "smallcaps"
    pos = broll.get("pos", "middle")
    cps = max(6, min(30, int(broll.get("cps", 14) or 14)))
    shake = bool(broll.get("shake", True))
    try:
        typing_vol = max(0.0, min(1.0, float(broll.get("typing_vol", 0.6))))
    except (ValueError, TypeError):
        typing_vol = 0.6
    pixabay_key = (broll.get("pixabay_key") or "").strip()
    kw_overrides = broll.get("kw_overrides") or {}
    tmpdir = os.path.join(DATA, f"{job_id}_broll")
    os.makedirs(tmpdir, exist_ok=True)
    # which segments get B-roll?
    targets = []
    for i in range(n):
        if density == "alternate" and i % 2 == 1:
            continue
        if density == "marked" and not (broll_marked and i < len(broll_marked)
                                        and broll_marked[i]):
            continue
        targets.append(i)
    # xfade overlap correction (mirrors build_video / build_sfx_track)
    T = 0.0
    if transition in TRANSITIONS and n > 1:
        b0 = [0.0] + list(starts[1:]) + [total]
        d0 = [b0[i + 1] - b0[i] for i in range(n)]
        if min(d0) > 0:
            T = min(0.5, min(d0) * 0.49)
            if T < 0.05:
                T = 0.0
    paths = list(image_paths)
    dlg_lines, sfx_extra = [], []
    for i in targets:
        raw = (seg_texts[i] if i < len(seg_texts) else "").strip()
        kw = (kw_overrides.get(str(i)) or "").strip()
        if not kw:
            kws = extract_keywords(raw, top_k=2)
            kw = " ".join(kws) if kws else ""
        if pixabay_key and kw:
            clip = broll_mod.fetch_broll_clip(pixabay_key, kw, tmpdir, idx=i)
            if clip:
                paths[i] = clip
        line = broll_mod.overlay_line(raw)
        if not line:
            continue
        t0 = max(0.0, starts[i] - T * i + 0.6)
        seg_end_raw = starts[i + 1] if i + 1 < n else total
        seg_end = max(t0 + 0.5, seg_end_raw - T * (i + 1))
        dlgs, type_dur = broll_mod.broll_dialogues(
            line, style, t0, seg_end, W=width, H=height,
            cps=cps, shake=shake, pos=pos)
        dlg_lines.extend(dlgs)
        if type_dur > 0.2:
            wav = broll_mod.typing_sfx_slice(
                type_dur, os.path.join(tmpdir, f"typing_{i}.wav"))
            if wav:
                sfx_extra.append((t0, wav, typing_vol))
    ass_extra = None
    if dlg_lines:
        ass_extra = (broll_mod.broll_ass(W=width, H=height), dlg_lines)
    return paths, ass_extra, (sfx_extra or None)


def _render_bg(job_id, audio_id, image_paths, cues_text, width, height,
               transition, motion, effect, captions, sfx_on, sfx_kind,
               sfx_vol, sync_mode, broll=None, auto_arrange=False,
               x264_preset="medium", intro_on=False, adjustments=None,
               color_filter=""):
    try:
        jobs[job_id]["status"] = "building"
        # v2.15: remember [b] B-roll markers, then strip before cue parsing
        broll_marked = None
        if broll and broll.get("on"):
            broll_marked = [("[b]" in ln)
                            for ln in (cues_text or "").splitlines() if ln.strip()]
            cues_text = (cues_text or "").replace("[b]", "")
        a = audios[audio_id]
        if len(image_paths) < 1:
            raise CueError("Please add at least 1 image.")
        if sync_mode in ("timestamps", "script-times"):
            # user-supplied times: no transcription needed.
            # "timestamps": [imgN] m:ss markers; "script-times": script
            # lines starting with m:ss, images follow in order.
            if sync_mode == "timestamps":
                cues = parse_cue_times(cues_text)
                starts = [t for _, t in cues]
                n = len(cues)
            else:
                cues = parse_script_times(cues_text)
                starts = [t for t, _ in cues]
                n = len(cues)
            if n != len(image_paths):
                raise CueError(
                    f"Script sections ({n}) and images ({len(image_paths)}) "
                    "must be equal in number.")
            if a["status"] == "ready":
                total = a["result"]["duration"]
                words = a["result"]["words"]
            else:
                total = audio_duration(a["path"])
                words = []
        else:
            if a["status"] != "ready":
                raise CueError("Please wait for transcription to finish.")
            cues = parse_cues(cues_text)
            if len(cues) != len(image_paths):
                raise CueError(
                    f"Cues ({len(cues)}) and images ({len(image_paths)}) "
                    "must be equal in number.")
            starts = locate_cues(a["result"]["words"], cues)
            total = a["result"]["duration"]
            words = a["result"]["words"]
        if starts[-1] >= total:
            raise CueError("The last cue is beyond the audio length.")
        # --- v2.15: Auto Both Clips Sync (script-relevance media order) ---
        seg_texts = _segment_texts(sync_mode, cues_text, cues)
        if auto_arrange:
            image_paths = _auto_arrange_media(image_paths, seg_texts)
        # --- v2.15: B-roll (stock footage + typewriter text + typing SFX) ---
        ass_extra, sfx_extra = None, None
        if broll and broll.get("on"):
            image_paths, ass_extra, sfx_extra = _apply_broll(
                job_id, image_paths, starts, total, seg_texts,
                width, height, broll, transition, broll_marked)
        out = os.path.join(DATA, f"{job_id}.mp4")
        info = build_video(a["path"], image_paths, starts, out,
                           total_duration=total,
                           width=width, height=height,
                           transition=transition, motion=motion,
                           effect=effect, captions=captions,
                           words=words, sfx_on=sfx_on,
                           sfx_kind=sfx_kind, sfx_vol=sfx_vol,
                           ass_extra=ass_extra, sfx_extra=sfx_extra,
                           x264_preset=x264_preset, adjustments=adjustments,
                           color_filter=color_filter)
        # v2.16: silent AZ Studio intro prepended (no music, no voice)
        if intro_on:
            idur = prepend_intro(out, width, height)
            if idur > 0:
                info["durations"] = [idur] + info["durations"]
        jobs[job_id].update(status="done", durations=info["durations"])
    except (CueError, RuntimeError) as e:
        jobs[job_id].update(status="error", error=str(e))
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=f"Unexpected error: {e}")


@app.post("/api/render")
def api_render():
    audio_id = request.form.get("audio_id")
    cues_text = request.form.get("cues", "")
    sync_mode = request.form.get("sync_mode", "audio")
    if sync_mode not in ("audio", "timestamps", "script-times"):
        sync_mode = "audio"
    a = audios.get(audio_id)
    if not a:
        return jsonify(error="Please upload audio first."), 400
    if sync_mode == "audio" and a["status"] != "ready":
        return jsonify(error="Please wait for transcription to finish."), 400
    files = [f for f in request.files.getlist("images") if f.filename]
    if not files:
        return jsonify(error="Please add at least 1 image."), 400
    try:
        width = int(request.form.get("width", 1280))
        height = int(request.form.get("height", 720))
    except ValueError:
        width, height = 1280, 720
    if (width, height) not in [(w, h) for w, h in ASPECTS.values()]:
        width, height = 1280, 720
    try:
        image_paths = [_save_upload(f, IMAGE_EXTS) for f in files]
    except CueError as e:
        return jsonify(error=str(e)), 400
    transition = request.form.get("transition", "none")
    motion = request.form.get("motion", "none")
    effect = request.form.get("effect", "none")
    if transition not in TRANSITIONS:
        transition = "none"
    if motion not in MOTIONS:
        motion = "none"
    if effect not in EFFECTS:
        effect = "none"
    captions = _caption_opts(request.form)
    sfx_on = request.form.get("sfx_on", "1") == "1"
    sfx_kind = request.form.get("sfx_kind") or None
    if not valid_sfx_kind(sfx_kind):
        sfx_kind = None
    try:
        sfx_vol = max(0.0, min(1.0, float(request.form.get("sfx_vol", 0.5))))
    except (ValueError, TypeError):
        sfx_vol = 0.5
    # --- v2.15: B-roll + auto-arrange + export speed ---
    auto_arrange = request.form.get("auto_arrange", "0") == "1"
    export_speed = request.form.get("export_speed", "best")
    x264_preset = "veryfast" if export_speed == "fast" else "medium"
    intro_on = request.form.get("intro_on", "0") == "1"  # v2.16: silent intro
    # v2.17: CapCut-style adjustments (adj_<name> = -100..100)
    from pipeline import ADJUSTMENTS as _ADJ
    adjustments = {}
    for _an, _ in _ADJ:
        try:
            adjustments[_an] = max(-100, min(100, int(request.form.get("adj_" + _an, 0) or 0)))
        except (ValueError, TypeError):
            adjustments[_an] = 0
    if not any(adjustments.values()):
        adjustments = None
    # v2.17: color filter name -> ffmpeg string
    from capcut_filters import ffmpeg_for as _ff_for
    color_filter = _ff_for(request.form.get("color_filter", ""))
    broll = None
    if request.form.get("broll_on", "0") == "1":
        kw_overrides = {}
        for k in request.form:
            if k.startswith("broll_kw_"):
                kw_overrides[k[len("broll_kw_"):]] = request.form.get(k, "")
        broll = {
            "on": True,
            "density": request.form.get("broll_density", "every"),
            "style": request.form.get("broll_style", "smallcaps"),
            "pos": request.form.get("broll_pos", "middle"),
            "cps": request.form.get("broll_cps", "14"),
            "shake": request.form.get("broll_shake", "1") == "1",
            "typing_vol": request.form.get("broll_typing_vol", "0.6"),
            "pixabay_key": request.form.get("pixabay_key", ""),
            "kw_overrides": kw_overrides,
        }
        if broll["density"] not in ("every", "alternate", "marked"):
            broll["density"] = "every"
        if broll["pos"] not in ("top", "middle", "bottom"):
            broll["pos"] = "middle"
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued"}
    threading.Thread(target=_render_bg,
                     args=(job_id, audio_id, image_paths, cues_text, width,
                           height, transition, motion, effect, captions,
                           sfx_on, sfx_kind, sfx_vol, sync_mode,
                           broll, auto_arrange, x264_preset, intro_on,
                           adjustments, color_filter),
                     daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/render/<job_id>")
def api_job(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Job not found."), 404
    return jsonify(j)


@app.get("/api/render/<job_id>/cues")
def api_cues(job_id):
    """Caption cue segments [start, end, text] for the pro-dashboard timeline."""
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Job not found."), 404
    if j.get("status") != "done":
        return jsonify(error="Captions are not ready yet."), 404
    return jsonify(cues=j.get("cues", []))


@app.get("/api/render/<job_id>/preview")
def api_preview(job_id):
    j = jobs.get(job_id)
    if not j or j["status"] != "done":
        return jsonify(error="Video is not ready yet."), 404
    return send_file(os.path.join(DATA, f"{job_id}.mp4"), mimetype="video/mp4")


@app.get("/api/render/<job_id>/download")
def api_download(job_id):
    j = jobs.get(job_id)
    if not j or j["status"] != "done":
        return jsonify(error="Video is not ready yet."), 404
    return send_file(os.path.join(DATA, f"{job_id}.mp4"),
                     as_attachment=True, download_name="azcut-video.mp4")


# ---------------- Phase 1 tools: transcriber export, captions, clipper -------

@app.post("/api/translate")
def api_translate():
    """v2.19.1: translate text to any language (free Google Translate)."""
    import urllib.parse, urllib.request, json as _json
    d = request.get_json(force=True, silent=True) or {}
    text = (d.get("text") or "").strip()
    target = (d.get("target") or "ur").strip().lower()
    if not text:
        return jsonify(error="No text to translate."), 400
    if len(text) > 4000:
        return jsonify(error="Text too long (max 4000 characters)."), 400
    # chunk into sentences to stay under URL limits
    try:
        q = urllib.parse.quote(text[:3500])
        url = (f"https://translate.googleapis.com/translate_a/single"
               f"?client=gtx&sl=auto&tl={target}&dt=t&q={q}")
        req = urllib.request.Request(url, headers={"User-Agent": "AzCut/2.19"})
        with urllib.request.urlopen(req, timeout=30) as r:
            data = _json.loads(r.read().decode("utf-8"))
        translated = "".join(seg[0] for seg in data[0] if seg[0])
        detected = (data[2] or "auto") if len(data) > 2 else "auto"
        return jsonify(translated=translated, detected=detected, target=target)
    except Exception as e:
        return jsonify(error=f"Translation failed: {e}"), 502


@app.post("/api/brolls/collect")
def api_brolls_collect():
    """v2.20 B-Rolls Collector: script -> scenes -> stock footage per scene."""
    from brolls import split_scenes, collect_footage
    d = request.get_json(force=True, silent=True) or {}
    script = (d.get("script") or "").strip()
    if not script:
        return jsonify(error="Please paste your script first."), 400
    if len(script.split()) < 10:
        return jsonify(error="Script is too short — need at least 10 words."), 400
    keys = _load_keys()
    pixabay_key = keys.get("pixabay") or ""
    pexels_key = keys.get("pexels") or ""
    if not pixabay_key and not pexels_key:
        return jsonify(error="Add a Pixabay or Pexels API key first (dashboard → API Keys)."), 400
    scenes = split_scenes(script, max_scenes=12)
    if not scenes:
        return jsonify(error="Could not split script into scenes."), 400
    try:
        scenes = collect_footage(scenes, pixabay_key=pixabay_key,
                                 pexels_key=pexels_key, per_scene=4)
    except Exception as e:
        return jsonify(error=f"Footage search failed: {e}"), 502
    return jsonify(
        topic=d.get("topic", ""),
        content_type=d.get("content_type", ""),
        scenes=[{
            "n": i + 1,
            "text": s["text"],
            "keywords": s["keywords"],
            "query": s["query"],
            "clips": s["clips"],
        } for i, s in enumerate(scenes)],
    )


@app.post("/api/brolls/download")
def api_brolls_download():
    """v2.20: download selected clips as a ZIP."""
    import io, zipfile, urllib.request
    d = request.get_json(force=True, silent=True) or {}
    clips = d.get("clips") or []  # [{"url","name"}]
    if not clips:
        return jsonify(error="No clips selected."), 400
    if len(clips) > 24:
        return jsonify(error="Max 24 clips per ZIP."), 400
    buf = io.BytesIO()
    allowed = ("cdn.pixabay.com", "videos.pexels.com", "player.vimeo.com",
               "images.pexels.com")
    try:
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for i, c in enumerate(clips):
                url = c.get("url") or ""
                host = urllib.parse.urlparse(url).hostname or ""
                if not any(host.endswith(a) for a in allowed):
                    continue
                name = re.sub(r"[^A-Za-z0-9_.-]", "_",
                              c.get("name") or f"clip_{i+1}.mp4")[:60]
                req = urllib.request.Request(
                    url, headers={"User-Agent": "AzCut/2.20"})
                with urllib.request.urlopen(req, timeout=300) as r:
                    zf.writestr(name, r.read())
    except Exception as e:
        return jsonify(error=f"Download failed: {e}"), 502
    buf.seek(0)
    return send_file(buf, mimetype="application/zip",
                     as_attachment=True, download_name="brolls.zip")


@app.get("/api/audio/<audio_id>/export")
def api_export(audio_id):
    a = audios.get(audio_id)
    if not a or a["status"] != "ready":
        return jsonify(error="Please wait for transcription to finish."), 400
    fmt = request.args.get("format", "srt").lower()
    words = a["result"]["words"]
    converters = {"srt": words_to_srt, "txt": words_to_txt,
                  "vtt": words_to_vtt, "stamped": words_to_stamped}
    names = {"srt": "transcript.srt", "txt": "transcript.txt",
             "vtt": "transcript.vtt",
             "stamped": "script-with-timestamps.txt"}
    if fmt not in converters:
        fmt = "srt"
    data, name = converters[fmt](words), names[fmt]
    path = os.path.join(DATA, f"{audio_id}.{fmt}")
    with open(path, "w", encoding="utf-8") as f:
        f.write(data)
    return send_file(path, as_attachment=True, download_name=name)


def _caption_bg(job_id, video_path, opts, model, groq_key=None):
    try:
        jobs[job_id]["status"] = "building"
        out = os.path.join(DATA, f"{job_id}.mp4")
        info = burn_captions(video_path, out, opts, model=model,
                             groq_key=groq_key or _groq_key())
        jobs[job_id].update(status="done", words=info["words"],
                            cues=info.get("cues", []),
                            language=info.get("language", ""))
        # cache words for fast re-burn (new style, no re-transcribe)
        _caption_words[job_id] = {"words": info.get("words_list", []),
                                  "language": info.get("language", ""),
                                  "video_path": video_path}
        _cap_cache_trim()
    except (CueError, RuntimeError) as e:
        jobs[job_id].update(status="error", error=str(e))
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=f"Unexpected error: {e}")


def _caption_reburn_bg(job_id, src, opts):
    """Re-burn captions with new style using cached words (no transcription)."""
    try:
        jobs[job_id]["status"] = "building"
        out = os.path.join(DATA, f"{job_id}.mp4")
        info = burn_captions(src["video_path"], out, opts,
                             words=src["words"], language=src["language"])
        jobs[job_id].update(status="done", words=info["words"],
                            cues=info.get("cues", []),
                            language=info.get("language", ""))
        _caption_words[job_id] = {"words": src["words"],
                                  "language": src["language"],
                                  "video_path": src["video_path"]}
        _cap_cache_trim()
    except (CueError, RuntimeError) as e:
        jobs[job_id].update(status="error", error=str(e))
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=f"Unexpected error: {e}")


@app.post("/api/caption/reburn")
def api_caption_reburn():
    """Re-burn captions with a new style — reuses cached transcription."""
    data = request.get_json(force=True, silent=True) or {}
    src = _caption_words.get(data.get("job_id"))
    if not src or not src.get("words"):
        return jsonify(error="Pehle ⚡ One-Click Captions chalao — phir re-burn hoga."), 400
    if not os.path.exists(src["video_path"]):
        return jsonify(error="Video file nahi mili — dobara upload karke One-Click chalao."), 400
    form = dict(data.get("opts") or {})
    form["cap_on"] = "1"
    opts = _caption_opts(form)
    if opts is None:
        return jsonify(error="Style options samajh nahi aayein."), 400
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "caption-reburn"}
    threading.Thread(target=_caption_reburn_bg,
                     args=(job_id, src, opts), daemon=True).start()
    return jsonify(job_id=job_id)


@app.post("/api/caption")
def api_caption():
    f = request.files.get("video")
    if not f or not f.filename:
        return jsonify(error="Please upload a video file."), 400
    try:
        video_path = _save_upload(f, VIDEO_EXTS)
    except CueError as e:
        return jsonify(error=str(e)), 400
    form = dict(request.form)
    form["cap_on"] = "1"  # captions always on for this tool
    opts = _caption_opts(form)
    model = form.get("model") or None
    if model not in TRANSCRIBE_MODELS:
        model = None
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "caption"}
    threading.Thread(target=_caption_bg, args=(job_id, video_path, opts, model),
                     daemon=True).start()
    return jsonify(job_id=job_id)


def _job_error(job_id, e):
    if isinstance(e, (CueError, RuntimeError)):
        jobs[job_id].update(status="error", error=str(e))
    else:
        jobs[job_id].update(status="error", error=f"Unexpected error: {e}")


def _caption_preview_bg(job_id, video_path, opts, model):
    try:
        jobs[job_id]["status"] = "building"
        out = os.path.join(DATA, f"{job_id}.mp4")
        info = preview_caption_clip(video_path, out, opts, model=model, groq_key=_groq_key())
        jobs[job_id].update(status="done", language=(info or {}).get("language", ""))
    except Exception as e:  # noqa: BLE001
        _job_error(job_id, e)


@app.post("/api/caption-preview")
def api_caption_preview():
    """Burn captions on a 5s sample of the uploaded video (live preview)."""
    f = request.files.get("video")
    if not f or not f.filename:
        return jsonify(error="Please upload a video file."), 400
    try:
        video_path = _save_upload(f, VIDEO_EXTS)
    except CueError as e:
        return jsonify(error=str(e)), 400
    form = dict(request.form)
    form["cap_on"] = "1"
    opts = _caption_opts(form)
    model = form.get("model") or None
    if model not in TRANSCRIBE_MODELS:
        model = None
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "caption-preview"}
    threading.Thread(target=_caption_preview_bg,
                     args=(job_id, video_path, opts, model), daemon=True).start()
    return jsonify(job_id=job_id)


def _studio_preview_bg(job_id, audio_id, image_path, opts):
    try:
        jobs[job_id]["status"] = "building"
        a = audios.get(audio_id)
        if not a or a["status"] != "ready":
            raise CueError("Please wait for transcription to finish first.")
        out = os.path.join(DATA, f"{job_id}.mp4")
        preview_studio_clip(a["path"], image_path, out, opts,
                            a["result"]["words"])
        jobs[job_id].update(status="done")
    except Exception as e:  # noqa: BLE001
        _job_error(job_id, e)


@app.post("/api/studio-preview")
def api_studio_preview():
    """Render a 5s studio sample (first image + start of audio) with captions."""
    audio_id = request.form.get("audio_id")
    a = audios.get(audio_id)
    if not a:
        return jsonify(error="Please upload audio first."), 400
    f = request.files.get("image")
    if not f or not f.filename:
        return jsonify(error="Please pick one image for the preview."), 400
    try:
        image_path = _save_upload(f, IMAGE_EXTS)
    except CueError as e:
        return jsonify(error=str(e)), 400
    form = dict(request.form)
    form["cap_on"] = "1"
    opts = _caption_opts(form)
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "studio-preview"}
    threading.Thread(target=_studio_preview_bg,
                     args=(job_id, audio_id, image_path, opts), daemon=True).start()
    return jsonify(job_id=job_id)


def _autoclip_bg(job_id, video_path, n_clips, clip_dur, cam, cap_opts, model,
                 groq_key=None):
    try:
        jobs[job_id]["status"] = "building"
        out_dir = os.path.join(DATA, job_id)
        os.makedirs(out_dir, exist_ok=True)
        paths = make_auto_clips(video_path, out_dir, n_clips=n_clips,
                                clip_dur=clip_dur, cam=cam,
                                captions=cap_opts, model=model,
                                groq_key=groq_key or _groq_key())
        jobs[job_id].update(status="done", clips=paths)
    except Exception as e:  # noqa: BLE001
        _job_error(job_id, e)


@app.post("/api/autoclip")
def api_autoclip():
    """Find the most engaging clips (any language) and cut them to 9:16."""
    f = request.files.get("video")
    if not f or not f.filename:
        return jsonify(error="Please upload a video file."), 400
    try:
        video_path = _save_upload(f, VIDEO_EXTS)
    except CueError as e:
        return jsonify(error=str(e)), 400
    try:
        n_clips = max(1, min(10, int(request.form.get("n_clips", 3))))
        clip_dur = max(10, min(120, int(request.form.get("clip_dur", 30))))
    except ValueError:
        return jsonify(error="Invalid clip settings."), 400
    cam = request.form.get("cam") or "face"
    if cam not in ("face", "center"):
        cam = "face"
    cap_opts = None
    if request.form.get("cap_on") == "1":
        form = dict(request.form)
        cap_opts = _caption_opts(form)
    model = request.form.get("model") or None
    if model not in TRANSCRIBE_MODELS:
        model = None
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "autoclip"}
    threading.Thread(target=_autoclip_bg,
                     args=(job_id, video_path, n_clips, clip_dur, cam,
                           cap_opts, model), daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/clips/<job_id>")
def api_clips_status(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Unknown job."), 404
    out = {"status": j["status"], "kind": j.get("kind")}
    if j["status"] == "done":
        out["clips"] = list(range(1, len(j.get("clips", [])) + 1))
    if j["status"] == "error":
        out["error"] = j.get("error")
    return jsonify(out)


@app.get("/api/clips/<job_id>/<int:n>/preview")
def api_clip_preview(job_id, n):
    j = jobs.get(job_id)
    clips = (j or {}).get("clips") or []
    if not (1 <= n <= len(clips)) or not os.path.exists(clips[n - 1]):
        return jsonify(error="Clip not found."), 404
    return send_file(clips[n - 1], mimetype="video/mp4")


@app.get("/api/clips/<job_id>/download")
def api_clips_download(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Job not found."), 404
    clips = j.get("clips") or []
    if j["status"] != "done" or not clips:
        return jsonify(error="Clips are not ready yet."), 400
    import zipfile
    zpath = os.path.join(DATA, f"clips_{job_id}.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for i, p in enumerate(clips, 1):
            z.write(p, f"clip{i}.mp4")
    return send_file(zpath, as_attachment=True,
                     download_name="azcut_clips.zip")


def _clipper_bg(job_id, video_path):
    try:
        jobs[job_id]["status"] = "building"
        out = os.path.join(DATA, f"{job_id}.mp4")
        info = reframe_916(video_path, out)
        jobs[job_id].update(status="done", faces=info["faces"])
    except (CueError, RuntimeError) as e:
        jobs[job_id].update(status="error", error=str(e))
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=f"Unexpected error: {e}")


@app.post("/api/clipper")
def api_clipper():
    f = request.files.get("video")
    if not f or not f.filename:
        return jsonify(error="Please upload a video file."), 400
    try:
        video_path = _save_upload(f, VIDEO_EXTS)
    except CueError as e:
        return jsonify(error=str(e)), 400
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "clipper"}
    threading.Thread(target=_clipper_bg, args=(job_id, video_path),
                     daemon=True).start()
    return jsonify(job_id=job_id)


def _imggen_bg(job_id, api_key, prompts_text, aspect, model, provider):
    try:
        jobs[job_id]["status"] = "building"
        prompts = parse_bulk_prompts(prompts_text)
        out_dir = os.path.join(DATA, job_id)
        os.makedirs(out_dir, exist_ok=True)

        def prog(i, n):
            jobs[job_id].update(doing=f"{i}/{n}")

        paths, failed = bulk_generate(api_key, prompts, out_dir, aspect=aspect,
                                      model=model, progress=prog,
                                      provider=provider)
        jobs[job_id].update(status="done", images=paths, failed=failed)
    except Exception as e:  # noqa: BLE001
        _job_error(job_id, e)


@app.post("/api/test-key")
def api_test_key():
    """v2.20: API key test karo (groq/openrouter)."""
    import urllib.request
    import json as _json
    data = request.get_json(force=True, silent=True) or {}
    service = (data.get("service") or "").strip().lower()
    key = (_load_keys().get(service) or "").strip()
    if not key:
        return jsonify(ok=False, error="Key nahi lagi."), 400

    UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
          "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
    try:
        if service == "groq":
            # chhota test: models list
            req = urllib.request.Request(
                "https://api.groq.com/openai/v1/models",
                headers={"Authorization": f"Bearer {key}",
                         "User-Agent": UA})
            with urllib.request.urlopen(req, timeout=30) as resp:
                d = _json.loads(resp.read().decode("utf-8"))
            n = len(d.get("data", []))
            return jsonify(ok=True, message=f"✅ Groq OK! ({n} models)")
        elif service == "elevenlabs":
            req = urllib.request.Request(
                "https://api.elevenlabs.io/v1/user",
                headers={"xi-api-key": key, "User-Agent": UA})
            with urllib.request.urlopen(req, timeout=30) as resp:
                d = _json.loads(resp.read().decode("utf-8"))
            chars = d.get("subscription", {}).get("character_limit", 0)
            return jsonify(ok=True,
                           message=f"✅ ElevenLabs OK! ({chars} chars)"), 200
        elif service == "stability":
            req = urllib.request.Request(
                "https://api.stability.ai/v1/user/account",
                headers={"Authorization": f"Bearer {key}",
                         "User-Agent": UA})
            with urllib.request.urlopen(req, timeout=30) as resp:
                _json.loads(resp.read().decode("utf-8"))
            return jsonify(ok=True, message="✅ Stability OK!"), 200
        elif service == "openrouter":
            body = _json.dumps({
                "model": "meta-llama/llama-3.3-70b-instruct:free",
                "messages": [{"role": "user", "content": "Say OK"}],
                "max_tokens": 5,
            }).encode()
            req = urllib.request.Request(
                "https://openrouter.ai/api/v1/chat/completions",
                data=body,
                headers={"Authorization": f"Bearer {key}",
                         "Content-Type": "application/json",
                         "HTTP-Referer": "https://azcut.app",
                         "X-Title": "Az Cut", "User-Agent": UA})
            with urllib.request.urlopen(req, timeout=60) as resp:
                _json.loads(resp.read().decode("utf-8"))
            return jsonify(ok=True, message="✅ OpenRouter OK!")
        return jsonify(ok=False, error="Unknown service."), 400
    except urllib.error.HTTPError as e:
        code = e.code
        if code == 401:
            return jsonify(ok=False,
                            error="❌ Galat key — check karo."), 200
        return jsonify(ok=False,
                        error=f"❌ Error {code} — phir try karo."), 200
    except Exception as e:  # noqa: BLE001
        return jsonify(ok=False, error=f"❌ {str(e)[:100]}"), 200


@app.post("/api/ai-prompts")
def api_ai_prompts():
    """v2.20: OpenRouter se script -> detailed image prompts (bulk)."""
    import urllib.request
    import json as _json
    data = request.get_json(force=True, silent=True) or {}
    script = (data.get("script") or "").strip()
    if not script:
        return jsonify(error="Script likhein."), 400
    style = (data.get("style") or "cinematic").strip()
    api_key = (_load_keys().get("openrouter") or "").strip()
    if not api_key:
        return jsonify(error="OpenRouter key dashboard mein lagao."), 400

    style_desc = {
        "cinematic": "Cinematic hand-painted illustration",
        "doodle": "Simple doodle cartoon illustration",
        "realistic": "Photorealistic cinematic photo",
        "anime": "Beautiful anime style illustration",
    }.get(style, "Cinematic hand-painted illustration")

    system = (
        "You are a professional storyboard artist. Given a video script, "
        "split it into visual scenes and write ONE detailed image generation "
        "prompt per scene. "
        f"Each prompt must start with 'Image Prompt: {style_desc} showing ' "
        "then describe the scene vividly. "
        "End EVERY prompt with: 'warm golden atmosphere, extreme wide establishing "
        "shot, full-bleed 16:9, scene extending completely to every edge, "
        "no borders, no frames, no text, no captions, no subtitles, no watermark, "
        "NOT flat clipart, NOT 3D render'. "
        "Number each as '(0:00) IMAGE 1', '(0:08) IMAGE 2' etc (8 sec apart). "
        "Output ONLY the numbered prompts, one per paragraph, no extra text."
    )
    body = _json.dumps({
        "model": "meta-llama/llama-3.3-70b-instruct:free",
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": f"Script:\n{script[:4000]}"},
        ],
    }).encode()

    req = urllib.request.Request(
        "https://openrouter.ai/api/v1/chat/completions",
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://azcut.app",
            "X-Title": "Az Cut",
        })
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            out = _json.loads(resp.read().decode("utf-8"))
        text = out["choices"][0]["message"]["content"]
        return jsonify(prompts=text)
    except urllib.error.HTTPError as e:
        try:
            err = e.read().decode("utf-8")[:300]
        except Exception:  # noqa: BLE001
            err = str(e)
        return jsonify(error=f"OpenRouter error: {err}"), 500
    except Exception as e:  # noqa: BLE001
        return jsonify(error=str(e)[:300]), 500


@app.post("/api/imggen")
def api_imggen():
    """Bulk-generate storyboard images (Gemini or fal.ai)."""
    provider = (request.form.get("provider") or "gemini").strip().lower()
    if provider not in ("gemini", "fal"):
        provider = "gemini"
    api_key = (request.form.get("api_key") or "").strip()
    if not api_key:
        if provider == "fal":
            return jsonify(
                error="Please paste your fal.ai API key first."), 400
        return jsonify(error="Please paste your Gemini API key first."), 400
    prompts_text = request.form.get("prompts", "")
    aspect = request.form.get("aspect", "16:9")
    model = request.form.get("model", "")
    if aspect not in IMGGEN_ASPECTS:
        aspect = "16:9"
    if provider == "fal":
        if model not in FAL_MODELS:
            model = "fal-ai/flux/schnell"
    elif model not in IMGGEN_MODELS:
        model = "gemini-3.1-flash-image"
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "imggen"}
    threading.Thread(target=_imggen_bg,
                     args=(job_id, api_key, prompts_text, aspect, model,
                           provider),
                     daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/imggen/<job_id>")
def api_imggen_status(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Unknown job."), 404
    out = {"status": j["status"], "kind": j.get("kind"),
           "doing": j.get("doing", "")}
    if j["status"] == "done":
        out["images"] = list(range(1, len(j.get("images", [])) + 1))
        out["failed"] = [{"n": n, "error": e}
                         for n, e in (j.get("failed") or [])]
    if j["status"] == "error":
        out["error"] = j.get("error")
    return jsonify(out)


@app.get("/api/imggen/<job_id>/<int:n>/preview")
def api_imggen_preview(job_id, n):
    j = jobs.get(job_id)
    imgs = (j or {}).get("images") or []
    if not (1 <= n <= len(imgs)) or not os.path.exists(imgs[n - 1]):
        return jsonify(error="Image not found."), 404
    return send_file(imgs[n - 1], mimetype="image/png")


@app.get("/api/imggen/<job_id>/download")
def api_imggen_download(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Job not found."), 404
    imgs = j.get("images") or []
    if j["status"] != "done" or not imgs:
        return jsonify(error="Images are not ready yet."), 400
    import zipfile
    zpath = os.path.join(DATA, f"images_{job_id}.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for i, p in enumerate(imgs, 1):
            z.write(p, f"{i:02d}.png")
    return send_file(zpath, as_attachment=True,
                     download_name="azcut_images.zip")


# ---------------- one-click auto-update ----------------
_update_state = {"state": "idle", "percent": 0, "message": "", "latest_version": ""}
_last_update_check = None


@app.get("/api/check-update")
def api_check_update():
    global _last_update_check
    _last_update_check = check_for_updates(PIPELINE_VERSION)
    return jsonify(_last_update_check)


@app.get("/api/update-status")
def api_update_status():
    return jsonify(_update_state)


def _do_update(url, asset_name):
    try:
        _update_state.update(state="downloading", percent=0,
                             message="Update download ho raha hai...")
        tmp = os.environ.get("TEMP") or tempfile.gettempdir()
        dest = os.path.join(tmp, asset_name)
        req = urllib.request.Request(url, headers={"User-Agent": "AzCut-Updater"})
        with urllib.request.urlopen(req, timeout=60) as r, open(dest, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            while True:
                chunk = r.read(1024 * 256)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if total:
                    _update_state["percent"] = int(done * 100 / total)
        _update_state.update(state="downloaded", percent=100,
                             message="Download mukammal!")
        if not FROZEN:
            _update_state["message"] = f"File tayyar: {dest} - ise khud chalayein."
            return
        # frozen (installed) mode: silent-install via helper bat, then restart
        exe_dir = os.path.dirname(sys.executable)
        bat = os.path.join(tmp, "azcut_update.bat")
        with open(bat, "w") as f:
            f.write("@echo off\n"
                    "timeout /t 4 /nobreak >nul\n"
                    "taskkill /F /IM AzCut.exe >nul 2>nul\n"
                    f'"{dest}" /VERYSILENT /SUPPRESSMSGBOXES\n'
                    f'start "" "{exe_dir}\\AzCut.exe"\n')
        _update_state.update(state="installing",
                             message="Installer chal raha hai...")
        popen_kw = {}
        if os.name == "nt":
            popen_kw["creationflags"] = (subprocess.DETACHED_PROCESS
                                         | subprocess.CREATE_NO_WINDOW)
        subprocess.Popen(["cmd", "/c", bat], **popen_kw)
        time.sleep(2)
        os._exit(0)
    except Exception as e:
        _update_state.update(state="error", message=str(e)[:200])


@app.post("/api/start-update")
def api_start_update():
    if _update_state["state"] == "downloading":
        return jsonify(started=True)
    info = _last_update_check or check_for_updates(PIPELINE_VERSION)
    if not info.get("ok") or not info.get("update_available"):
        return jsonify(error="No new update found."), 404
    _update_state.update(state="downloading", percent=0, message="",
                         latest_version=info["latest_version"])
    threading.Thread(target=_do_update,
                     args=(info["download_url"], info["asset_name"]),
                     daemon=True).start()
    return jsonify(started=True)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"\n  Az Cut chal raha hai: http://127.0.0.1:{port}\n"
          "  Band karne ke liye Ctrl+C dabayein.\n")
    if os.environ.get("NARRASYNC_NO_BROWSER") != "1":
        import webbrowser
        from threading import Timer
        Timer(1.2, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
    app.run(host="127.0.0.1", port=port, threaded=True)
