"""Az Cut web app — narration-synced video builder.

Run:  python app.py   ->  http://127.0.0.1:5000
"""
import os
import json
import re
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import uuid

# v2.20: Windows par har subprocess (ffmpeg waghera) ke liye console window
# blink na ho — CREATE_NO_WINDOW lagao
if os.name == "nt":
    _orig_popen = subprocess.Popen

    def _hidden_popen(*args, **kwargs):
        kwargs.setdefault("creationflags", subprocess.CREATE_NO_WINDOW)
        return _orig_popen(*args, **kwargs)

    subprocess.Popen = _hidden_popen

# v2.49: frozen (installed) app mein bundled ffmpeg.exe ki jagah PATH
# mein lazmi rakho — exe ka folder AUR PyInstaller ka _internal
# (sys._MEIPASS) folder, jahan --add-data wali files asal mein hoti
# hain. Is ke baghair "ffmpeg" subprocess [WinError 2] deta tha.
if getattr(sys, "frozen", False):
    _dirs = [os.path.dirname(sys.executable)]
    _mp = getattr(sys, "_MEIPASS", "")
    if _mp and _mp not in _dirs:
        _dirs.append(_mp)
    os.environ["PATH"] = os.pathsep.join(_dirs) + os.pathsep + os.environ.get("PATH", "")

from flask import Flask, jsonify, request, send_file
from werkzeug.utils import secure_filename  # noqa: F401  (kept for clarity)

from pipeline import (
    PIPELINE_VERSION, TRANSITIONS, MOTIONS, EFFECTS, CAPTION_STYLES, VIDEO_EXTS,
    SFX_KINDS, SFX_KINDS_ALL, valid_sfx_kind, CAPTION_PRESETS, TOP_PRESETS, CAPTION_FONTS, CAPTION_GRIDS,
    CAPTION_ANIMS, TRANSCRIBE_MODELS,
    CueError, audio_duration, build_video, burn_captions, draft_cues,
    locate_cues, make_auto_clips, make_title_card, parse_cue_times,
    parse_cues, parse_script_times, preview_caption_clip,
    preview_studio_clip, reframe_916, transcribe, words_to_srt,
    words_to_txt, words_to_vtt, words_to_stamped, EXPORT_FORMATS,
    prepend_intro,
)
from pipeline import TITLECARD_THEMES
from pipeline import split_scenes, extract_keywords, DOODLE_PROMPT_SUFFIX
from pexels import PexelsError, download as pexels_download, search as pexels_search
from pixabay import PixabayError, download as pixabay_download, search as pixabay_search
from imggen import (
    IMGGEN_ASPECTS, IMGGEN_MODELS, IMAGE_STYLES, FAL_MODELS,
    POLLINATION_MODELS, ImgGenError,
    bulk_generate, generate_image,
    parse_bulk_prompts,
)
import broll as broll_mod

ASPECTS = {
    "16:9": (1280, 720),
    "9:16": (720, 1280),
    "1:1": (1080, 1080),
    "4:5": (1080, 1350),
}
from updater import check_for_updates

FROZEN = getattr(sys, "frozen", False)
if FROZEN:
    # Running from PyInstaller bundle (installed under Program Files):
    # read-only resources live next to the exe, user data goes to LocalAppData.
    BASE = sys._MEIPASS
    _local = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    DATA = os.path.join(_local, "AzCut", "data")
else:
    BASE = os.path.dirname(os.path.abspath(__file__))
    DATA = os.path.join(BASE, "data")
STATIC_DIR = os.path.join(BASE, "static")
os.makedirs(DATA, exist_ok=True)

app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="")
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024 * 1024  # 1 GB

audios = {}  # audio_id -> {path, status, result?, error?}
jobs = {}    # job_id   -> {status, durations?, error?}
_caption_words = {}  # caption job_id -> {words, language, video_path} (for fast re-burn)


def _cap_cache_trim():
    while len(_caption_words) > 6:
        _caption_words.pop(next(iter(_caption_words)))

AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".ogg", ".flac", ".aac", ".wma", ".opus",
              ".mp4", ".webm", ".mkv", ".mov", ".avi"}  # v2.24: video bhi!
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp",
              ".mp4", ".mov", ".m4v", ".webm", ".mkv", ".avi"}


def _save_upload(f, exts):
    ext = os.path.splitext(f.filename or "")[1].lower()
    if ext not in exts:
        raise CueError(f"File type '{ext or '?'}' is not supported.")
    path = os.path.join(DATA, f"{uuid.uuid4().hex}{ext}")
    f.save(path)
    return path


def _quick_duration(path):
    """Audio duration in seconds via ffprobe — instant (<1s), no decode."""
    try:
        r = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", path],
            capture_output=True, text=True, timeout=15)
        d = float(r.stdout.strip())
        return d if d > 0 else 0.0
    except Exception:  # noqa: BLE001
        return 0.0


def _transcribe_bg(audio_id, groq_key=None, language=None):
    try:
        model = audios[audio_id].get("model")
        result = transcribe(audios[audio_id]["path"], model=model, groq_key=groq_key,
                            language=language or audios[audio_id].get("language"))
        audios[audio_id].update(status="ready", result=result)
    except Exception as e:  # noqa: BLE001
        audios[audio_id].update(status="error", error=str(e))


@app.route("/intro-splash")
def intro_splash():
    """v2.18: app launch splash screen — plays the AZ Studio intro."""
    return """<!DOCTYPE html><html><head><meta charset="utf-8">
<title>Az Cut</title>
<style>html,body{margin:0;padding:0;background:#0a0a0e;height:100%;overflow:hidden;cursor:pointer}
video{width:100vw;height:100vh;object-fit:contain}</style></head>
<body onclick="window.close()" title="Click to skip">
<video autoplay muted playsinline><source src="/intro-video.mp4" type="video/mp4"></video>
</body></html>"""


@app.route("/intro-video.mp4")
def intro_video():
    """v2.18: serve the silent intro mp4 for the splash screen."""
    from pipeline import INTRO_ASSET
    if not os.path.exists(INTRO_ASSET):
        return "Intro not found", 404
    return send_file(INTRO_ASSET, mimetype="video/mp4")


@app.route("/")
def index():
    return app.send_static_file("home.html")


@app.after_request
def _no_cache_html(resp):
    # v2.17.1: never let the webview cache HTML pages — after an update the
    # old cached UI (theme/tabs) would keep showing instead of the new one.
    ct = resp.headers.get("Content-Type", "")
    if "text/html" in ct:
        resp.headers["Cache-Control"] = \
            "no-store, no-cache, must-revalidate, max-age=0"
        resp.headers["Pragma"] = "no-cache"
    return resp


@app.route("/studio")
def studio():
    return app.send_static_file("studio.html")


@app.route("/workflow")
def workflow():
    """v2.21: Workflow Wizard — topic se final video tak step by step."""
    return app.send_static_file("workflow.html")


@app.route("/bulk-studio")
def bulk_studio():
    """v2.21: Bulk Image Studio — style+character reference, ZIP download."""
    return app.send_static_file("bulk-studio.html")


@app.route("/transcriber")
def page_transcriber():
    return app.send_static_file("transcriber.html")


@app.route("/voice-lab")
def page_voice_lab():
    return app.send_static_file("voice-lab.html")


@app.route("/captions")
def page_captions():
    return app.send_static_file("captions.html")


@app.route("/clipper")
def page_clipper():
    return app.send_static_file("clipper.html")


@app.route("/image-lab")
def page_image_lab():
    return app.send_static_file("image-lab.html")




@app.route("/brolls")
def page_brolls():
    return app.send_static_file("brolls.html")


























# ----------------------------------------------------------------------------
# Clip Grabber: celebrity name / video link -> clean 1080p moment clips
# (no captions, no overlays)
# ----------------------------------------------------------------------------

@app.route("/clips")
def page_clips():
    return app.send_static_file("clips.html")


@app.route("/oneclick")
def page_oneclick():
    return app.send_static_file("oneclick.html")
















# ----------------------------------------------------------------------------
# Voiceover Video: voiceover -> auto YouTube-clip video (Ken Burns + fades)
# ----------------------------------------------------------------------------

@app.post("/api/vv/analyze")
def api_vv_analyze():
    import voicevideo as vv
    data = request.get_json(force=True, silent=True) or {}
    a = audios.get(data.get("audio_id"))
    if not a:
        return jsonify(error="Audio not found."), 404
    if a["status"] == "transcribing":
        return jsonify(status="transcribing"), 202
    if a["status"] == "error":
        return jsonify(error=a.get("error") or "Transcription failed."), 400
    try:
        words = [(w["word"], w["start"], w["end"])
                 for w in a["result"]["words"]]
        dur = a["result"].get("duration") or 0
        if not dur:
            import rank as rankmod
            dur = rankmod.probe_duration(a["path"])
        scenes = vv.split_scenes(words, dur)
    except Exception as e:  # noqa: BLE001
        return jsonify(error=str(e)), 400
    return jsonify(status="ready", duration=round(dur, 1),
                   transcription=a["result"].get("text", ""),
                   scenes=scenes)


def _vv_bg(job_id, audio_id, scenes, ratio):
    import voicevideo as vv
    try:
        a = audios.get(audio_id)
        if not a or a["status"] != "ready":
            raise vv.VVError("Audio is not ready.")
        workdir = os.path.join(DATA, f"vv_{job_id}")
        os.makedirs(workdir, exist_ok=True)
        jobs[job_id]["status"] = "building"

        def _prog(msg):
            jobs[job_id]["doing"] = msg

        out = vv.build_voiceover_video(a["path"], scenes, ratio, workdir,
                                       progress_cb=_prog)
        jobs[job_id].update(status="done", file=out,
                            transcription=a["result"].get("text", ""),
                            scenes=scenes)
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=str(e))


@app.post("/api/vv/build")
def api_vv_build():
    import voicevideo as vv
    data = request.get_json(force=True, silent=True) or {}
    audio_id = data.get("audio_id")
    a = audios.get(audio_id)
    if not a or a["status"] != "ready":
        return jsonify(error="Please upload and transcribe the voiceover first."), 400
    scenes = data.get("scenes") or []
    scenes = [s for s in scenes
              if isinstance(s, dict) and s.get("keyword")
              and float(s.get("end", 0)) > float(s.get("start", 0))]
    if not scenes:
        return jsonify(error="No scenes found."), 400
    if len(scenes) > 12:
        return jsonify(error="Zyada se zyada 12 scenes."), 400
    ratio = data.get("ratio", "16:9")
    if ratio not in ("16:9", "9:16", "1:1"):
        ratio = "16:9"
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "vv"}
    threading.Thread(target=_vv_bg,
                     args=(job_id, audio_id, scenes, ratio),
                     daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/vv/<job_id>")
def api_vv_status(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Job not found."), 404
    out = {"status": j.get("status"), "doing": j.get("doing")}
    if j.get("status") == "error":
        out["error"] = j.get("error")
    if j.get("status") == "done":
        out["transcription"] = j.get("transcription", "")
        out["scenes"] = j.get("scenes", [])
    return jsonify(out)


@app.get("/api/vv/<job_id>/preview")
def api_vv_preview(job_id):
    j = jobs.get(job_id)
    if not j or j.get("status") != "done" or not os.path.exists(j.get("file", "")):
        return jsonify(error="Video is not ready."), 404
    return send_file(j["file"], as_attachment=False,
                     download_name="azcut-voiceover-video.mp4")


@app.get("/api/vv/<job_id>/download")
def api_vv_download(job_id):
    j = jobs.get(job_id)
    if not j or j.get("status") != "done" or not os.path.exists(j.get("file", "")):
        return jsonify(error="Video is not ready."), 404
    return send_file(j["file"], as_attachment=True,
                     download_name="azcut-voiceover-video.mp4")


@app.get("/api/options")
def api_options():
    from capcut_sfx import list_sfx as _cc_list
    try:
        _cc = [{"id": "cc_" + i, "label": l, "cat": c} for i, l, c in _cc_list()]
    except Exception:
        _cc = []
    try:
        from capcut_filters import list_filters as _fl
        _filters = _fl()
    except Exception:
        _filters = []
    try:
        import json as _js
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "assets", "voices.json"), encoding="utf-8") as _vf:
            _voices = _js.load(_vf)
    except Exception:
        _voices = []
    return jsonify(
        transitions=TRANSITIONS, motions=MOTIONS, effects=EFFECTS,
        caption_styles=CAPTION_STYLES,
        caption_presets={k: v["label"] for k, v in CAPTION_PRESETS.items()},
        top_presets=TOP_PRESETS,
        preset_details={k: {kk: vv for kk, vv in v.items() if kk != "label"}
                        for k, v in CAPTION_PRESETS.items()},
        caption_fonts=CAPTION_FONTS, caption_grids=CAPTION_GRIDS,
        caption_anims=CAPTION_ANIMS,
        transcribe_models=TRANSCRIBE_MODELS,
        imggen_models=IMGGEN_MODELS, imggen_aspects=IMGGEN_ASPECTS,
        fal_models=FAL_MODELS, poll_models=POLLINATION_MODELS,
        image_styles={k: v[0] for k, v in IMAGE_STYLES.items()},
        sfx_kinds=SFX_KINDS_ALL,
        capcut_sfx=_cc,
        color_filters=_filters,
        voices=_voices,
        titlecard_themes={k: v["label"] for k, v in TITLECARD_THEMES.items()},
        aspects={k: {"w": w, "h": h} for k, (w, h) in ASPECTS.items()})


@app.get("/api/sfx/preview/<sid>")
def api_sfx_preview(sid):
    """v2.17: render any SFX kind to WAV for the library preview player."""
    from pipeline import synthesize_sfx, _write_wav_mono, SFX_SR
    kind = (sid or "").strip()
    if not valid_sfx_kind(kind):
        return jsonify(error="Unknown sound."), 404
    try:
        buf = synthesize_sfx(kind)
    except Exception as e:  # noqa: BLE001
        return jsonify(error=str(e)), 500
    if buf is None:
        return jsonify(error="Could not render sound."), 500
    safe = re.sub(r"[^a-z0-9_]+", "_", kind.lower())[:32] or "sfx"
    path = os.path.join(DATA, f"sfxprev_{safe}.wav")
    _write_wav_mono(path, buf, SFX_SR)
    return send_file(path, mimetype="audio/wav")


@app.post("/api/titlecard")
def api_titlecard():
    """Render a kinetic-typography title card to MP4 (doodle-video style)."""
    text = request.form.get("text", "").strip()
    theme = request.form.get("theme", "black-yellow")
    if theme not in TITLECARD_THEMES:
        theme = "black-yellow"
    try:
        duration = max(1.0, min(30.0, float(request.form.get("duration", 5))))
    except (ValueError, TypeError):
        duration = 5.0
    try:
        width = int(request.form.get("width", 1280))
        height = int(request.form.get("height", 720))
    except (ValueError, TypeError):
        width, height = 1280, 720
    if not text:
        return jsonify(error="Please write the card text first."), 400
    out = os.path.join(DATA, f"card_{uuid.uuid4().hex}.mp4")
    try:
        make_title_card(text, out, duration=duration, width=width,
                        height=height, theme=theme)
    except (CueError, RuntimeError) as e:
        return jsonify(error=str(e)), 400
    return send_file(out, as_attachment=True, download_name="titlecard.mp4")


@app.get("/api/stock/search")
def api_stock_search():
    """Search Pexels stock photos/videos (free API key)."""
    key = request.args.get("key", "")
    q = request.args.get("q", "")
    kind = request.args.get("kind", "photo")
    if kind not in ("photo", "video"):
        kind = "photo"
    try:
        page = max(1, int(request.args.get("page", 1)))
    except (ValueError, TypeError):
        page = 1
    try:
        return jsonify(pexels_search(key, q, kind, page))
    except PexelsError as e:
        return jsonify(error=str(e)), 400


@app.post("/api/stock/fetch")
def api_stock_fetch():
    """Download one Pexels file to the server and return it."""
    url = request.form.get("url", "")
    name = request.form.get("name", "stock")
    kind = request.form.get("kind", "photo")
    ext = "mp4" if kind == "video" else "jpg"
    safe = re.sub(r"[^a-zA-Z0-9_-]+", "_", name)[:40] or "stock"
    out = os.path.join(DATA, f"stock_{uuid.uuid4().hex[:8]}_{safe}.{ext}")
    try:
        pexels_download(url, out)
    except PexelsError as e:
        return jsonify(error=str(e)), 400
    return send_file(out, as_attachment=True,
                     download_name=f"{safe}.{ext}")


# ---------------- Auto Doodle Video ----------------



















@app.get("/api/recent")
def api_recent():
    """v2.19: recent rendered videos for the dashboard Recent Projects."""
    items = []
    try:
        import glob, time
        mp4s = sorted(glob.glob(os.path.join(DATA, "*.mp4")),
                      key=os.path.getmtime, reverse=True)
        for p in mp4s[:8]:
            if os.path.getsize(p) < 50000:
                continue
            mt = time.strftime("%d %b", time.localtime(os.path.getmtime(p)))
            # duration via ffprobe (best effort)
            dur = ""
            try:
                import subprocess, json as _j
                pr = subprocess.run(
                    ["ffprobe", "-v", "error", "-show_entries",
                     "format=duration", "-of", "json", p],
                    capture_output=True, text=True, timeout=10)
                dd = float(_j.loads(pr.stdout)["format"]["duration"])
                dur = f"{int(dd//60)}:{int(dd%60):02d}"
            except Exception:
                pass
            items.append({"name": os.path.splitext(os.path.basename(p))[0][:32],
                          "meta": f"Rendered {mt} • {dur}",
                          "dur": dur})
    except Exception:
        pass
    return jsonify(items=items)






@app.get("/api/version")
def api_version():
    out = {"app": "Az Cut", "version": PIPELINE_VERSION,
           "pipeline": PIPELINE_VERSION}
    # v2.20: update check — dashboard banner ke liye
    try:
        info = check_for_updates(PIPELINE_VERSION)
        if info.get("ok") and info.get("update_available"):
            out["update"] = info.get("latest_version", "").lstrip("v")
    except Exception:  # noqa: BLE001
        pass
    return jsonify(out)


# ---------------- API keys: disk persistence ----------------
# Keys are ALSO saved to a JSON file on disk, so they survive even if the
# embedded browser wipes localStorage (fresh profile). Saved only on this PC.
KEYS_FILE = os.path.join(DATA, "api_keys.json")
_KEY_NAMES = ("pixabay", "pexels", "gemini", "fal", "groq", "openrouter", "elevenlabs", "stability", "iconify")


def _load_keys():
    try:
        with open(KEYS_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return {k: str(d.get(k) or "") for k in _KEY_NAMES}
    except (OSError, ValueError):
        return {k: "" for k in _KEY_NAMES}


def _save_keys(d):
    clean = {k: str((d or {}).get(k) or "").strip() for k in _KEY_NAMES}
    try:
        os.makedirs(os.path.dirname(KEYS_FILE), exist_ok=True)
        tmp = KEYS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(clean, f)
        os.replace(tmp, KEYS_FILE)
    except Exception as e:
        print(f"[keys] save failed: {e}")
    return clean


def _groq_key(form=None):
    """v2.20: Groq key — form se ya saved keys se. Ek dafa lagao, har jagah kaam."""
    if form:
        k = (form.get("groq_key") or "").strip()
        if k:
            return k
    return (_load_keys().get("groq") or "").strip() or None


@app.get("/api/keys")
def api_keys_get():
    """Return saved API keys (so pages can restore them if localStorage is empty)."""
    return jsonify(_load_keys())


@app.post("/api/keys")
def api_keys_post():
    """Save API keys to disk. Body: {pixabay, pexels, gemini, fal}."""
    data = request.get_json(force=True, silent=True) or {}
    return jsonify(_save_keys(data))


@app.post("/api/audio")
def api_audio():
    f = request.files.get("audio")
    if not f or not f.filename:
        return jsonify(error="Please upload an audio file."), 400
    try:
        path = _save_upload(f, AUDIO_EXTS)
    except CueError as e:
        return jsonify(error=str(e)), 400
    model = request.form.get("model") or None
    if model not in TRANSCRIBE_MODELS:
        model = None
    # v2.25: language selection — Transcriber page se aati hai, pehle ignore
    # hoti thi (hamesha auto-detect). Sirf chhota code allow karo.
    _lang = (request.form.get("language") or "").strip().lower()
    language = _lang if re.fullmatch(r"[a-z]{2,3}", _lang or "") else None
    # v2.21 fix: groq key yahan se lo (request context mein), bg thread mein nahi
    keys = _load_keys()
    gkey = (request.form.get("groq_key") or keys.get("groq") or "").strip() or None
    audio_id = uuid.uuid4().hex
    audios[audio_id] = {"path": path, "status": "transcribing", "model": model,
                        "language": language,
                        "duration": _quick_duration(path)}
    threading.Thread(target=_transcribe_bg, args=(audio_id, gkey, language), daemon=True).start()
    return jsonify(audio_id=audio_id, duration=audios[audio_id]["duration"])


@app.get("/api/audio/<audio_id>")
def api_audio_status(audio_id):
    a = audios.get(audio_id)
    if not a:
        return jsonify(error="Audio not found."), 404
    out = {"status": a["status"]}
    if a.get("duration"):
        out["duration"] = a["duration"]
    if a["status"] == "ready":
        out.update(duration=a["result"]["duration"],
                   text=a["result"]["text"],
                   language=a["result"].get("language", ""),
                   words=a["result"]["words"])
    elif a["status"] == "error":
        out["error"] = a.get("error", "Transcription failed.")
    return jsonify(out)


@app.post("/api/cue-draft")
def api_cue_draft():
    data = request.get_json(force=True, silent=True) or {}
    a = audios.get(data.get("audio_id"))
    if not a or a["status"] != "ready":
        return jsonify(error="Please wait for transcription to finish."), 400
    count = max(1, min(50, int(data.get("count", 3))))
    return jsonify(cues=draft_cues(a["result"]["words"], count))


@app.post("/api/validate")
def api_validate():
    data = request.get_json(force=True, silent=True) or {}
    a = audios.get(data.get("audio_id"))
    if not a or a["status"] != "ready":
        return jsonify(error="Please wait for transcription to finish."), 400
    try:
        cues = parse_cues(data.get("cues", ""))
        starts = locate_cues(a["result"]["words"], cues)
    except CueError as e:
        return jsonify(ok=False, error=str(e))
    return jsonify(ok=True, cues=[
        {"img": n, "start": round(s, 2)} for (n, _), s in zip(cues, starts)
    ])


def _caption_opts(form):
    """Validate caption options from a form dict; return None if disabled."""
    if form.get("cap_on") != "1":
        return None

    def _int(key, default, lo, hi):
        try:
            return max(lo, min(hi, int(form.get(key, default))))
        except (ValueError, TypeError):
            return default

    def _color(key, default):
        v = (form.get(key) or "").strip()
        return v if re.match(r"^#[0-9a-fA-F]{6}$", v) else default

    opts = {
        "preset": form.get("cap_preset", "hormozi"),
        "cap_lang": form.get("cap_lang", "auto"),
        "font": form.get("cap_font", "Montserrat"),
        "size": _int("cap_size", 64, 20, 160),
        "bold": form.get("cap_bold", "1") == "1",
        "color": _color("cap_color", "#FFFFFF"),
        "hl": _color("cap_hl", "#FFE600"),
        "outline": _int("cap_outline", 2, 0, 8),
        "outline_color": _color("cap_oline", "#000000"),
        "shadow": _int("cap_shadow", 1, 0, 8),
        "glow": _color("cap_glow", "") or None,
        "grid": form.get("cap_grid", "bottom-center"),
        "dx": _int("cap_dx", 0, -600, 600),
        "dy": _int("cap_dy", 0, -400, 400),
        # v2.20: X%/Y% sliders (clipper + captions page)
        "pos_x": float(form.get("pos_x", 50) or 50),
        "pos_y": float(form.get("pos_y", 84) or 84),
        "wpl": _int("cap_wpl", 4, 1, 20),
        "lines": _int("cap_lines", 1, 1, 3),
        "spacing": _int("cap_spacing", 0, 0, 12),
        "karaoke": form.get("cap_karaoke", "spot"),
        "anim": form.get("cap_anim", "pop"),
        "uppercase": form.get("cap_upper") == "1",
        "box": form.get("cap_box") == "1",
        "aspect": form.get("cap_aspect") if form.get("cap_aspect") in ("source", "9:16", "16:9", "1:1") else "source",
        "fps": int(form.get("cap_fps") or 0) if str(form.get("cap_fps") or "0") in ("0", "24", "30", "60") else 0,
    }
    if opts["font"] not in CAPTION_FONTS:
        opts["font"] = "Montserrat"
    # v2.35: File Size & Compression (Export panel) -> x264 CRF
    _q = {"master": 16, "balanced": 21, "small": 27}.get(form.get("cap_quality") or "")
    if _q:
        opts["crf"] = _q
    # v2.39: Render Speed (Export panel) -> x264 preset
    _sp = form.get("cap_speed") or ""
    if _sp in ("medium", "fast", "veryfast", "superfast", "ultrafast"):
        opts["speed"] = _sp
    return opts
def _auto_arrange_media(image_paths, cue_texts):
    """v2.15 "Auto Both Clips Sync": match each media file to the script
    segment whose keywords overlap its filename best. No filename sorting —
    purely script-relevance driven; unmatched media fills remaining slots
    in upload order."""
    n = len(image_paths)
    if n < 2 or not cue_texts:
        return image_paths
    media_toks = []
    for p in image_paths:
        base = os.path.splitext(os.path.basename(p))[0]
        toks = set(t for t in re.findall(r"[a-z]+", base.lower()) if len(t) > 2)
        media_toks.append(toks)
    seg_kws = []
    for c in cue_texts:
        kws = set(extract_keywords(c, top_k=4))
        kws |= set(t for t in re.findall(r"[a-z]+", (c or "").lower())
                   if len(t) > 3)
        seg_kws.append(kws)
    used = [False] * n
    order = []
    for kws in seg_kws:
        best, best_score = -1, 0
        for j in range(n):
            if used[j]:
                continue
            score = len(kws & media_toks[j])
            if score > best_score:
                best, best_score = j, score
        if best < 0:
            best = next((j for j in range(n) if not used[j]), -1)
        if best < 0:
            break
        used[best] = True
        order.append(image_paths[best])
    for j in range(n):
        if not used[j]:
            order.append(image_paths[j])
    return order[:n]


@app.post("/api/studio/broll/plan")
def api_broll_plan():
    """v2.15: keywords + stock preview per script segment (no download yet)."""
    data = request.get_json(force=True, silent=True) or {}
    segments = data.get("segments") or []
    pixabay_key = (data.get("pixabay_key") or "").strip()
    if not segments:
        return jsonify(error="No script segments."), 400
    try:
        plan = broll_mod.plan_broll(pixabay_key, segments[:24])
    except Exception as e:  # noqa: BLE001
        return jsonify(error=f"B-roll plan failed: {e}"), 500
    return jsonify(plan=plan)


def _segment_texts(sync_mode, cues_text, cues):
    """Per-segment script text for B-roll / auto-arrange, in segment order."""
    if sync_mode in ("audio", "script-times"):
        return [(t or "") for _, t in cues]
    texts = []
    for line in (cues_text or "").splitlines():
        m = re.match(r"\[img\d+\]\s*\d+:\d+(?:\.\d+)?\s*(.*)", line.strip())
        texts.append((m.group(1) if m else "").strip())
    return texts


def _apply_broll(job_id, image_paths, starts, total, seg_texts,
                 width, height, broll, transition, broll_marked=None):
    """v2.15: replace segment visuals with Pixabay stock, add typewriter
    text overlays (ASS) + typing SFX. Returns (paths, ass_extra, sfx_extra)."""
    n = len(image_paths)
    density = broll.get("density", "every")
    style = broll.get("style", "smallcaps")
    if style not in broll_mod.TEXT_STYLES:
        style = "smallcaps"
    pos = broll.get("pos", "middle")
    cps = max(6, min(30, int(broll.get("cps", 14) or 14)))
    shake = bool(broll.get("shake", True))
    try:
        typing_vol = max(0.0, min(1.0, float(broll.get("typing_vol", 0.6))))
    except (ValueError, TypeError):
        typing_vol = 0.6
    pixabay_key = (broll.get("pixabay_key") or "").strip()
    kw_overrides = broll.get("kw_overrides") or {}
    tmpdir = os.path.join(DATA, f"{job_id}_broll")
    os.makedirs(tmpdir, exist_ok=True)
    # which segments get B-roll?
    targets = []
    for i in range(n):
        if density == "alternate" and i % 2 == 1:
            continue
        if density == "marked" and not (broll_marked and i < len(broll_marked)
                                        and broll_marked[i]):
            continue
        targets.append(i)
    # xfade overlap correction (mirrors build_video / build_sfx_track)
    T = 0.0
    if transition in TRANSITIONS and n > 1:
        b0 = [0.0] + list(starts[1:]) + [total]
        d0 = [b0[i + 1] - b0[i] for i in range(n)]
        if min(d0) > 0:
            T = min(0.5, min(d0) * 0.49)
            if T < 0.05:
                T = 0.0
    paths = list(image_paths)
    dlg_lines, sfx_extra = [], []
    for i in targets:
        raw = (seg_texts[i] if i < len(seg_texts) else "").strip()
        kw = (kw_overrides.get(str(i)) or "").strip()
        if not kw:
            kws = extract_keywords(raw, top_k=2)
            kw = " ".join(kws) if kws else ""
        if pixabay_key and kw:
            clip = broll_mod.fetch_broll_clip(pixabay_key, kw, tmpdir, idx=i)
            if clip:
                paths[i] = clip
        line = broll_mod.overlay_line(raw)
        if not line:
            continue
        t0 = max(0.0, starts[i] - T * i + 0.6)
        seg_end_raw = starts[i + 1] if i + 1 < n else total
        seg_end = max(t0 + 0.5, seg_end_raw - T * (i + 1))
        dlgs, type_dur = broll_mod.broll_dialogues(
            line, style, t0, seg_end, W=width, H=height,
            cps=cps, shake=shake, pos=pos)
        dlg_lines.extend(dlgs)
        if type_dur > 0.2:
            wav = broll_mod.typing_sfx_slice(
                type_dur, os.path.join(tmpdir, f"typing_{i}.wav"))
            if wav:
                sfx_extra.append((t0, wav, typing_vol))
    ass_extra = None
    if dlg_lines:
        ass_extra = (broll_mod.broll_ass(W=width, H=height), dlg_lines)
    return paths, ass_extra, (sfx_extra or None)


def _render_bg(job_id, audio_id, image_paths, cues_text, width, height,
               transition, motion, effect, captions, sfx_on, sfx_kind,
               sfx_vol, sync_mode, broll=None, auto_arrange=False,
               x264_preset="medium", intro_on=False, adjustments=None,
               color_filter="", groq_key=None):
    try:
        jobs[job_id]["status"] = "building"
        # v2.15: remember [b] B-roll markers, then strip before cue parsing
        broll_marked = None
        if broll and broll.get("on"):
            broll_marked = [("[b]" in ln)
                            for ln in (cues_text or "").splitlines() if ln.strip()]
            cues_text = (cues_text or "").replace("[b]", "")
        a = audios[audio_id]
        if len(image_paths) < 1:
            raise CueError("Please add at least 1 image.")
        if sync_mode in ("timestamps", "script-times"):
            # user-supplied times: no transcription needed.
            # "timestamps": [imgN] m:ss markers; "script-times": script
            # lines starting with m:ss, images follow in order.
            if sync_mode == "timestamps":
                cues = parse_cue_times(cues_text)
                starts = [t for _, t in cues]
                n = len(cues)
            else:
                cues = parse_script_times(cues_text)
                starts = [t for t, _ in cues]
                n = len(cues)
            if n != len(image_paths):
                raise CueError(
                    f"Script sections ({n}) and images ({len(image_paths)}) "
                    "must be equal in number.")
            if a["status"] == "ready":
                total = a["result"]["duration"]
                words = a["result"]["words"]
            else:
                total = audio_duration(a["path"])
                words = []
        else:
            if a["status"] != "ready":
                raise CueError("Please wait for transcription to finish.")
            cues = parse_cues(cues_text)
            if len(cues) != len(image_paths):
                raise CueError(
                    f"Cues ({len(cues)}) and images ({len(image_paths)}) "
                    "must be equal in number.")
            starts = locate_cues(a["result"]["words"], cues)
            total = a["result"]["duration"]
            words = a["result"]["words"]
        if starts[-1] >= total:
            raise CueError("The last cue is beyond the audio length.")
        # --- v2.15: Auto Both Clips Sync (script-relevance media order) ---
        seg_texts = _segment_texts(sync_mode, cues_text, cues)
        if auto_arrange:
            image_paths = _auto_arrange_media(image_paths, seg_texts)
        # --- v2.15: B-roll (stock footage + typewriter text + typing SFX) ---
        ass_extra, sfx_extra = None, None
        if broll and broll.get("on"):
            image_paths, ass_extra, sfx_extra = _apply_broll(
                job_id, image_paths, starts, total, seg_texts,
                width, height, broll, transition, broll_marked)
        out = os.path.join(DATA, f"{job_id}.mp4")
        info = build_video(a["path"], image_paths, starts, out,
                           total_duration=total,
                           width=width, height=height,
                           transition=transition, motion=motion,
                           effect=effect, captions=captions,
                           words=words, sfx_on=sfx_on,
                           sfx_kind=sfx_kind, sfx_vol=sfx_vol,
                           ass_extra=ass_extra, sfx_extra=sfx_extra,
                           x264_preset=x264_preset, adjustments=adjustments,
                           color_filter=color_filter)
        # v2.16: silent AZ Studio intro prepended (no music, no voice)
        if intro_on:
            idur = prepend_intro(out, width, height)
            if idur > 0:
                info["durations"] = [idur] + info["durations"]
        jobs[job_id].update(status="done", durations=info["durations"])
    except (CueError, RuntimeError) as e:
        jobs[job_id].update(status="error", error=str(e))
    except FileNotFoundError:
        jobs[job_id].update(status="error", error="FFmpeg was not found. "
                            "Please reinstall Az Cut, or install FFmpeg on "
                            "this PC and restart the app.")
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=f"Unexpected error: {e}")


@app.post("/api/render")
def api_render():
    audio_id = request.form.get("audio_id")
    cues_text = request.form.get("cues", "")
    sync_mode = request.form.get("sync_mode", "audio")
    if sync_mode not in ("audio", "timestamps", "script-times"):
        sync_mode = "audio"
    a = audios.get(audio_id)
    if not a:
        return jsonify(error="Please upload audio first."), 400
    if sync_mode == "audio" and a["status"] != "ready":
        return jsonify(error="Please wait for transcription to finish."), 400
    files = [f for f in request.files.getlist("images") if f.filename]
    if not files:
        return jsonify(error="Please add at least 1 image."), 400
    try:
        width = int(request.form.get("width", 1280))
        height = int(request.form.get("height", 720))
    except ValueError:
        width, height = 1280, 720
    if (width, height) not in [(w, h) for w, h in ASPECTS.values()]:
        width, height = 1280, 720
    try:
        image_paths = [_save_upload(f, IMAGE_EXTS) for f in files]
    except CueError as e:
        return jsonify(error=str(e)), 400
    transition = request.form.get("transition", "none")
    motion = request.form.get("motion", "none")
    effect = request.form.get("effect", "none")
    if transition not in TRANSITIONS:
        transition = "none"
    if motion not in MOTIONS:
        motion = "none"
    if effect not in EFFECTS:
        effect = "none"
    captions = _caption_opts(request.form)
    sfx_on = request.form.get("sfx_on", "1") == "1"
    sfx_kind = request.form.get("sfx_kind") or None
    if not valid_sfx_kind(sfx_kind):
        sfx_kind = None
    try:
        sfx_vol = max(0.0, min(1.0, float(request.form.get("sfx_vol", 0.5))))
    except (ValueError, TypeError):
        sfx_vol = 0.5
    # --- v2.15: B-roll + auto-arrange + export speed ---
    auto_arrange = request.form.get("auto_arrange", "0") == "1"
    export_speed = request.form.get("export_speed", "best")
    x264_preset = "veryfast" if export_speed == "fast" else "medium"
    intro_on = request.form.get("intro_on", "0") == "1"  # v2.16: silent intro
    # v2.17: CapCut-style adjustments (adj_<name> = -100..100)
    from pipeline import ADJUSTMENTS as _ADJ
    adjustments = {}
    for _an, _ in _ADJ:
        try:
            adjustments[_an] = max(-100, min(100, int(request.form.get("adj_" + _an, 0) or 0)))
        except (ValueError, TypeError):
            adjustments[_an] = 0
    if not any(adjustments.values()):
        adjustments = None
    # v2.17: color filter name -> ffmpeg string
    from capcut_filters import ffmpeg_for as _ff_for
    color_filter = _ff_for(request.form.get("color_filter", ""))
    broll = None
    if request.form.get("broll_on", "0") == "1":
        kw_overrides = {}
        for k in request.form:
            if k.startswith("broll_kw_"):
                kw_overrides[k[len("broll_kw_"):]] = request.form.get(k, "")
        broll = {
            "on": True,
            "density": request.form.get("broll_density", "every"),
            "style": request.form.get("broll_style", "smallcaps"),
            "pos": request.form.get("broll_pos", "middle"),
            "cps": request.form.get("broll_cps", "14"),
            "shake": request.form.get("broll_shake", "1") == "1",
            "typing_vol": request.form.get("broll_typing_vol", "0.6"),
            "pixabay_key": request.form.get("pixabay_key", ""),
            "kw_overrides": kw_overrides,
        }
        if broll["density"] not in ("every", "alternate", "marked"):
            broll["density"] = "every"
        if broll["pos"] not in ("top", "middle", "bottom"):
            broll["pos"] = "middle"
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued"}
    threading.Thread(target=_render_bg,
                     args=(job_id, audio_id, image_paths, cues_text, width,
                           height, transition, motion, effect, captions,
                           sfx_on, sfx_kind, sfx_vol, sync_mode,
                           broll, auto_arrange, x264_preset, intro_on,
                           adjustments, color_filter, _groq_key()),
                     daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/render/<job_id>")
def api_job(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Job not found."), 404
    return jsonify(j)


@app.get("/api/render/<job_id>/cues")
def api_cues(job_id):
    """Caption cue segments [start, end, text] for the pro-dashboard timeline."""
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Job not found."), 404
    if j.get("status") != "done":
        return jsonify(error="Captions are not ready yet."), 404
    return jsonify(cues=j.get("cues", []))


@app.get("/api/render/<job_id>/preview")
def api_preview(job_id):
    j = jobs.get(job_id)
    if not j or j["status"] != "done":
        return jsonify(error="Video is not ready yet."), 404
    return send_file(os.path.join(DATA, f"{job_id}.mp4"), mimetype="video/mp4")


@app.get("/api/render/<job_id>/download")
def api_download(job_id):
    j = jobs.get(job_id)
    if not j or j["status"] != "done":
        return jsonify(error="Video is not ready yet."), 404
    return send_file(os.path.join(DATA, f"{job_id}.mp4"),
                     as_attachment=True, download_name="azcut-video.mp4")


# ---------------- Phase 1 tools: transcriber export, captions, clipper -------

@app.post("/api/translate")
def api_translate():
    """Translate text to any language.

    v2.31 fix: pehle (v2.19.1) poora text EK hi request mein jata tha —
    lambay transcript par Google ki free service foran "429 Too Many
    Requests" de deti thi, koi chunking/retry nahi thi, aur khamkha ki
    4000-char limit bhi thi. Ab pipeline ka saaz istemal hota hai:
    Groq key ho to pehle woh (fast, bina rate-limit ke), warna Google
    chunked tarjuma har chunk par backoff-retry ke sath. Phir bhi fail
    ho to user ko saaf wajah wala message milta hai, kham "HTTP Error"
    nahi.
    """
    d = request.get_json(force=True, silent=True) or {}
    text = (d.get("text") or "").strip()
    target = (d.get("target") or "ur").strip().lower()
    if not text:
        return jsonify(error="No text to translate."), 400
    if len(text) > 20000:  # poora transcript bhi aa jaye; is se zyada truncate
        text = text[:20000]
    from pipeline import _translate_text_google_full, _translate_text_groq
    translated, detected = "", "auto"
    gkey = _groq_key()
    if gkey:
        try:
            translated = _translate_text_groq(text, target, gkey) or ""
        except Exception:  # noqa: BLE001
            translated = ""
    if not translated:
        try:
            translated, detected = _translate_text_google_full(text, target)
        except Exception:  # noqa: BLE001
            translated = ""
    if not translated:
        return jsonify(error="Translation failed. Google's free translation service is "
                             "temporarily rate-limited (HTTP 429). Please wait a "
                             "minute and try again, or add a free Groq API key "
                             "under API Keys for instant translation without "
                             "interruptions."), 502
    return jsonify(translated=translated, detected=detected, target=target)


@app.post("/api/brolls/collect")
def api_brolls_collect():
    """v2.20 B-Rolls Collector: script -> scenes -> stock footage per scene."""
    from brolls import split_scenes, collect_footage
    d = request.get_json(force=True, silent=True) or {}
    script = (d.get("script") or "").strip()
    if not script:
        return jsonify(error="Please paste your script first."), 400
    if len(script.split()) < 10:
        return jsonify(error="Script is too short — need at least 10 words."), 400
    keys = _load_keys()
    pixabay_key = keys.get("pixabay") or ""
    pexels_key = keys.get("pexels") or ""
    if not pixabay_key and not pexels_key:
        return jsonify(error="Add a Pixabay or Pexels API key first (dashboard → API Keys)."), 400
    scenes = split_scenes(script, max_scenes=12)
    if not scenes:
        return jsonify(error="Could not split script into scenes."), 400
    try:
        scenes = collect_footage(scenes, pixabay_key=pixabay_key,
                                 pexels_key=pexels_key, per_scene=4)
    except Exception as e:
        return jsonify(error=f"Footage search failed: {e}"), 502
    return jsonify(
        topic=d.get("topic", ""),
        content_type=d.get("content_type", ""),
        scenes=[{
            "n": i + 1,
            "text": s["text"],
            "keywords": s["keywords"],
            "query": s["query"],
            "clips": s["clips"],
        } for i, s in enumerate(scenes)],
    )


@app.post("/api/brolls/download")
def api_brolls_download():
    """v2.20: download selected clips as a ZIP."""
    import io, zipfile, urllib.request
    d = request.get_json(force=True, silent=True) or {}
    clips = d.get("clips") or []  # [{"url","name"}]
    if not clips:
        return jsonify(error="No clips selected."), 400
    if len(clips) > 24:
        return jsonify(error="Max 24 clips per ZIP."), 400
    buf = io.BytesIO()
    allowed = ("cdn.pixabay.com", "videos.pexels.com", "player.vimeo.com",
               "images.pexels.com")
    try:
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for i, c in enumerate(clips):
                url = c.get("url") or ""
                host = urllib.parse.urlparse(url).hostname or ""
                if not any(host.endswith(a) for a in allowed):
                    continue
                name = re.sub(r"[^A-Za-z0-9_.-]", "_",
                              c.get("name") or f"clip_{i+1}.mp4")[:60]
                req = urllib.request.Request(
                    url, headers={"User-Agent": "AzCut/2.20"})
                with urllib.request.urlopen(req, timeout=300) as r:
                    zf.writestr(name, r.read())
    except Exception as e:
        return jsonify(error=f"Download failed: {e}"), 502
    buf.seek(0)
    return send_file(buf, mimetype="application/zip",
                     as_attachment=True, download_name="brolls.zip")


@app.get("/api/audio/<audio_id>/export")
def api_export(audio_id):
    a = audios.get(audio_id)
    if not a or a["status"] != "ready":
        return jsonify(error="Please wait for transcription to finish."), 400
    fmt = request.args.get("format", "srt").lower()
    words = a["result"]["words"]
    converters = {"srt": words_to_srt, "txt": words_to_txt,
                  "vtt": words_to_vtt, "stamped": words_to_stamped}
    names = {"srt": "transcript.srt", "txt": "transcript.txt",
             "vtt": "transcript.vtt",
             "stamped": "script-with-timestamps.txt"}
    if fmt not in converters:
        fmt = "srt"
    data, name = converters[fmt](words), names[fmt]
    path = os.path.join(DATA, f"{audio_id}.{fmt}")
    with open(path, "w", encoding="utf-8") as f:
        f.write(data)
    return send_file(path, as_attachment=True, download_name=name)


def _caption_bg(job_id, video_path, opts, model, groq_key=None):
    try:
        jobs[job_id]["status"] = "building"
        out = os.path.join(DATA, f"{job_id}.mp4")
        info = burn_captions(video_path, out, opts, model=model,
                             groq_key=groq_key or _groq_key())
        jobs[job_id].update(status="done", words=info["words"],
                            cues=info.get("cues", []),
                            warning=info.get("translation_warning", ""),
                            language=info.get("language", ""))
        # cache words for fast re-burn (new style, no re-transcribe)
        # v2.26: ORIGINAL words bhi cache karo — re-burn translation
        # hamesha original se hogi, translated ke upar translated nahi.
        _caption_words[job_id] = {"words": info.get("words_list", []),
                                  "orig_words": info.get("orig_words_list",
                                                         info.get("words_list", [])),
                                  "orig_language": info.get("orig_language",
                                                            info.get("language", "")),
                                  "language": info.get("language", ""),
                                  "video_path": video_path}
        _cap_cache_trim()
    except (CueError, RuntimeError) as e:
        jobs[job_id].update(status="error", error=str(e))
    except FileNotFoundError:
        jobs[job_id].update(status="error", error="FFmpeg was not found. "
                            "Please reinstall Az Cut, or install FFmpeg on "
                            "this PC and restart the app.")
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=f"Unexpected error: {e}")


def _caption_reburn_bg(job_id, src, opts):
    """Re-burn captions with new style using cached words (no transcription)."""
    try:
        jobs[job_id]["status"] = "building"
        out = os.path.join(DATA, f"{job_id}.mp4")
        # v2.26 fix: (1) groq_key pass hi nahi hota tha — re-burn par
        # language badalna kabhi kaam hi nahi karta tha. (2) Ab ORIGINAL
        # words se burn hoga taake nayi selected language saaf translate ho.
        orig_words = src.get("orig_words") or src["words"]
        orig_lang = src.get("orig_language") or src["language"]
        info = burn_captions(src["video_path"], out, opts,
                             words=[dict(w) for w in orig_words],
                             language=orig_lang, groq_key=_groq_key())
        jobs[job_id].update(status="done", words=info["words"],
                            cues=info.get("cues", []),
                            warning=info.get("translation_warning", ""),
                            language=info.get("language", ""))
        _caption_words[job_id] = {"words": info.get("words_list", []),
                                  "orig_words": orig_words,
                                  "orig_language": orig_lang,
                                  "language": info.get("language", ""),
                                  "video_path": src["video_path"]}
        _cap_cache_trim()
    except (CueError, RuntimeError) as e:
        jobs[job_id].update(status="error", error=str(e))
    except FileNotFoundError:
        jobs[job_id].update(status="error", error="FFmpeg was not found. "
                            "Please reinstall Az Cut, or install FFmpeg on "
                            "this PC and restart the app.")
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=f"Unexpected error: {e}")


@app.post("/api/caption/reburn")
def api_caption_reburn():
    """Re-burn captions with a new style — reuses cached transcription."""
    data = request.get_json(force=True, silent=True) or {}
    src = _caption_words.get(data.get("job_id"))
    if not src or not src.get("words"):
        return jsonify(error="Please run ⚡ One-Click Captions first, then re-burn."), 400
    if not os.path.exists(src["video_path"]):
        return jsonify(error="The video file was not found. Please upload it again and run One-Click Captions."), 400
    form = dict(data.get("opts") or {})
    form["cap_on"] = "1"
    opts = _caption_opts(form)
    if opts is None:
        return jsonify(error="The style options could not be understood."), 400
    # v2.35: Cues editor se edited words (text badla / cue delete) — yehi
    # words ab is burn ka base hain aur cache mein bhi yehi save honge.
    src = dict(src)
    ew = data.get("edited_words")
    if isinstance(ew, list) and ew:
        clean = []
        for w in ew[:20000]:
            try:
                clean.append({"word": str(w["word"]),
                              "start": float(w["start"]),
                              "end": float(w["end"])})
            except (KeyError, TypeError, ValueError):
                continue
        clean = [w for w in clean if w["end"] > w["start"] >= 0]
        if clean:
            src["orig_words"] = clean
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "caption-reburn"}
    threading.Thread(target=_caption_reburn_bg,
                     args=(job_id, src, opts), daemon=True).start()
    return jsonify(job_id=job_id)


@app.post("/api/caption")
def api_caption():
    f = request.files.get("video")
    if not f or not f.filename:
        return jsonify(error="Please upload a video file."), 400
    try:
        video_path = _save_upload(f, VIDEO_EXTS)
    except CueError as e:
        return jsonify(error=str(e)), 400
    form = dict(request.form)
    form["cap_on"] = "1"  # captions always on for this tool
    opts = _caption_opts(form)
    model = form.get("model") or None
    if model not in TRANSCRIBE_MODELS:
        model = None
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "caption"}
    threading.Thread(target=_caption_bg, args=(job_id, video_path, opts, model),
                     daemon=True).start()
    return jsonify(job_id=job_id)


def _job_error(job_id, e):
    if isinstance(e, (CueError, RuntimeError)):
        jobs[job_id].update(status="error", error=str(e))
    else:
        jobs[job_id].update(status="error", error=f"Unexpected error: {e}")


def _caption_preview_bg(job_id, video_path, opts, model):
    try:
        jobs[job_id]["status"] = "building"
        out = os.path.join(DATA, f"{job_id}.mp4")
        info = preview_caption_clip(video_path, out, opts, model=model, groq_key=_groq_key())
        jobs[job_id].update(status="done", language=(info or {}).get("language", ""),
                            warning=(info or {}).get("translation_warning", ""))
    except Exception as e:  # noqa: BLE001
        _job_error(job_id, e)


@app.post("/api/caption-preview")
def api_caption_preview():
    """Burn captions on a 5s sample of the uploaded video (live preview)."""
    f = request.files.get("video")
    if not f or not f.filename:
        return jsonify(error="Please upload a video file."), 400
    try:
        video_path = _save_upload(f, VIDEO_EXTS)
    except CueError as e:
        return jsonify(error=str(e)), 400
    form = dict(request.form)
    form["cap_on"] = "1"
    opts = _caption_opts(form)
    model = form.get("model") or None
    if model not in TRANSCRIBE_MODELS:
        model = None
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "caption-preview"}
    threading.Thread(target=_caption_preview_bg,
                     args=(job_id, video_path, opts, model), daemon=True).start()
    return jsonify(job_id=job_id)


def _studio_preview_bg(job_id, audio_id, image_path, opts):
    try:
        jobs[job_id]["status"] = "building"
        a = audios.get(audio_id)
        if not a or a["status"] != "ready":
            raise CueError("Please wait for transcription to finish first.")
        out = os.path.join(DATA, f"{job_id}.mp4")
        preview_studio_clip(a["path"], image_path, out, opts,
                            a["result"]["words"])
        jobs[job_id].update(status="done")
    except Exception as e:  # noqa: BLE001
        _job_error(job_id, e)


@app.post("/api/studio-preview")
def api_studio_preview():
    """Render a 5s studio sample (first image + start of audio) with captions."""
    audio_id = request.form.get("audio_id")
    a = audios.get(audio_id)
    if not a:
        return jsonify(error="Please upload audio first."), 400
    f = request.files.get("image")
    if not f or not f.filename:
        return jsonify(error="Please pick one image for the preview."), 400
    try:
        image_path = _save_upload(f, IMAGE_EXTS)
    except CueError as e:
        return jsonify(error=str(e)), 400
    form = dict(request.form)
    form["cap_on"] = "1"
    opts = _caption_opts(form)
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "studio-preview"}
    threading.Thread(target=_studio_preview_bg,
                     args=(job_id, audio_id, image_path, opts), daemon=True).start()
    return jsonify(job_id=job_id)


def _autoclip_bg(job_id, video_path, n_clips, clip_dur, cam, cap_opts, model,
                 groq_key=None):
    try:
        jobs[job_id]["status"] = "building"
        out_dir = os.path.join(DATA, job_id)
        os.makedirs(out_dir, exist_ok=True)
        paths = make_auto_clips(video_path, out_dir, n_clips=n_clips,
                                clip_dur=clip_dur, cam=cam,
                                captions=cap_opts, model=model,
                                groq_key=groq_key or _groq_key())
        jobs[job_id].update(status="done", clips=paths)
    except Exception as e:  # noqa: BLE001
        _job_error(job_id, e)


@app.post("/api/autoclip")
def api_autoclip():
    """Find the most engaging clips (any language) and cut them to 9:16."""
    f = request.files.get("video")
    if not f or not f.filename:
        return jsonify(error="Please upload a video file."), 400
    try:
        video_path = _save_upload(f, VIDEO_EXTS)
    except CueError as e:
        return jsonify(error=str(e)), 400
    try:
        n_clips = max(1, min(10, int(request.form.get("n_clips", 3))))
        clip_dur = max(10, min(120, int(request.form.get("clip_dur", 30))))
    except ValueError:
        return jsonify(error="Invalid clip settings."), 400
    cam = request.form.get("cam") or "face"
    if cam not in ("face", "center"):
        cam = "face"
    cap_opts = None
    if request.form.get("cap_on") == "1":
        form = dict(request.form)
        cap_opts = _caption_opts(form)
    model = request.form.get("model") or None
    if model not in TRANSCRIBE_MODELS:
        model = None
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "autoclip"}
    threading.Thread(target=_autoclip_bg,
                     args=(job_id, video_path, n_clips, clip_dur, cam,
                           cap_opts, model), daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/clips/<job_id>")
def api_clips_status(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Unknown job."), 404
    out = {"status": j["status"], "kind": j.get("kind")}
    if j["status"] == "done":
        out["clips"] = list(range(1, len(j.get("clips", [])) + 1))
    if j["status"] == "error":
        out["error"] = j.get("error")
    return jsonify(out)


@app.get("/api/clips/<job_id>/<int:n>/preview")
def api_clip_preview(job_id, n):
    j = jobs.get(job_id)
    clips = (j or {}).get("clips") or []
    if not (1 <= n <= len(clips)) or not os.path.exists(clips[n - 1]):
        return jsonify(error="Clip not found."), 404
    return send_file(clips[n - 1], mimetype="video/mp4")


@app.get("/api/clips/<job_id>/download")
def api_clips_download(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Job not found."), 404
    clips = j.get("clips") or []
    if j["status"] != "done" or not clips:
        return jsonify(error="Clips are not ready yet."), 400
    import zipfile
    zpath = os.path.join(DATA, f"clips_{job_id}.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for i, p in enumerate(clips, 1):
            z.write(p, f"clip{i}.mp4")
    return send_file(zpath, as_attachment=True,
                     download_name="azcut_clips.zip")


def _clipper_bg(job_id, video_path):
    try:
        jobs[job_id]["status"] = "building"
        out = os.path.join(DATA, f"{job_id}.mp4")
        info = reframe_916(video_path, out)
        jobs[job_id].update(status="done", faces=info["faces"])
    except (CueError, RuntimeError) as e:
        jobs[job_id].update(status="error", error=str(e))
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=f"Unexpected error: {e}")


@app.post("/api/clipper")
def api_clipper():
    f = request.files.get("video")
    if not f or not f.filename:
        return jsonify(error="Please upload a video file."), 400
    try:
        video_path = _save_upload(f, VIDEO_EXTS)
    except CueError as e:
        return jsonify(error=str(e)), 400
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "clipper"}
    threading.Thread(target=_clipper_bg, args=(job_id, video_path),
                     daemon=True).start()
    return jsonify(job_id=job_id)


def _imggen_bg(job_id, api_key, prompts_text, aspect, model, provider):
    try:
        jobs[job_id]["status"] = "building"
        prompts = parse_bulk_prompts(prompts_text)
        out_dir = os.path.join(DATA, job_id)
        os.makedirs(out_dir, exist_ok=True)

        def prog(i, n):
            jobs[job_id].update(doing=f"{i}/{n}")

        paths, failed = bulk_generate(api_key, prompts, out_dir, aspect=aspect,
                                      model=model, progress=prog,
                                      provider=provider)
        jobs[job_id].update(status="done", images=paths, failed=failed)
    except Exception as e:  # noqa: BLE001
        _job_error(job_id, e)


@app.post("/api/transcribe-youtube")
def api_transcribe_youtube():
    """Download a YouTube video's audio with yt-dlp and transcribe it.

    YouTube now frequently demands a sign-in check, so several download
    methods are tried in order: standard, alternate player clients, then
    cookies from the user's own browsers (Chrome, Edge, Firefox).
    """
    data = request.get_json(force=True, silent=True) or {}
    url = (data.get("url") or "").strip()
    lang = (data.get("language") or "").strip() or None
    if not url or ("youtube.com" not in url and "youtu.be" not in url):
        return jsonify(error="Please paste a valid YouTube link."), 400
    try:
        from yt_dlp import YoutubeDL
    except ImportError:
        return jsonify(error="The yt-dlp component is missing. Please reinstall the app."), 500
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "yt-transcribe",
                    "doing": "Starting download..."}
    gkey = _groq_key()

    def _attempt(out_tmpl, extra):
        opts = {"format": "bestaudio[ext=m4a]/bestaudio/best",
                "outtmpl": out_tmpl, "quiet": True, "no_warnings": True,
                "socket_timeout": 30, "retries": 3}
        opts.update(extra)
        try:
            import certifi
            if not hasattr(certifi, "where"):
                import ssl as _ssl
                certifi.where = lambda: _ssl.get_default_verify_paths().cafile
        except Exception:
            pass
        with YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
            return ydl.prepare_filename(info), info

    def _bg():
        attempts = [
            ("Downloading audio from YouTube...", {}),
            ("Retrying with an alternate playback method...",
             {"extractor_args": {"youtube": {"player_client": ["android", "ios"]}}}),
            ("Trying with your Chrome sign-in...",
             {"cookiesfrombrowser": ("chrome",)}),
            ("Trying with your Edge sign-in...",
             {"cookiesfrombrowser": ("edge",)}),
            ("Trying with your Firefox sign-in...",
             {"cookiesfrombrowser": ("firefox",)}),
        ]
        try:
            jobs[job_id]["status"] = "downloading"
            out_base = os.path.join(DATA, f"yt_{job_id}")
            dl_path = info = None
            last_err = None
            for label, extra in attempts:
                jobs[job_id]["doing"] = label
                try:
                    dl_path, info = _attempt(out_base + ".%(ext)s", extra)
                    break
                except Exception as e:  # noqa: BLE001
                    last_err = e
            if not dl_path:
                raise RuntimeError(
                    "YouTube refused the download. It now requires a sign-in "
                    "check for most videos. Please sign in to YouTube in "
                    "Chrome, Edge or Firefox on this PC, close the browser, "
                    "and try again. Alternatively, download the audio with "
                    "any other tool and use the file upload option above. "
                    f"(Details: {str(last_err)[:160]})")
            jobs[job_id]["status"] = "transcribing"
            jobs[job_id]["doing"] = "Transcribing audio..."
            result = transcribe(dl_path, groq_key=gkey, language=lang)
            jobs[job_id].update(status="done", result=result,
                                title=(info or {}).get("title", ""))
            try:
                os.remove(dl_path)
            except OSError:
                pass
        except Exception as e:  # noqa: BLE001
            jobs[job_id].update(status="error", error=str(e))

    threading.Thread(target=_bg, daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/job/<job_id>")
def api_job_status(job_id):
    """v2.22: Generic job status (YouTube transcribe etc)."""
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Job not found."), 404
    return jsonify(j)


@app.post("/api/summarize")
def api_summarize():
    """v2.22: Transcription ka AI summary (OpenRouter)."""
    data = request.get_json(force=True, silent=True) or {}
    text = (data.get("text") or "").strip()
    if not text:
        return jsonify(error="No text was provided."), 400
    key = (_load_keys().get("openrouter") or "").strip()
    if not key:
        return jsonify(error="Please add your OpenRouter API key on the dashboard."), 400
    import urllib.request, json as _json
    prompt = ("Is transcription ka khulasa banao:\n\n1. **Summary** (2-3 lines)\n"
              "2. **Key Points** (bullet points)\n3. **Action Items** (agar hon)\n\nText:\n" + text[:4000])
    body = _json.dumps({
        "model": "meta-llama/llama-3.3-70b-instruct:free",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 800}).encode()
    try:
        req = urllib.request.Request(
            "https://openrouter.ai/api/v1/chat/completions", data=body,
            headers={"Authorization": f"Bearer {key}",
                     "Content-Type": "application/json",
                     "HTTP-Referer": "https://azcut.app",
                     "User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=60) as r:
            d = _json.loads(r.read().decode())
        summary = d["choices"][0]["message"]["content"]
        return jsonify(summary=summary)
    except Exception as e:
        return jsonify(error=str(e)[:200]), 500


@app.post("/api/brolls/yt-clips")
def api_brolls_yt_clips():
    """v2.22: YouTube video se 6-sec 1080p clips nikalo."""
    data = request.get_json(force=True, silent=True) or {}
    url = (data.get("url") or "").strip()
    if not url or ("youtube.com" not in url and "youtu.be" not in url):
        return jsonify(error="Please paste a YouTube link."), 400
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "yt-clips", "clips": []}
    def _bg():
        try:
            from yt_dlp import YoutubeDL
            jobs[job_id]["status"] = "downloading"
            workdir = os.path.join(DATA, f"ytc_{job_id}")
            os.makedirs(workdir, exist_ok=True)
            vpath = os.path.join(workdir, "video.mp4")
            ydl_opts = {"format": "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/best[height<=1080]",
                        "outtmpl": vpath.replace(".mp4", ".%(ext)s"),
                        "quiet": True, "no_warnings": True,
                        "merge_output_format": "mp4",
                        "nocheckcertificate": True}
            # v2.24 fix: certifi may be broken in bundle — patch it
            try:
                import certifi
                if not hasattr(certifi, 'where'):
                    import ssl as _ssl
                    certifi.where = lambda: _ssl.get_default_verify_paths().cafile
            except Exception:
                pass
            with YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
            # Find downloaded file
            for f in os.listdir(workdir):
                if f.startswith("video."):
                    vpath = os.path.join(workdir, f)
                    break
            # Get duration
            import subprocess as _sp, json as _js
            pr = _sp.run(["ffprobe", "-v", "error", "-show_entries",
                          "format=duration", "-of", "json", vpath],
                         capture_output=True, text=True)
            dur = float(_js.loads(pr.stdout)["format"]["duration"])
            # 6-sec clips
            n = int(dur // 6)
            jobs[job_id]["status"] = f"cutting {n} clips"
            clips = []
            for i in range(n):
                cpath = os.path.join(workdir, f"clip_{i+1:02d}.mp4")
                _sp.run(["ffmpeg", "-y", "-v", "error", "-ss", str(i*6),
                         "-i", vpath, "-t", "6", "-c:v", "libx264",
                         "-preset", "ultrafast", "-c:a", "aac", cpath],
                        capture_output=True)
                if os.path.exists(cpath):
                    clips.append({"i": i+1, "path": cpath,
                                  "start": i*6, "url": f"/api/brolls/yt-clips/{job_id}/{i+1}"})
            jobs[job_id].update(status="done", clips=clips,
                                total=n, duration=dur, workdir=workdir)
        except Exception as e:
            jobs[job_id].update(status="error", error=str(e)[:200])
    threading.Thread(target=_bg, daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/brolls/yt-clips/<job_id>/<int:idx>")
def api_brolls_yt_clip_file(job_id, idx):
    j = jobs.get(job_id)
    if not j or j.get("kind") != "yt-clips":
        return jsonify(error="Not found."), 404
    for c in j.get("clips", []):
        if c["i"] == idx and os.path.exists(c["path"]):
            return send_file(c["path"], mimetype="video/mp4")
    return jsonify(error="Clip not found."), 404


@app.post("/api/brolls/yt-clips/filter")
def api_brolls_yt_filter():
    """v2.22: Sirf personality wale clips rakho (face detection)."""
    data = request.get_json(force=True, silent=True) or {}
    job_id = data.get("job_id", "")
    j = jobs.get(job_id)
    if not j or j.get("kind") != "yt-clips":
        return jsonify(error="Job not found."), 404
    try:
        import cv2
        import subprocess as _sp
    except ImportError:
        return jsonify(error="OpenCV is not installed."), 500
    face_cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    kept = []
    for c in j.get("clips", []):
        # Middle frame nikalo
        tmp = c["path"] + ".thumb.jpg"
        _sp.run(["ffmpeg", "-y", "-v", "error", "-ss", "3",
                 "-i", c["path"], "-vframes", "1", tmp],
                capture_output=True)
        has_face = False
        if os.path.exists(tmp):
            img = cv2.imread(tmp)
            if img is not None:
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                faces = face_cascade.detectMultiScale(gray, 1.3, 5)
                has_face = len(faces) > 0
            try: os.remove(tmp)
            except OSError: pass
        if has_face:
            kept.append(c)
    j["clips"] = kept
    j["filtered"] = True
    return jsonify(kept=len(kept), total=len(j.get("clips", [])) + 0)


@app.get("/api/brolls/yt-clips/<job_id>/download-zip")
def api_brolls_yt_zip(job_id):
    """v2.22: Filtered clips ko ZIP mein download karo (timecode names)."""
    j = jobs.get(job_id)
    if not j or j.get("kind") != "yt-clips":
        return jsonify(error="Job not found."), 404
    import zipfile, io
    buf = io.BytesIO()
    def tc(s):
        m, sec = divmod(int(s), 60)
        return f"{m:02d}-{sec:02d}"
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for c in j.get("clips", []):
            if os.path.exists(c["path"]):
                # timecode name: 00-06.mp4, 00-12.mp4...
                name = f"{tc(c['start'])}-{tc(c['start']+6)}.mp4"
                zf.write(c["path"], f"personality_clips/{name}")
    buf.seek(0)
    return send_file(buf, mimetype="application/zip",
                     as_attachment=True,
                     download_name="personality_clips.zip")


@app.post("/api/bulk/prompts")
def api_bulk_prompts():
    """v2.24: Script + style -> styled image prompts (timecode analyzed)."""
    import json as _js, urllib.request as _ur
    data = request.get_json(force=True, silent=True) or {}
    script = (data.get("script") or "").strip()
    style = (data.get("style") or "cinematic").strip()
    if not script:
        return jsonify(error="Please write a script first."), 400
    # v2.24: AUTO interval — script analyze karke khud decide karo
    # Scene breaks (blank lines / #timecodes) = natural image points
    import re as _re2
    scenes = [s.strip() for s in _re2.split(r"\n\s*\n|#\d+-\d+", script) if s.strip()]
    words = len(script.split())
    duration = max(words / 2.5, 5)
    if len(scenes) >= 2:
        # Scene-based: ek image per scene
        n = len(scenes)
        interval = round(duration / n, 1)
    else:
        # Sentence-based: har 2-3 sentences par ek image
        sentences = [s.strip() for s in _re2.split(r"[.!?]+", script) if s.strip()]
        n = max(1, min(len(sentences) // 2, int(duration // 4)))
        n = max(n, 3)  # kam se kam 3
        interval = round(duration / n, 1)
    keys = _load_keys()
    gkey = (keys.get("groq") or "").strip()
    okey = (keys.get("openrouter") or "").strip()
    from imggen import IMAGE_STYLES as _DS
    style_desc = {
        "cinematic": "cinematic film still, dramatic lighting, 35mm",
        "anime": "anime style, vibrant, studio ghibli inspired",
        "cyberpunk": "cyberpunk, neon lights, futuristic",
        "realistic": "photorealistic, high detail, 8k",
    }.get(style)
    if not style_desc and style in _DS:
        style_desc = _DS[style][1]  # doodle style description
    # Sticky character explainer presets
    if style == "char_2d":
        style_desc = ("2D flat cartoon style with a RECURRING explainer character: "
                      "a friendly young man with brown hair, wearing a blue hoodie and jeans, "
                      "simple cartoon face, thick outlines. The SAME character appears in EVERY scene, "
                      "doing relevant activities or explaining — pointing at things, demonstrating actions, "
                      "reacting to the scene. Character stays consistent across all images, no text")
    elif style == "char_3d":
        style_desc = ("3D animated movie style with a RECURRING explainer character: "
                      "a cute 3D character with big expressive eyes, round face, wearing an orange t-shirt, "
                      "Pixar-like quality, soft lighting. The SAME character appears in EVERY scene, "
                      "doing relevant activities or explaining — interacting with the environment, "
                      "showing emotions, guiding the viewer. Character stays consistent across all images, no text")
    if not style_desc:
        style_desc = "cinematic film still"
    prompt = (f"You are an image prompt generator. Given this video script, create {n} "
              f"image prompts (one per ~{interval} seconds). Each prompt should describe a visual "
              f"scene matching the script's content at that point, in this style: {style_desc}. "
              f"Output ONLY the {n} prompts, one per line, numbered. No extra text.\n\nScript:\n{script[:3000]}")
    result = None
    if gkey:
        try:
            body = _js.dumps({"model": "llama-3.3-70b-versatile",
                              "messages": [{"role": "user", "content": prompt}],
                              "max_tokens": 3000}).encode()
            req = _ur.Request("https://api.groq.com/openai/v1/chat/completions", data=body,
                              headers={"Authorization": f"Bearer {gkey}",
                                       "Content-Type": "application/json"})
            with _ur.urlopen(req, timeout=90) as resp:
                data = _js.loads(resp.read().decode("utf-8"))
                result = data["choices"][0]["message"]["content"].strip()
        except Exception as e:
            pass
    if not result:
        return jsonify(error="Please add your Groq API key on the dashboard, or try again."), 400
    # Parse numbered prompts
    lines = [l.strip() for l in result.split("\n") if l.strip()]
    prompts = []
    for l in lines:
        # Remove numbering like "1." or "1)"
        import re as _re
        l = _re.sub(r"^\d+[.\)]\s*", "", l).strip()
        if l:
            prompts.append(l)
    # Timecodes for frontend display
    out_tcs = [s["tc"] for s in segments[:len(prompts)]] if segments else [round(i*interval) for i in range(len(prompts))]
    return jsonify(prompts=prompts, count=len(prompts),
                   duration=round(duration, 1), interval=interval,
                   timecodes=out_tcs)


@app.post("/api/style-from-image")
def api_style_from_image():
    """v2.24: Kisi bhi image se graphic style nikalo (Gemini Vision)."""
    import json as _js, urllib.request as _ur, base64
    f = request.files.get("image")
    if not f or not f.filename:
        return jsonify(error="Please upload an image."), 400
    keys = _load_keys()
    gkey = (keys.get("gemini") or "").strip()
    if not gkey:
        return jsonify(error="Please add your Gemini API key on the dashboard."), 400
    try:
        img_data = f.read()
        b64 = base64.b64encode(img_data).decode()
        mime = f.mimetype or "image/jpeg"
        body = _js.dumps({
            "contents": [{
                "parts": [
                    {"text": "Analyze this image's VISUAL/GRAPHIC STYLE in detail. Describe: art style, colors, lighting, texture, mood, technique. Output ONLY a concise style description (2-3 sentences) suitable as an image generation prompt suffix. No extra text."},
                    {"inline_data": {"mime_type": mime, "data": b64}}
                ]
            }]
        }).encode()
        req = _ur.Request(
            f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={gkey}",
            data=body, headers={"Content-Type": "application/json"})
        with _ur.urlopen(req, timeout=60) as resp:
            data = _js.loads(resp.read().decode("utf-8"))
            style = data["candidates"][0]["content"]["parts"][0]["text"].strip()
        return jsonify(style=style)
    except Exception as e:
        return jsonify(error=str(e)[:200]), 500


@app.post("/api/bulk/prompts-from-audio")
def api_bulk_prompts_from_audio():
    """v2.24: Audio do -> transcribe (Groq) -> scene prompts banao."""
    import json as _js, urllib.request as _ur, os, uuid
    f = request.files.get("audio")
    style = (request.form.get("style") or "cinematic").strip()
    if not f or not f.filename:
        return jsonify(error="Please upload an audio file."), 400
    keys = _load_keys()
    gkey = (keys.get("groq") or "").strip()
    if not gkey:
        return jsonify(error="Please add your Groq API key on the dashboard."), 400
    # Save temp
    tmp = os.path.join(DATA, f"tmpaud_{uuid.uuid4().hex[:8]}")
    f.save(tmp)
    try:
        # Transcribe via Groq
        from pipeline import transcribe_groq
        tr = transcribe_groq(tmp, gkey)
        words = tr.get("words", [])
        if not words:
            return jsonify(error="No speech was detected in the audio."), 400
        # Group into segments (~15 sec each)
        segments = []
        cur, cur_start = [], None
        for w in words:
            if cur_start is None:
                cur_start = w["start"]
            cur.append(w["word"])
            if w["end"] - cur_start >= 15:
                segments.append({"tc": round(cur_start), "text": " ".join(cur)})
                cur, cur_start = [], None
        if cur:
            segments.append({"tc": round(cur_start or 0), "text": " ".join(cur)})
        n = len(segments)
        # Style description
        from imggen import IMAGE_STYLES as _DS
        style_desc = {"cinematic": "cinematic film still", "anime": "anime style, vibrant",
                      "cyberpunk": "cyberpunk, neon", "realistic": "photorealistic"}.get(style)
        if not style_desc and style in _DS:
            style_desc = _DS[style][1]
        if style == "char_2d":
            style_desc = "2D flat cartoon with recurring explainer character (friendly young man, brown hair, blue hoodie), same character every scene, no text"
        elif style == "char_3d":
            style_desc = "3D Pixar-like with recurring explainer character (cute, big eyes, orange t-shirt), same character every scene, no text"
        if not style_desc:
            style_desc = "cinematic film still"
        seg_text = "\n".join(f"[{s['tc']}s] {s['text'][:250]}" for s in segments)
        prompt = (f"You are an image prompt generator. This is a transcribed voiceover. Create {n} "
                  f"image prompts — ONE per segment, in order.\n\nRULES:\n"
                  f"1. Each prompt = ONE single paragraph (visual scene only)\n"
                  f"2. NO cinematic filler words — describe ONLY what is visible\n"
                  f"3. Style: '{style_desc}'\n"
                  f"4. Output ONLY the {n} prompts, one per line, numbered.\n\nTranscript:\n{seg_text}")
        body = _js.dumps({"model": "llama-3.3-70b-versatile",
                          "messages": [{"role": "user", "content": prompt}],
                          "max_tokens": 3000}).encode()
        req = _ur.Request("https://api.groq.com/openai/v1/chat/completions", data=body,
                          headers={"Authorization": f"Bearer {gkey}", "Content-Type": "application/json"})
        with _ur.urlopen(req, timeout=90) as resp:
            data = _js.loads(resp.read().decode("utf-8"))
            result = data["choices"][0]["message"]["content"].strip()
        import re as _re
        lines = [l.strip() for l in result.split("\n") if l.strip()]
        prompts = [_re.sub(r"^\d+[.\)]\s*", "", l).strip() for l in lines]
        prompts = [p for p in prompts if p]
        tcs = [s["tc"] for s in segments[:len(prompts)]]
        transcript = " ".join(w["word"] for w in words)
        return jsonify(prompts=prompts, count=len(prompts), timecodes=tcs,
                       transcript=transcript[:500], duration=round(words[-1]["end"], 1))
    except Exception as e:
        return jsonify(error=str(e)[:200]), 500
    finally:
        try: os.remove(tmp)
        except: pass


# v2.24: Colorful vs monochrome icon sets
COLOR_SETS = {"openmoji", "noto", "noto-v2", "twemoji", "fxemoji", "fluent-emoji", "emojione", "emojione-v1"}
LINE_SETS = {"tabler", "mdi", "ic", "material-symbols", "ph", "lucide", "heroicons", "feather"}



def _classify_scenes_groq(scenes, gkey):
    """v2.24: Har scene ko classify karo: abstract (3D icon) ya real (stock footage)."""
    import json as _js, urllib.request as _ur
    texts = "\n".join(f"{i+1}. {s.get('text','')[:150]}" for i, s in enumerate(scenes))
    prompt = (f"Classify each scene as ABSTRACT (concept/idea/emotion) or REAL (person/place/brand/object).\n"
              f"Output ONLY one word per line: ABSTRACT or REAL. {len(scenes)} lines.\n\nScenes:\n{texts}")
    try:
        body = _js.dumps({"model": "llama-3.3-70b-versatile",
                          "messages": [{"role": "user", "content": prompt}],
                          "max_tokens": 500}).encode()
        req = _ur.Request("https://api.groq.com/openai/v1/chat/completions", data=body,
                          headers={"Authorization": f"Bearer {gkey}", "Content-Type": "application/json"})
        with _ur.urlopen(req, timeout=30) as resp:
            data = _js.loads(resp.read().decode("utf-8"))
            result = data["choices"][0]["message"]["content"].strip()
        out = []
        for line in result.split("\n"):
            line = line.strip().upper()
            out.append("real" if "REAL" in line else "abstract")
        # Pad if needed
        while len(out) < len(scenes):
            out.append("abstract")
        return out[:len(scenes)]
    except Exception:
        return ["abstract"] * len(scenes)


def _white_border_card(img_path, out_path, border=18, radius=28):
    """v2.24: Stock footage ko white rounded border card mein daalo (3D shadow)."""
    from PIL import Image, ImageDraw, ImageFilter
    img = Image.open(img_path).convert("RGB")
    # Resize to fit (keep aspect)
    tw, th = 1280, 720
    img.thumbnail((tw - border*2, th - border*2), Image.LANCZOS)
    # White card
    cw, ch = img.width + border*2, img.height + border*2
    card = Image.new("RGB", (cw, ch), "white")
    # Rounded mask
    mask = Image.new("L", (cw, ch), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, cw, ch], radius=radius, fill=255)
    # Paste image centered
    card.paste(img, (border, border))
    # Shadow
    shadow = Image.new("RGB", (cw+30, ch+30), "#f0f0f5")
    shadow.paste(card, (15, 15), mask)
    # Off-white background
    bg = Image.new("RGB", (tw, th), "#f5f5f7")
    bg.paste(shadow, ((tw-cw-30)//2, (th-ch-30)//2))
    bg.save(out_path)
    return out_path


@app.post("/api/test-key")
def api_test_key():
    """v2.20: API key test karo (groq/openrouter)."""
    import urllib.request
    import json as _json
    data = request.get_json(force=True, silent=True) or {}
    service = (data.get("service") or "").strip().lower()
    key = (_load_keys().get(service) or "").strip()
    if not key:
        return jsonify(ok=False, error="No key has been added."), 400

    UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
          "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
    try:
        if service == "groq":
            # chhota test: models list
            req = urllib.request.Request(
                "https://api.groq.com/openai/v1/models",
                headers={"Authorization": f"Bearer {key}",
                         "User-Agent": UA})
            with urllib.request.urlopen(req, timeout=30) as resp:
                d = _json.loads(resp.read().decode("utf-8"))
            n = len(d.get("data", []))
            return jsonify(ok=True, message=f"✅ Groq OK! ({n} models)")
        elif service == "elevenlabs":
            req = urllib.request.Request(
                "https://api.elevenlabs.io/v1/user",
                headers={"xi-api-key": key, "User-Agent": UA})
            with urllib.request.urlopen(req, timeout=30) as resp:
                d = _json.loads(resp.read().decode("utf-8"))
            chars = d.get("subscription", {}).get("character_limit", 0)
            return jsonify(ok=True,
                           message=f"✅ ElevenLabs OK! ({chars} chars)"), 200
        elif service == "stability":
            req = urllib.request.Request(
                "https://api.stability.ai/v1/user/account",
                headers={"Authorization": f"Bearer {key}",
                         "User-Agent": UA})
            with urllib.request.urlopen(req, timeout=30) as resp:
                _json.loads(resp.read().decode("utf-8"))
            return jsonify(ok=True, message="✅ Stability OK!"), 200
        elif service == "openrouter":
            # v2.22 fix: try multiple free models (404 = model gone)
            models = ["meta-llama/llama-3.3-70b-instruct:free",
                      "google/gemma-2-9b-it:free",
                      "mistralai/mistral-7b-instruct:free"]
            last_err = ""
            for model in models:
                try:
                    body = _json.dumps({
                        "model": model,
                        "messages": [{"role": "user", "content": "Say OK"}],
                        "max_tokens": 5,
                    }).encode()
                    req = urllib.request.Request(
                        "https://openrouter.ai/api/v1/chat/completions",
                        data=body,
                        headers={"Authorization": f"Bearer {key}",
                                 "Content-Type": "application/json",
                                 "HTTP-Referer": "https://azcut.app",
                                 "X-Title": "Az Cut", "User-Agent": UA})
                    with urllib.request.urlopen(req, timeout=60) as resp:
                        _json.loads(resp.read().decode("utf-8"))
                    return jsonify(ok=True, message="✅ OpenRouter OK!")
                except urllib.error.HTTPError as me:
                    last_err = f"HTTP {me.code}"
                    if me.code == 401:
                        return jsonify(ok=False, error="❌ Galat key!"), 400
                    continue  # try next model on 404
                except Exception as me:
                    last_err = str(me)[:50]
                    continue
            return jsonify(ok=False, error=f"❌ {last_err} — please check the key"), 400
        return jsonify(ok=False, error="Unknown service."), 400
    except urllib.error.HTTPError as e:
        code = e.code
        if code == 401:
            return jsonify(ok=False,
                            error="❌ Invalid key — please check it."), 200
        return jsonify(ok=False,
                        error=f"❌ Error {code} — please try again."), 200
    except Exception as e:  # noqa: BLE001
        return jsonify(ok=False, error=f"❌ {str(e)[:100]}"), 200


@app.post("/api/ai-prompts")
def api_ai_prompts():
    """v2.20: OpenRouter se script -> detailed image prompts (bulk)."""
    import urllib.request
    import json as _json
    data = request.get_json(force=True, silent=True) or {}
    script = (data.get("script") or "").strip()
    if not script:
        return jsonify(error="Please enter a script."), 400
    style = (data.get("style") or "cinematic").strip()
    api_key = (_load_keys().get("openrouter") or "").strip()
    if not api_key:
        return jsonify(error="Please add your OpenRouter API key on the dashboard."), 400

    style_desc = {
        "cinematic": "Cinematic hand-painted illustration",
        "doodle": "Simple doodle cartoon illustration",
        "realistic": "Photorealistic cinematic photo",
        "anime": "Beautiful anime style illustration",
    }.get(style, "Cinematic hand-painted illustration")

    system = (
        "You are a professional storyboard artist. Given a video script, "
        "split it into visual scenes and write ONE detailed image generation "
        "prompt per scene. "
        f"Each prompt must start with 'Image Prompt: {style_desc} showing ' "
        "then describe the scene vividly. "
        "End EVERY prompt with: 'warm golden atmosphere, extreme wide establishing "
        "shot, full-bleed 16:9, scene extending completely to every edge, "
        "no borders, no frames, no text, no captions, no subtitles, no watermark, "
        "NOT flat clipart, NOT 3D render'. "
        "Number each as '(0:00) IMAGE 1', '(0:08) IMAGE 2' etc (8 sec apart). "
        "Output ONLY the numbered prompts, one per paragraph, no extra text."
    )
    body = _json.dumps({
        "model": "meta-llama/llama-3.3-70b-instruct:free",
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": f"Script:\n{script[:4000]}"},
        ],
    }).encode()

    req = urllib.request.Request(
        "https://openrouter.ai/api/v1/chat/completions",
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://azcut.app",
            "X-Title": "Az Cut",
        })
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            out = _json.loads(resp.read().decode("utf-8"))
        text = out["choices"][0]["message"]["content"]
        return jsonify(prompts=text)
    except urllib.error.HTTPError as e:
        try:
            err = e.read().decode("utf-8")[:300]
        except Exception:  # noqa: BLE001
            err = str(e)
        return jsonify(error=f"OpenRouter error: {err}"), 500
    except Exception as e:  # noqa: BLE001
        return jsonify(error=str(e)[:300]), 500


@app.post("/api/imggen")
def api_imggen():
    """Bulk-generate storyboard images (Gemini or fal.ai)."""
    provider = (request.form.get("provider") or "gemini").strip().lower()
    if provider not in ("gemini", "fal", "stability"):
        provider = "gemini"
    api_key = (request.form.get("api_key") or "").strip()
    if not api_key:
        if provider == "fal":
            return jsonify(
                error="Please paste your fal.ai API key first."), 400
        if provider == "stability":
            return jsonify(
                error="Please add your Stability AI key on the dashboard."), 400
        return jsonify(error="Please paste your Gemini API key first."), 400
    prompts_text = request.form.get("prompts", "")
    aspect = request.form.get("aspect", "16:9")
    model = request.form.get("model", "")
    if aspect not in IMGGEN_ASPECTS:
        aspect = "16:9"
    if provider == "fal":
        if model not in FAL_MODELS:
            model = "fal-ai/flux/schnell"
    elif model not in IMGGEN_MODELS:
        model = "gemini-3.1-flash-image"
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"status": "queued", "kind": "imggen"}
    threading.Thread(target=_imggen_bg,
                     args=(job_id, api_key, prompts_text, aspect, model,
                           provider),
                     daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/imggen/<job_id>")
def api_imggen_status(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Unknown job."), 404
    out = {"status": j["status"], "kind": j.get("kind"),
           "doing": j.get("doing", "")}
    if j["status"] == "done":
        out["images"] = list(range(1, len(j.get("images", [])) + 1))
        out["failed"] = [{"n": n, "error": e}
                         for n, e in (j.get("failed") or [])]
    if j["status"] == "error":
        out["error"] = j.get("error")
    return jsonify(out)


@app.get("/api/imggen/<job_id>/<int:n>/preview")
def api_imggen_preview(job_id, n):
    j = jobs.get(job_id)
    imgs = (j or {}).get("images") or []
    if not (1 <= n <= len(imgs)) or not os.path.exists(imgs[n - 1]):
        return jsonify(error="Image not found."), 404
    return send_file(imgs[n - 1], mimetype="image/png")


@app.get("/api/imggen/<job_id>/download")
def api_imggen_download(job_id):
    j = jobs.get(job_id)
    if not j:
        return jsonify(error="Job not found."), 404
    imgs = j.get("images") or []
    if j["status"] != "done" or not imgs:
        return jsonify(error="Images are not ready yet."), 400
    import zipfile
    zpath = os.path.join(DATA, f"images_{job_id}.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for i, p in enumerate(imgs, 1):
            z.write(p, f"{i:02d}.png")
    return send_file(zpath, as_attachment=True,
                     download_name="azcut_images.zip")


# ---------------- one-click auto-update ----------------
_update_state = {"state": "idle", "percent": 0, "message": "", "latest_version": ""}
_last_update_check = None


# ---------------------------------------------------------------------------
# 1-Click Video (v2.33): topic -> script (Groq/OpenRouter) -> voice (edge-tts,
# free Microsoft neural voices) -> scene images (Pollinations, free) ->
# render + captions (Studio engine) -> thumbnail. Ek button, poori video.
# ---------------------------------------------------------------------------

ONECLICK_NICHES = {
    "history": ("Faceless History Documentary",
                "ancient empires, wars, kings, lost civilizations; dramatic "
                "storytelling with a strong hook, dates and vivid scenes"),
    "motivation": ("Motivation & Mindset",
                   "stoic discipline, habits, mental toughness; direct, "
                   "powerful second-person narration"),
    "horror": ("Horror Stories",
               "a slow-burn scary story, eerie atmosphere, suspense that "
               "keeps building, chilling ending twist"),
    "facts": ("Amazing Facts",
              "surprising facts woven into a flowing story, curious and "
              "energetic tone"),
    "islamic": ("Islamic Wisdom & History",
                "respectful stories from Islamic history and timeless "
                "wisdom, calm and reflective tone"),
    "health": ("Health & Longevity",
               "science-based health and habits of long-lived people, "
               "practical advice, warm tone for older viewers"),
    "crime": ("True Crime & Mystery",
              "unsolved mysteries and true crime told like a documentary, "
              "careful with facts, never glorifying criminals"),
    "science": ("Science & Space",
                "space, physics and discoveries explained simply, with a "
                "sense of wonder"),
    "biography": ("Biography / Life Story",
                  "one famous person's life from struggle to success, "
                  "emotional storytelling"),
    "general": ("General / Any Topic",
                "an engaging explainer documentary on the given topic"),
}

ONECLICK_LANGS = {
    "en": "English",
    "ur": "Urdu - write ONLY in Urdu script, no Roman Urdu",
    "hi": "Hindi - write ONLY in Devanagari script",
    "ar": "Arabic - write ONLY in Arabic script",
    "es": "Spanish - neutral Latin-American Spanish",
}

ONECLICK_VOICES = [
    ("en-US-ChristopherNeural", "en"),
    ("en-US-EricNeural", "en"),
    ("en-GB-RyanNeural", "en"),
    ("en-US-JennyNeural", "en"),
    ("ur-PK-AsadNeural", "ur"),
    ("ur-PK-UzmaNeural", "ur"),
    ("hi-IN-MadhurNeural", "hi"),
    ("hi-IN-SwaraNeural", "hi"),
    ("ar-SA-HamedNeural", "ar"),
    ("ar-EG-SalmaNeural", "ar"),
    ("es-ES-AlvaroNeural", "es"),
    ("es-MX-JorgeNeural", "es"),
    ("es-ES-ElviraNeural", "es"),
]
ONECLICK_VOICE_IDS = {v[0] for v in ONECLICK_VOICES}
ONECLICK_DEFAULT_VOICE = {
    "en": "en-US-ChristopherNeural", "ur": "ur-PK-AsadNeural",
    "hi": "hi-IN-MadhurNeural", "ar": "ar-SA-HamedNeural",
    "es": "es-ES-AlvaroNeural",
}

ONECLICK_LENGTHS = {
    "short": ("Short (~1 min)", 150, 6),
    "medium": ("Medium (~3 min)", 450, 12),
    "long": ("Long (~6 min)", 850, 20),
    "xl": ("XL (~10 min)", 1300, 28),
}

ONECLICK_STYLES = {
    "cinematic": "Cinematic hand-painted illustration",
    "realistic": "Photorealistic cinematic photo",
    "anime": "Beautiful anime style illustration",
    "doodle": "Simple doodle cartoon illustration",
}


def _oc_llm(prompt, max_tokens=3000):
    """Script/prompt generation: Groq (saved key) pehle, warna OpenRouter
    free model. Dono na hon ya fail hon to None."""
    keys = _load_keys()
    gkey = (keys.get("groq") or "").strip()
    if gkey:
        try:
            body = json.dumps({
                "model": "llama-3.3-70b-versatile",
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens}).encode()
            req = urllib.request.Request(
                "https://api.groq.com/openai/v1/chat/completions", data=body,
                headers={"Authorization": f"Bearer {gkey}",
                         "Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            return data["choices"][0]["message"]["content"].strip()
        except Exception:
            pass
    okey = (keys.get("openrouter") or "").strip()
    if okey:
        try:
            body = json.dumps({
                "model": "meta-llama/llama-3.3-70b-instruct:free",
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens}).encode()
            req = urllib.request.Request(
                "https://openrouter.ai/api/v1/chat/completions", data=body,
                headers={"Authorization": f"Bearer {okey}",
                         "Content-Type": "application/json",
                         "HTTP-Referer": "https://azcut.app",
                         "X-Title": "Az Cut"})
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            return data["choices"][0]["message"]["content"].strip()
        except Exception:
            return None
    return None


def _oc_make_script(topic, niche_id, lang_id, target_words):
    """LLM se (title, script). Fail ho to (None, None)."""
    nlabel, guide = ONECLICK_NICHES[niche_id]
    prompt = (
        "You are a senior scriptwriter for faceless YouTube channels.\n"
        f"NICHE: {nlabel} - {guide}.\n"
        f"TOPIC: {topic}\n"
        f"LANGUAGE: {ONECLICK_LANGS[lang_id]}.\n"
        f"Write a narration script of about {target_words} words. Rules:\n"
        "- Start with a powerful 1-2 line HOOK that makes viewers stay.\n"
        "- Pure narration text only: no headings, no [music], no stage "
        "directions, no speaker labels, no markdown.\n"
        "- Short paragraphs, spoken style, keep curiosity alive till the end.\n"
        "- End with a memorable closing line (no subscribe begging).\n"
        "Respond with ONLY a JSON object: "
        '{"title": "<catchy video title, max 70 chars>", '
        '"script": "<the full narration script>"}'
    )
    raw = _oc_llm(prompt, max_tokens=4000)
    if not raw:
        return None, None
    txt = raw.strip()
    if txt.startswith("```"):
        txt = txt.strip("`")
        if txt.lower().startswith("json"):
            txt = txt[4:].strip()
    try:
        obj = json.loads(txt)
        script = (obj.get("script") or "").strip()
        if len(script.split()) >= 40:
            return (obj.get("title") or topic).strip()[:90], script
    except Exception:
        pass
    if len(raw.split()) >= 40:  # model ne JSON nahi diya - text hi script hai
        return topic[:90], raw.strip()
    return None, None


def _oc_sents(text):
    parts = re.split(r"(?<=[.!?।…])\s+", (text or "").replace("\n", " "))
    return [p.strip() for p in parts if p.strip()]


def _oc_groups(items, weights, n):
    """items ko n groups mein baanto - har group ka kul weight takreeban ek sa."""
    if n <= 1 or len(items) <= 1:
        return [list(items)]
    target = sum(weights) / n
    groups, cur, acc = [], [], 0.0
    for it, w in zip(items, weights):
        cur.append(it)
        acc += w
        if len(groups) < n - 1 and acc >= target * (len(groups) + 1):
            groups.append(cur)
            cur = []
    if cur:
        groups.append(cur)
    return groups


def _oc_image_prompts(group_texts, style_desc, aspect):
    n = len(group_texts)
    joined = "\n".join(f"SCENE {i + 1}: {g}" for i, g in enumerate(group_texts))
    prompt = (
        "You are a storyboard artist. Below is a narration script split into "
        f"{n} scenes. Write ONE image-generation prompt per scene in this "
        f"visual style: {style_desc}.\n"
        "Every prompt must be in ENGLISH, vivid and specific to its scene, "
        f"and end with: 'warm cinematic light, full-bleed {aspect}, no text, "
        "no watermark, no borders'.\n"
        f"Output ONLY the {n} prompts, numbered '1.' to '{n}.', one per "
        f"line, no extra text.\n\n{joined[:6000]}"
    )
    raw = _oc_llm(prompt, max_tokens=2500)
    prompts = []
    if raw:
        for line in raw.splitlines():
            line = re.sub(r"^\d+[\.\)]\s*", "", line.strip()).strip()
            if line:
                prompts.append(line)
    if len(prompts) < n:  # fallback: scene text se seedha prompt
        prompts = [
            f"{style_desc} showing {g[:220]}, warm cinematic light, "
            f"full-bleed {aspect}, no text, no watermark"
            for g in group_texts
        ]
    return prompts[:n]


def _oc_tts(text, voice, workdir, out_path):
    """edge-tts (free Microsoft neural voices) se voiceover. Lambay script
    ko chunks mein kaat kar ffmpeg se jorta hai."""
    try:
        import edge_tts
    except ImportError:
        raise RuntimeError(
            "The voice engine (edge-tts) is not installed. Please "
            "reinstall the app; it is included in the requirements.")
    import asyncio

    chunks, cur = [], ""
    for s in _oc_sents(text):
        if cur and len(cur) + len(s) + 1 > 1100:
            chunks.append(cur)
            cur = ""
        cur = (cur + " " + s).strip()
    if cur:
        chunks.append(cur)
    if not chunks:
        raise RuntimeError("The script is empty, so no voice can be generated.")

    async def _save(chunk, path):
        await edge_tts.Communicate(chunk, voice).save(path)

    parts = []
    for i, ch in enumerate(chunks):
        p = os.path.join(workdir, f"voice_{i}.mp3")
        asyncio.run(_save(ch, p))
        if not (os.path.exists(p) and os.path.getsize(p) > 1000):
            raise RuntimeError(
                "Voice generation failed. Please check your internet connection.")
        parts.append(p)
    if len(parts) == 1:
        os.replace(parts[0], out_path)
        return
    lst = os.path.join(workdir, "concat.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p in parts:
            f.write(f"file '{p}'\n")
    r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat",
                        "-safe", "0", "-i", lst, "-c", "copy", out_path],
                       capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(out_path):
        raise RuntimeError("Failed to join the voice parts.")


def _oc_starts(words, n, total):
    """Transcribed words ko n groups mein baant kar har group ka start time.
    Words na hon to barabar hisse."""
    if not words or len(words) < n:
        step = total / max(n, 1)
        return [round(i * step, 2) for i in range(n)]
    groups = _oc_groups(words, [1] * len(words), n)
    starts, idx = [0.0], 0
    for g in groups[:-1]:
        idx += len(g)
        starts.append(float(words[idx]["start"]))
    while len(starts) < n:  # safety: kabhi kam na hon
        starts.append(starts[-1] + total / max(n, 1))
    return starts[:n]


def _oc_thumbnail(img_path, title, out_path):
    """Pehli scene image + baray title text se 1280x720 thumbnail."""
    from PIL import Image, ImageDraw, ImageFont
    img = Image.open(img_path).convert("RGB")
    tw, th = 1280, 720
    scale = max(tw / img.width, th / img.height)
    img = img.resize((int(img.width * scale) + 1, int(img.height * scale) + 1))
    x = (img.width - tw) // 2
    y = (img.height - th) // 2
    img = img.crop((x, y, x + tw, y + th))
    img = Image.blend(img, Image.new("RGB", (tw, th), (0, 0, 0)), 0.16)
    d = ImageDraw.Draw(img)
    font_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "assets", "fonts", "Anton-Regular.ttf")
    words = (title or "").upper().split()
    lines, cur = [], ""
    for w in words:
        if len(cur) + len(w) + 1 <= 15:
            cur = (cur + " " + w).strip()
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    lines = [l for l in lines if l][:3] or [""]
    size = 118 if len(lines) <= 2 else 94
    try:
        fnt = ImageFont.truetype(font_path, size)
    except Exception:
        fnt = ImageFont.load_default()
    lh = int(size * 1.14)
    y0 = th - lh * len(lines) - 44
    for i, ln in enumerate(lines):
        d.text((46, y0 + i * lh), ln, font=fnt, fill=(255, 255, 255),
               stroke_width=7, stroke_fill=(0, 0, 0))
    img.save(out_path, quality=90)


def _oneclick_bg(job_id, cfg):
    try:
        jobs[job_id]["status"] = "building"
        from imggen import generate_image_pollinations
        workdir = os.path.join(DATA, f"oneclick_{job_id}")
        os.makedirs(workdir, exist_ok=True)

        # 1) Script
        jobs[job_id]["doing"] = "Writing the script..."
        title, script = _oc_make_script(
            cfg["topic"], cfg["niche"], cfg["lang"], cfg["words"])
        if not script:
            raise RuntimeError(
                "The script could not be generated. Please add a Groq API "
                "key under API Keys on the Home page (it is free), then try again.")
        jobs[job_id]["title"] = title

        # 2) Scenes + image prompts
        sents = _oc_sents(script)
        groups = _oc_groups(
            sents, [max(1, len(s.split())) for s in sents], cfg["scenes"])
        group_texts = [" ".join(g) for g in groups]
        prompts = _oc_image_prompts(
            group_texts, ONECLICK_STYLES[cfg["style"]], cfg["aspect"])

        # 3) Images (free Pollinations) - fail ho to pichli image / placeholder
        images = []
        for i, pr in enumerate(prompts):
            jobs[job_id]["doing"] = f"Generating images... {i + 1}/{len(prompts)}"
            data = None
            for attempt in range(3):
                try:
                    data = generate_image_pollinations(pr, aspect=cfg["aspect"])
                    break
                except Exception:
                    time.sleep(4 * (attempt + 1))
            path = os.path.join(workdir, f"scene_{i:02d}.jpg")
            if data:
                with open(path, "wb") as f:
                    f.write(data)
            elif images:
                path = images[-1]
            else:
                from PIL import Image as _Im
                _Im.new("RGB", (1280, 720), (24, 24, 32)).save(path)
            images.append(path)
        if not images:
            raise RuntimeError("No image could be generated. Please try again.")

        # 4) Voice (edge-tts, free)
        jobs[job_id]["doing"] = "Generating the voiceover..."
        audio = os.path.join(workdir, "voice.mp3")
        _oc_tts(script, cfg["voice"], workdir, audio)
        total = audio_duration(audio)
        if not total or total <= 0:
            raise RuntimeError("Could not determine the voice duration.")

        # 5) Transcribe - captions + scene timing ke liye
        words = []
        try:
            gkey = _groq_key()
            if gkey:
                tr = transcribe(audio, groq_key=gkey, language=cfg["lang"])
            else:
                tr = transcribe(audio, language=cfg["lang"])
            words = tr.get("words") or []
        except Exception:
            words = []
        starts = _oc_starts(words, len(images), total)
        if len(starts) < len(images):
            images = images[:len(starts)]

        # 6) Render (Studio engine) + captions
        jobs[job_id]["doing"] = "Rendering the video..."
        cap_opts = None
        if cfg["captions"] and words:
            cap_opts = _caption_opts({"cap_on": "1",
                                      "cap_preset": cfg["preset"],
                                      "cap_aspect": "source"})
        width, height = (720, 1280) if cfg["aspect"] == "9:16" else (1280, 720)
        out = os.path.join(workdir, "video.mp4")
        build_video(audio, images, starts, out, total,
                    width=width, height=height,
                    transition="fade", motion="zoomin",
                    captions=cap_opts, words=words or None, sfx_on=False)

        # 7) Thumbnail
        thumb = os.path.join(workdir, "thumbnail.jpg")
        try:
            _oc_thumbnail(images[0], title, thumb)
        except Exception:
            thumb = None
        jobs[job_id].update(status="done", file=out, thumb=thumb,
                            title=title, script=script, doing="Done!")
    except Exception as e:  # noqa: BLE001
        jobs[job_id].update(status="error", error=str(e)[:400])


@app.post("/api/oneclick/build")
def api_oneclick_build():
    data = request.get_json(force=True, silent=True) or {}
    topic = (data.get("topic") or "").strip()
    if not topic:
        return jsonify(error="Please enter a topic."), 400
    niche = data.get("niche") if data.get("niche") in ONECLICK_NICHES else "general"
    lang = data.get("lang") if data.get("lang") in ONECLICK_LANGS else "en"
    voice = data.get("voice")
    if voice not in ONECLICK_VOICE_IDS:
        voice = ONECLICK_DEFAULT_VOICE[lang]
    length = data.get("length") if data.get("length") in ONECLICK_LENGTHS else "medium"
    _lbl, words_t, scenes = ONECLICK_LENGTHS[length]
    style = data.get("style") if data.get("style") in ONECLICK_STYLES else "cinematic"
    preset = data.get("preset") or "hormozi"
    if preset not in CAPTION_PRESETS:
        preset = "hormozi"
    cfg = {"topic": topic[:300], "niche": niche, "lang": lang, "voice": voice,
           "words": words_t, "scenes": scenes, "style": style,
           "aspect": "9:16" if data.get("aspect") == "9:16" else "16:9",
           "captions": bool(data.get("captions", True)), "preset": preset}
    job_id = uuid.uuid4().hex[:12]
    jobs[job_id] = {"status": "queued", "kind": "oneclick",
                    "doing": "Queued..."}
    threading.Thread(target=_oneclick_bg, args=(job_id, cfg),
                     daemon=True).start()
    return jsonify(job_id=job_id)


@app.get("/api/oneclick/<job_id>")
def api_oneclick_status(job_id):
    j = jobs.get(job_id)
    if not j or j.get("kind") != "oneclick":
        return jsonify(error="Job not found"), 404
    out = {"status": j.get("status"), "doing": j.get("doing")}
    if j.get("status") == "error":
        out["error"] = j.get("error")
    if j.get("status") == "done":
        out["title"] = j.get("title")
        out["script"] = j.get("script")
        out["has_thumb"] = bool(j.get("thumb"))
    return jsonify(out)


@app.get("/api/oneclick/<job_id>/preview")
def api_oneclick_preview(job_id):
    j = jobs.get(job_id)
    if not j or j.get("status") != "done" or not os.path.exists(j.get("file", "")):
        return jsonify(error="The video is not ready yet"), 404
    return send_file(j["file"], mimetype="video/mp4")


@app.get("/api/oneclick/<job_id>/download")
def api_oneclick_download(job_id):
    j = jobs.get(job_id)
    if not j or j.get("status") != "done" or not os.path.exists(j.get("file", "")):
        return jsonify(error="The video is not ready yet"), 404
    return send_file(j["file"], as_attachment=True,
                     download_name="azcut-oneclick-video.mp4")


@app.get("/api/oneclick/<job_id>/thumbnail")
def api_oneclick_thumbnail(job_id):
    j = jobs.get(job_id)
    if not j or not j.get("thumb") or not os.path.exists(j["thumb"]):
        return jsonify(error="No thumbnail is available"), 404
    return send_file(j["thumb"], as_attachment=True,
                     download_name="azcut-thumbnail.jpg")


@app.get("/api/check-update")
def api_check_update():
    global _last_update_check
    _last_update_check = check_for_updates(PIPELINE_VERSION)
    return jsonify(_last_update_check)


@app.get("/api/update-status")
def api_update_status():
    return jsonify(_update_state)


def _update_dest(tmp, asset_name):
    """v2.28: pick a writable installer path in Temp.

    The fixed name could be locked by antivirus or a leftover installer from
    an earlier attempt, which crashed the download with [Errno 13] Permission
    denied. Fall back to a unique name so an update never gets stuck on it.
    """
    base, ext = os.path.splitext(asset_name)
    cands = [os.path.join(tmp, asset_name),
             os.path.join(tmp, f"{base}-{int(time.time())}{ext}"),
             os.path.join(tmp, f"{base}-{os.getpid()}{ext}")]
    for cand in cands:
        try:
            with open(cand, "ab"):
                pass
            return cand
        except OSError:
            continue
    return cands[1]


def _do_update(url, asset_name):
    try:
        _update_state.update(state="downloading", percent=0,
                             message="Downloading the update...")
        tmp = os.environ.get("TEMP") or tempfile.gettempdir()
        dest = _update_dest(tmp, asset_name)
        req = urllib.request.Request(url, headers={"User-Agent": "AzCut-Updater"})
        with urllib.request.urlopen(req, timeout=60) as r, open(dest, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            while True:
                chunk = r.read(1024 * 256)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if total:
                    _update_state["percent"] = int(done * 100 / total)
        _update_state.update(state="downloaded", percent=100,
                             message="Download mukammal!")
        if not FROZEN:
            _update_state["message"] = f"File tayyar: {dest} - ise khud chalayein."
            return
        # frozen (installed) mode: silent-install via helper bat, then restart
        exe_dir = os.path.dirname(sys.executable)
        bat = os.path.join(tmp, "azcut_update.bat")
        with open(bat, "w") as f:
            f.write("@echo off\n"
                    "timeout /t 4 /nobreak >nul\n"
                    "taskkill /F /IM AzCut.exe >nul 2>nul\n"
                    f'"{dest}" /VERYSILENT /SUPPRESSMSGBOXES\n'
                    f'start "" "{exe_dir}\\AzCut.exe"\n')
        _update_state.update(state="installing",
                             message="Running the installer...")
        popen_kw = {}
        if os.name == "nt":
            popen_kw["creationflags"] = (subprocess.DETACHED_PROCESS
                                         | subprocess.CREATE_NO_WINDOW)
        subprocess.Popen(["cmd", "/c", bat], **popen_kw)
        time.sleep(2)
        os._exit(0)
    except Exception as e:
        _update_state.update(state="error", message=str(e)[:200])


@app.post("/api/start-update")
def api_start_update():
    if _update_state["state"] == "downloading":
        return jsonify(started=True)
    info = _last_update_check or check_for_updates(PIPELINE_VERSION)
    if not info.get("ok") or not info.get("update_available"):
        return jsonify(error="No new update found."), 404
    _update_state.update(state="downloading", percent=0, message="",
                         latest_version=info["latest_version"])
    threading.Thread(target=_do_update,
                     args=(info["download_url"], info["asset_name"]),
                     daemon=True).start()
    return jsonify(started=True)


@app.get("/capfonts/<path:fname>")
def capfonts(fname):
    """v2.38: bundled caption fonts serve karo taake Captions page ka
    preview (@font-face) bilkul wahi font use kare jo asal burn
    (libass fontsdir) use karta hai — preview font == video font."""
    base = os.path.basename(fname)
    if base != fname or not base.lower().endswith(".ttf"):
        return "Not found", 404
    from pipeline import _caption_fontsdir
    fd = _caption_fontsdir()
    if not fd:
        return "Not found", 404
    p = os.path.join(fd, base)
    if not os.path.isfile(p):
        return "Not found", 404
    return send_file(p, mimetype="font/ttf")


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"\n  Az Cut is running at: http://127.0.0.1:{port}\n"
          "  Band karne ke liye Ctrl+C dabayein.\n")
    if os.environ.get("NARRASYNC_NO_BROWSER") != "1":
        import webbrowser
        from threading import Timer
        Timer(1.2, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
    app.run(host="127.0.0.1", port=port, threaded=True)
