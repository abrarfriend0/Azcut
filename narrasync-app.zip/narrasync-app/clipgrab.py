"""Clip Grabber - celebrity name / video link -> clean 1080p moment clips.

Bilkul saaf clips: no captions, no overlays, no ranking graphics.
User selects: celebrity name OR video link, clip count, seconds,
aspect ratio (16:9 / 9:16 / 1:1). Moments found via rank.py's
audio-energy detection.
"""

import glob
import math
import os
import re
import subprocess
import zipfile

import rank

RATIOS = {
    "16:9": (1920, 1080),   # YouTube
    "9:16": (1080, 1920),   # Shorts / Reels / TikTok
    "1:1": (1080, 1080),    # Instagram post
}


class ClipError(Exception):
    pass


def _yt_base():
    return {
        "quiet": True, "no_warnings": True, "noplaylist": True,
        "socket_timeout": 30, "retries": 2,
        # web pehle (HD), na chale to android (bot-check se bachao)
        "extractor_args": {"youtube": {"player_client": ["web", "android"]}},
    }


def is_youtube_url(s):
    s = (s or "").strip().lower()
    return ("youtube.com/watch" in s or "youtu.be/" in s
            or "youtube.com/shorts/" in s)


def search_videos(query, n, workdir):
    """Celebrity/topic name -> top n YouTube video URLs (views order)."""
    try:
        from yt_dlp import YoutubeDL
    except ImportError:
        raise ClipError(
            "yt-dlp installed nahi hai - install.bat dobara chala kar "
            "libraries install karein.")
    base = _yt_base()
    try:
        with YoutubeDL(base) as ydl:
            pl = ydl.extract_info(f"ytsearch{max(n * 3, 12)}:{query}",
                                  download=False, process=False)
    except Exception as e:  # noqa: BLE001
        raise ClipError(f"YouTube search nahi ho saki: {e}")
    urls = []
    for e in (pl.get("entries") or []):
        u = (e or {}).get("webpage_url") or (e or {}).get("url")
        if u and u not in urls:
            urls.append(u)
    metas = []
    with YoutubeDL(base) as ydl:
        for u in urls[:max(n * 3, 12)]:
            try:
                v = ydl.extract_info(u, download=False)
            except Exception:  # noqa: BLE001
                continue
            if v and v.get("id"):
                metas.append(v)

    def score(m):
        dur = m.get("duration") or 0
        if dur <= 0 or dur > 1800:  # 30 min se lambi skip
            return -1
        return m.get("view_count") or 0

    metas.sort(key=score, reverse=True)
    out = []
    for m in metas:
        if score(m) < 0:
            continue
        out.append(m.get("webpage_url")
                   or f"https://www.youtube.com/watch?v={m.get('id')}")
        if len(out) >= n:
            break
    if not out:
        raise ClipError("Is naam ki koi video nahi mili. Kuch aur likh kar try karo.")
    return out


def download_1080(url, workdir, tag):
    """Best <=1080p mp4 download. Returns path, ya None (fail)."""
    from yt_dlp import YoutubeDL
    opts = dict(
        _yt_base(),
        format=("bv*[ext=mp4][height<=1080]+ba[ext=m4a]/"
                "b[ext=mp4][height<=1080]/b[ext=mp4]/b"),
        merge_output_format="mp4",
        outtmpl=os.path.join(workdir, f"grab_{tag}.%(ext)s"),
    )
    with YoutubeDL(opts) as ydl:
        try:
            ydl.download([url])
        except Exception:  # noqa: BLE001
            return None
    got = sorted(glob.glob(os.path.join(workdir, f"grab_{tag}.mp4")),
                 key=os.path.getmtime)
    return got[-1] if got else None


def cut_clean_clip(src, out, start, seconds, ratio):
    """Ek saaf clip kaato: chosen ratio, 1080, no captions/overlays."""
    w, h = RATIOS.get(ratio, RATIOS["16:9"])
    dur = rank.probe_duration(src)
    if dur <= 0:
        raise ClipError("Video ki duration maloom nahi ho saki.")
    take = min(seconds, dur)
    start = min(max(start, 0.0), max(dur - take, 0.0))
    vf = (f"[0:v]scale={w}:{h}:force_original_aspect_ratio=increase,"
          f"crop={w}:{h},setsar=1,fps=30,format=yuv420p[v]")
    cmd = (["ffmpeg", "-y", "-v", "error",
            "-ss", f"{start:.2f}", "-t", f"{take:.2f}", "-i", src,
            "-filter_complex", vf,
            "-map", "[v]", "-map", "0:a?",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-c:a", "aac", "-b:a", "128k",
            "-movflags", "+faststart", "-shortest", out])
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(out):
        raise ClipError(f"Clip cut nahi ho saki: {r.stderr[-300:]}")
    return out


def make_zip(paths, out_zip):
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for i, p in enumerate(paths, 1):
            z.write(p, f"clip_{i:02d}.mp4")
    return out_zip
