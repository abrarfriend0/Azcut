"""Clip Grabber - celebrity name / video link -> clean 1080p moment clips.

Bilkul saaf clips: no captions, no overlays, no ranking graphics.
User selects: celebrity name OR video link, clip count, seconds,
aspect ratio (16:9 / 9:16 / 1:1). Moments found via rank.py's
audio-energy detection.
"""

import glob
import math
import os
import re
import subprocess
import zipfile

import rank

RATIOS = {
    "16:9": (1920, 1080),   # YouTube
    "9:16": (1080, 1920),   # Shorts / Reels / TikTok
    "1:1": (1080, 1080),    # Instagram post
}


class ClipError(Exception):
    pass


_FACE_CASCADE = None


def _face_cascade():
    """Lazy Haar cascade (bundled with OpenCV)."""
    global _FACE_CASCADE
    if _FACE_CASCADE is None:
        import cv2
        _FACE_CASCADE = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    return _FACE_CASCADE


def _gray_small(frame, max_w=480):
    import cv2
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    scale = 1.0
    if gray.shape[1] > max_w:
        scale = gray.shape[1] / max_w
        gray = cv2.resize(gray, (max_w, int(gray.shape[0] / scale)))
    return gray, scale


def face_center_in_segment(src, start, seconds):
    """Segment mein sab se bare chehre ki median position (source coords).

    Returns (cx, cy, W, H) ya None (koi chehra nahi).
    """
    import cv2
    cap = cv2.VideoCapture(src)
    if not cap.isOpened():
        return None
    W = cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0
    H = cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0
    cascade = _face_cascade()
    centers = []
    t = start
    while t < start + seconds:
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ret, frame = cap.read()
        if not ret:
            break
        gray, scale = _gray_small(frame)
        faces = cascade.detectMultiScale(gray, 1.2, 4)
        if len(faces):
            x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])
            centers.append(((x + fw / 2) * scale, (y + fh / 2) * scale))
        t += 0.5
    cap.release()
    if not centers or not W or not H:
        return None
    centers.sort()
    return centers[len(centers) // 2][0], centers[len(centers) // 2][1], W, H


def rank_windows_by_face(src, windows, seconds):
    """Windows ko solo-face preference se rank karo.

    Returns [(start, face_score)] — face_score 0..1: 1 = har sample mein
    aik hi bara chehra (target jaisa solo shot), 0 = bheer/koi chehra nahi.
    """
    import cv2
    cap = cv2.VideoCapture(src)
    if not cap.isOpened():
        return [(s, 0.0) for s in windows]
    W = cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 1
    cascade = _face_cascade()
    out = []
    for s in windows:
        samples, solo = 0, 0
        for dt in (0.5, seconds / 2, max(seconds - 0.5, 0.6)):
            cap.set(cv2.CAP_PROP_POS_MSEC, (s + dt) * 1000)
            ret, frame = cap.read()
            if not ret:
                continue
            gray, scale = _gray_small(frame)
            faces = cascade.detectMultiScale(gray, 1.2, 4)
            big = [f for f in faces if f[2] * scale > W * 0.10]
            samples += 1
            if len(big) == 1:
                solo += 1
        out.append((s, solo / max(samples, 1)))
    cap.release()
    return out


def _crop_for_ratio(W, H, tw, th, face):
    """Target ratio ke liye source crop rect (face-aware)."""
    W, H = int(W), int(H)
    if tw * H <= th * W:
        cw, ch = int(H * tw / th), H
    else:
        cw, ch = W, int(W * th / tw)
    cw -= cw % 2
    ch -= ch % 2
    cw, ch = max(cw, 2), max(ch, 2)
    if face and W > cw:
        cx, _cy = face[0], face[1]
        x0 = int(min(max(cx - cw / 2, 0), W - cw))
    else:
        x0 = (W - cw) // 2
    if face and H > ch:
        _cx, cy = face[0], face[1]
        y0 = int(min(max(cy - ch / 2, 0), H - ch))
    else:
        y0 = (H - ch) // 2
    x0 -= x0 % 2
    y0 -= y0 % 2
    return cw, ch, max(x0, 0), max(y0, 0)


# ----------------------------------------------------------------------------
# Face identity (reference photo): "sirf wahi celebrity"
# ----------------------------------------------------------------------------

FACE_MATCH_THRESHOLD = 70.0  # LBPH confidence: kam = behtar match
FACE_SIZE = 100


def extract_ref_face(photo_path):
    """Reference photo se sab se bara chehra crop karo (grayscale 100x100).

    Returns numpy array, ya None (koi chehra nahi mila).
    """
    import cv2
    import numpy as np
    img = cv2.imread(photo_path)
    if img is None:
        return None
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = _face_cascade().detectMultiScale(gray, 1.2, 4)
    if not len(faces):
        return None
    x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])
    # thora margin ke sath crop
    m = int(fw * 0.15)
    x0, y0 = max(x - m, 0), max(y - m, 0)
    x1, y1 = min(x + fw + m, gray.shape[1]), min(y + fh + m, gray.shape[0])
    crop = gray[y0:y1, x0:x1]
    crop = cv2.resize(crop, (FACE_SIZE, FACE_SIZE))
    return cv2.equalizeHist(crop)


def _augment_face(face):
    """Training samples: original + flip + brightness variants."""
    import cv2
    import numpy as np
    out = [face]
    out.append(cv2.flip(face, 1))
    for b in (-25, 25):
        v = np.clip(face.astype(int) + b, 0, 255).astype("uint8")
        out.append(v)
    for ang in (-8, 8):
        M = cv2.getRotationMatrix2D((FACE_SIZE / 2, FACE_SIZE / 2), ang, 1)
        out.append(cv2.warpAffine(face, M, (FACE_SIZE, FACE_SIZE)))
    return out


def train_face_recognizer(ref_face):
    """Reference chehre par LBPH recognizer train karo."""
    import cv2
    import numpy as np
    samples = _augment_face(ref_face)
    rec = cv2.face.LBPHFaceRecognizer_create()
    rec.train(samples, np.array([0] * len(samples)))
    return rec


def _norm_face(gray, x, y, fw, fh):
    import cv2
    m = int(fw * 0.15)
    x0, y0 = max(x - m, 0), max(y - m, 0)
    x1, y1 = min(x + fw + m, gray.shape[1]), min(y + fh + m, gray.shape[0])
    crop = gray[y0:y1, x0:x1]
    crop = cv2.resize(crop, (FACE_SIZE, FACE_SIZE))
    return cv2.equalizeHist(crop)


def face_matches(recognizer, gray, x, y, fw, fh):
    """(match: bool, confidence: float) — kam confidence = behtar."""
    try:
        _label, conf = recognizer.predict(_norm_face(gray, x, y, fw, fh))
    except Exception:  # noqa: BLE001
        return False, 999.0
    return conf < FACE_MATCH_THRESHOLD, float(conf)


def rank_windows_by_identity(src, windows, seconds, recognizer):
    """Windows ko FACE IDENTITY se rank karo.

    Returns [(start, score)]: 1.0 = har sample mein reference jaisa
    solo chehra; neeche = doosre log / bheer / koi chehra nahi.
    """
    import cv2
    cap = cv2.VideoCapture(src)
    if not cap.isOpened():
        return [(s, 0.0) for s in windows]
    W = cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 1
    cascade = _face_cascade()
    out = []
    for s in windows:
        samples, score_sum = 0, 0.0
        for dt in (0.5, seconds / 2, max(seconds - 0.5, 0.6)):
            cap.set(cv2.CAP_PROP_POS_MSEC, (s + dt) * 1000)
            ret, frame = cap.read()
            if not ret:
                continue
            gray, scale = _gray_small(frame)
            faces = cascade.detectMultiScale(gray, 1.2, 4)
            big = [(x, y, fw, fh) for (x, y, fw, fh) in faces
                   if fw * scale > W * 0.10]
            samples += 1
            matched = [f for f in big
                       if face_matches(recognizer, gray, *f)[0]]
            if len(big) == 1 and matched:
                score_sum += 1.0
            elif matched:
                score_sum += 0.6
            elif len(big) == 1:
                score_sum += 0.15
        out.append((s, score_sum / max(samples, 1)))
    cap.release()
    return out


def identity_face_center(src, start, seconds, recognizer):
    """Reference se milte chehre ki median position, ya None."""
    import cv2
    cap = cv2.VideoCapture(src)
    if not cap.isOpened():
        return None
    W = cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0
    H = cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0
    cascade = _face_cascade()
    centers = []
    t = start
    while t < start + seconds:
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ret, frame = cap.read()
        if not ret:
            break
        gray, scale = _gray_small(frame)
        faces = cascade.detectMultiScale(gray, 1.2, 4)
        best, best_conf = None, 999.0
        for (x, y, fw, fh) in faces:
            ok, conf = face_matches(recognizer, gray, x, y, fw, fh)
            if ok and conf < best_conf:
                best, best_conf = (x, y, fw, fh), conf
        if best:
            x, y, fw, fh = best
            centers.append(((x + fw / 2) * scale, (y + fh / 2) * scale))
        t += 0.5
    cap.release()
    if not centers or not W or not H:
        return None
    centers.sort()
    mid = centers[len(centers) // 2]
    return mid[0], mid[1], W, H


def _yt_base():
    return {
        "quiet": True, "no_warnings": True, "noplaylist": True,
        "socket_timeout": 30, "retries": 2,
        # web pehle (HD), na chale to android (bot-check se bachao)
        "extractor_args": {"youtube": {"player_client": ["web", "android"]}},
    }


def is_youtube_url(s):
    s = (s or "").strip().lower()
    return ("youtube.com/watch" in s or "youtu.be/" in s
            or "youtube.com/shorts/" in s)


def search_videos(query, n, workdir, extra_keywords=None):
    """Celebrity/topic name -> top n YouTube video URLs (views order).

    v2.20: extra_keywords — additional search phrases (e.g. "interview",
    "movie scene") to find more videos of the same person.
    Returns [(url, duration_sec)].
    """
    try:
        from yt_dlp import YoutubeDL
    except ImportError:
        raise ClipError(
            "yt-dlp installed nahi hai - install.bat dobara chala kar "
            "libraries install karein.")
    base = _yt_base()
    urls = []
    # v2.20: search main query + extra keywords, combine results
    all_queries = [query] + [k.strip() for k in (extra_keywords or []) if k.strip()]
    seen_urls = set()
    search_ok = False
    for q in all_queries:
        try:
            with YoutubeDL(base) as ydl:
                pl = ydl.extract_info(f"ytsearch{max(n * 2, 8)}:{q}",
                                      download=False, process=False)
            search_ok = True
        except Exception:  # noqa: BLE001
            continue
        for e in (pl.get("entries") or []):
            u = (e or {}).get("webpage_url") or (e or {}).get("url")
            if u and u not in seen_urls:
                seen_urls.add(u)
                urls.append(u)
    if not search_ok and not urls:
        raise ClipError("YouTube search failed — try again in a bit.")
    metas = []
    with YoutubeDL(base) as ydl:
        for u in urls[:max(n * 3, 12)]:
            try:
                v = ydl.extract_info(u, download=False)
            except Exception:  # noqa: BLE001
                continue
            if v and v.get("id"):
                metas.append(v)

    def score(m):
        dur = m.get("duration") or 0
        if dur <= 0:
            return -1
        # v2.20: long videos (20+ min) preferred — more clips per video
        bonus = 1000000 if dur >= 1200 else 0
        return (m.get("view_count") or 0) + bonus

    metas.sort(key=score, reverse=True)
    out = []
    for m in metas:
        if score(m) < 0:
            continue
        url = (m.get("webpage_url")
               or f"https://www.youtube.com/watch?v={m.get('id')}")
        out.append((url, m.get("duration") or 0))
        if len(out) >= n:
            break
    if not out:
        raise ClipError("No video found for this name. Try something else.")
    return out


def download_1080(url, workdir, tag):
    """Best <=1080p mp4 download. Returns path, ya None (fail)."""
    from yt_dlp import YoutubeDL
    opts = dict(
        _yt_base(),
        format=("bv*[ext=mp4][height<=1080]+ba[ext=m4a]/"
                "b[ext=mp4][height<=1080]/b[ext=mp4]/b"),
        merge_output_format="mp4",
        outtmpl=os.path.join(workdir, f"grab_{tag}.%(ext)s"),
    )
    with YoutubeDL(opts) as ydl:
        try:
            ydl.download([url])
        except Exception:  # noqa: BLE001
            return None
    got = sorted(glob.glob(os.path.join(workdir, f"grab_{tag}.mp4")),
                 key=os.path.getmtime)
    return got[-1] if got else None


def cut_clean_clip(src, out, start, seconds, ratio, recognizer=None):
    """Ek saaf clip kaato: chosen ratio, 1080, no captions/overlays.

    Face-tracked: recognizer mile to REFERENCE chehre par crop centered
    (sirf wahi celebrity); warna sab se bare chehre par.
    """
    w, h = RATIOS.get(ratio, RATIOS["16:9"])
    dur = rank.probe_duration(src)
    if dur <= 0:
        raise ClipError("Could not get the video duration.")
    take = min(seconds, dur)
    start = min(max(start, 0.0), max(dur - take, 0.0))
    try:
        if recognizer is not None:
            face = identity_face_center(src, start, take, recognizer)
            if face is None:  # reference nahi mila to bare chehre par
                face = face_center_in_segment(src, start, take)
        else:
            face = face_center_in_segment(src, start, take)
    except Exception:  # noqa: BLE001
        face = None
    W = face[2] if face else 0
    H = face[3] if face else 0
    if W and H:
        cw, ch, x0, y0 = _crop_for_ratio(W, H, w, h, face)
        crop_vf = f"crop={cw}:{ch}:{x0}:{y0},"
    else:
        crop_vf = (f"scale={w}:{h}:force_original_aspect_ratio=increase,"
                   f"crop={w}:{h},")
    vf = (f"[0:v]{crop_vf}setsar=1,fps=30,scale={w}:{h},"
          f"format=yuv420p[v]")
    cmd = (["ffmpeg", "-y", "-v", "error",
            "-ss", f"{start:.2f}", "-t", f"{take:.2f}", "-i", src,
            "-filter_complex", vf,
            "-map", "[v]", "-map", "0:a?",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-c:a", "aac", "-b:a", "128k",
            "-movflags", "+faststart", "-shortest", out])
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(out):
        raise ClipError(f"Could not cut the clip: {r.stderr[-300:]}")
    return out


def make_zip(paths, out_zip):
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for i, p in enumerate(paths, 1):
            z.write(p, f"clip_{i:02d}.mp4")
    return out_zip
