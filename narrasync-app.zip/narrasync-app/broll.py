"""B-roll engine for Az Cut Studio (v2.15).

- 5 Unicode text styles (small-caps default, bold-script, bold-fraktur,
  monospace, fullwidth) for auto "important words" overlays.
- Typewriter reveal + shake ASS overlay generation.
- Pixabay stock-video fetch per script segment (cached by keyword).
- Typing-SFX slicer (user's own typing-loop.mp3) to the reveal duration.
"""
import os
import re
import subprocess

_HERE = os.path.dirname(os.path.abspath(__file__))
TYPING_MP3 = os.path.join(_HERE, "assets", "sfx", "typing-loop.mp3")


# ---------------------------------------------------------------- styles ---
def to_smallcaps(text):
    """a-z -> Unicode small capitals (renders in any font)."""
    table = {
        "a": "\u1d00", "b": "\u0299", "c": "\u1d04", "d": "\u1d05",
        "e": "\u1d07", "f": "\u0493", "g": "\u0262", "h": "\u029c",
        "i": "\u026a", "j": "\u1d0a", "k": "\u1d0b", "l": "\u029f",
        "m": "\u1d0d", "n": "\u0274", "o": "\u1d0f", "p": "\u1d18",
        "q": "\u01eb", "r": "\u0280", "s": "s", "t": "\u1d1b",
        "u": "\u1d1c", "v": "\u1d20", "w": "\u1d21", "x": "x",
        "y": "\u028f", "z": "\u1d22",
    }
    out = []
    for ch in text:
        low = ch.lower()
        if low in table:
            sc = table[low]
            out.append(sc.upper() if ch.isupper() and sc not in ("s", "x") else sc)
        else:
            out.append(ch)
    return "".join(out)


def _math_block(text, cap_base, low_base, digit_base=None):
    out = []
    for ch in text:
        o = ord(ch)
        if "A" <= ch <= "Z":
            out.append(chr(cap_base + o - ord("A")))
        elif "a" <= ch <= "z":
            out.append(chr(low_base + o - ord("a")))
        elif digit_base and "0" <= ch <= "9":
            out.append(chr(digit_base + o - ord("0")))
        else:
            out.append(ch)
    return "".join(out)


def to_bold_script(text):
    """A-Z U+1D4D0, a-z U+1D4EA (needs Segoe UI Symbol on Windows)."""
    return _math_block(text, 0x1D4D0, 0x1D4EA)


def to_bold_fraktur(text):
    """A-Z U+1D56C, a-z U+1D586 (needs Segoe UI Symbol on Windows)."""
    return _math_block(text, 0x1D56C, 0x1D586)


def to_monospace(text):
    """A-Z U+1D670, a-z U+1D68A, 0-9 U+1D7F6."""
    return _math_block(text, 0x1D670, 0x1D68A, 0x1D7F6)


def to_fullwidth(text):
    """A-Z U+FF21, a-z U+FF41, 0-9 U+FF10, space U+3000."""
    out = []
    for ch in text:
        o = ord(ch)
        if "A" <= ch <= "Z":
            out.append(chr(0xFF21 + o - ord("A")))
        elif "a" <= ch <= "z":
            out.append(chr(0xFF41 + o - ord("a")))
        elif "0" <= ch <= "9":
            out.append(chr(0xFF10 + o - ord("0")))
        elif ch == " ":
            out.append("\u3000")
        else:
            out.append(ch)
    return "".join(out)


TEXT_STYLES = {
    "smallcaps": ("Small Caps", to_smallcaps,
                  "Type something to start"),
    "boldscript": ("Bold Script", to_bold_script,
                   "Type something to start"),
    "boldfraktur": ("Bold Fraktur", to_bold_fraktur,
                    "Type something to start"),
    "monospace": ("Monospace", to_monospace,
                  "Type something to start"),
    "fullwidth": ("Fullwidth", to_fullwidth,
                  "Type something to start"),
}


def style_text(text, style):
    fn = TEXT_STYLES.get(style, TEXT_STYLES["smallcaps"])[1]
    return fn(text or "")


# ------------------------------------------------------- important words ---
def pick_important_words(text, max_words=6):
    """Heuristic: long words, ALL-CAPS, digits — like the explainer wordbox."""
    words = re.findall(r"[A-Za-z0-9']+", text or "")
    scored = []
    for w in words:
        s = 0
        if len(w) >= 6:
            s += 2
        if len(w) >= 9:
            s += 1
        if w.isupper() and len(w) > 1:
            s += 3
        if any(c.isdigit() for c in w):
            s += 2
        scored.append((s, w))
    picked = {w for s, w in scored if s > 0}
    if not picked:
        picked = set(words[:4])
    ordered = [w for w in words if w in picked]
    # de-dup while keeping order, cap length
    seen, out = set(), []
    for w in ordered:
        if w.lower() not in seen:
            seen.add(w.lower())
            out.append(w)
        if len(out) >= max_words:
            break
    return out


def overlay_line(text):
    """The display line: whole text if short, else the important words."""
    words = re.findall(r"[A-Za-z0-9']+", text or "")
    if len(words) <= 8:
        line = " ".join(words)
    else:
        line = " ".join(pick_important_words(text))
    return line[:48]


# ------------------------------------------------------------- ASS -------
def _ass_time(s):
    h = int(s // 3600)
    m = int((s % 3600) // 60)
    return f"{h}:{m:02d}:{s % 60:05.2f}"


def _ass_escape(t):
    return t.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}")


_POS = {
    "top": (8, 0.10),
    "middle": (5, 0.50),
    "bottom": (2, 0.86),
}


def broll_ass(style_lines_out=None, W=1280, H=720, font="Arial"):
    """ASS style definition for the B-roll overlay text."""
    size = max(28, int(H * 0.055))
    style = (f"Style: BROLL,{font},{size},&H00FFFFFF,&H000000FF,"
             f"&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,3,1,8,20,20,24,1")
    return [style]


def broll_dialogues(text, style, t0, seg_end, W=1280, H=720,
                    cps=14, shake=True, pos="middle"):
    """Dialogue events: typewriter reveal (per char) + shake + hold.

    cps: characters per second. Returns (dialogue_lines, reveal_duration).
    """
    styled = style_text(text, style)
    if not styled.strip():
        return [], 0.0
    align, yfrac = _POS.get(pos, _POS["middle"])
    x, y = W // 2, int(H * yfrac)
    n = len(styled)
    char_dur = 1.0 / max(4, cps)
    type_dur = n * char_dur
    hold_end = min(t0 + type_dur + 1.6, max(t0 + 0.4, seg_end - 0.25))
    lines = []
    # typewriter: progressive reveal; shake splits each step into jitter frames
    for i in range(1, n + 1):
        s = t0 + (i - 1) * char_dur
        e = t0 + i * char_dur
        part = _ass_escape(styled[:i])
        if shake:
            # 3 jitter frames per character step
            step = char_dur / 3
            jits = [(3, 2), (-3, -2), (2, -3)]
            for k, (jx, jy) in enumerate(jits):
                fs = s + k * step
                fe = min(s + (k + 1) * step, e)
                tags = f"{{\\an{align}\\pos({x + jx},{y + jy})}}"
                lines.append(
                    f"Dialogue: 0,{_ass_time(fs)},{_ass_time(fe)},"
                    f"BROLL,,0,0,0,,{tags}{part}")
        else:
            tags = f"{{\\an{align}\\pos({x},{y})}}"
            lines.append(
                f"Dialogue: 0,{_ass_time(s)},{_ass_time(e)},"
                f"BROLL,,0,0,0,,{tags}{part}")
    # hold the full line (steady, no shake)
    if hold_end > t0 + type_dur + 0.05:
        tags = f"{{\\an{align}\\pos({x},{y})}}"
        lines.append(
            f"Dialogue: 0,{_ass_time(t0 + type_dur)},{_ass_time(hold_end)},"
            f"BROLL,,0,0,0,,{tags}{_ass_escape(styled)}")
    return lines, type_dur


# ------------------------------------------------------- stock fetch ---
_broll_cache = {}


def fetch_broll_clip(api_key, keyword, out_dir, idx=0):
    """Download one Pixabay stock video for keyword. Returns path or None."""
    kw = (keyword or "").strip().lower()
    if not kw:
        return None
    hit = _broll_cache.get(kw)
    if hit and os.path.exists(hit):
        return hit
    try:
        from pixabay import search_videos, download
        res = search_videos(api_key, kw, per_page=6)
        items = (res or {}).get("items") or []
        if not items:
            # try first word only
            w = kw.split()[0]
            if w != kw:
                return fetch_broll_clip(api_key, w, out_dir, idx)
            return None
        item = items[min(idx, len(items) - 1)]
        url = item.get("url")
        if not url:
            return None
        safe = re.sub(r"[^a-z0-9]+", "_", kw)[:24] or "clip"
        out = os.path.join(out_dir, f"broll_{safe}_{idx}.mp4")
        download(url, out)
        if os.path.exists(out) and os.path.getsize(out) > 10000:
            _broll_cache[kw] = out
            return out
        return None
    except Exception:
        return None


def plan_broll(api_key, segments):
    """Lightweight plan: keywords + preview thumb per segment (no download)."""
    from pipeline import extract_keywords
    try:
        from pixabay import search_videos
    except Exception:
        search_videos = None
    plan = []
    for seg in segments:
        kws = extract_keywords(seg, top_k=2)
        kw = " ".join(kws) if kws else (seg or "")[:24]
        preview, dur = "", 0
        if search_videos and api_key and kw:
            try:
                res = search_videos(api_key, kw, per_page=4)
                items = (res or {}).get("items") or []
                if items:
                    preview = items[0].get("preview") or ""
                    dur = items[0].get("duration") or 0
            except Exception:
                pass
        plan.append({"keywords": kw, "preview": preview,
                     "duration": dur})
    return plan


# ------------------------------------------------------- typing sfx ---
def typing_sfx_slice(duration, out_wav):
    """Slice/loop the user's typing-loop.mp3 to exactly `duration` seconds."""
    duration = max(0.3, float(duration))
    if not os.path.exists(TYPING_MP3):
        return None
    try:
        # loop the source if the reveal outlasts the 8s recording
        r = subprocess.run(
            ["ffmpeg", "-v", "error", "-y", "-stream_loop", "-1",
             "-i", TYPING_MP3, "-t", f"{duration:.2f}",
             "-ac", "1", "-ar", "44100", "-c:a", "pcm_s16le", out_wav],
            capture_output=True)
        if r.returncode == 0 and os.path.exists(out_wav):
            return out_wav
        return None
    except Exception:
        return None
