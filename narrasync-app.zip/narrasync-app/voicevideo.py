"""Voiceover Video - voiceover -> auto YouTube-clip video.

Flow:
  voiceover -> Whisper word timestamps -> keyword scenes (<=6s each) ->
  YouTube 1080p clip per keyword -> slow Ken Burns zoom in/out +
  fade in/out per scene -> concat -> voiceover muxed.
Transcription bhi return hoti hai (neeche dikhane ke liye).
"""

import os
import math
import re
import subprocess

import rank
import clipgrab as cg


class VVError(Exception):
    pass


STOPWORDS = set("""
a an the and or but if then else when while of at by for with about into
through during before after above below to from up down in out on off over
under again further once here there all any both each few more most other
some such no nor not only own same so than too very can will just don should
now is are was were be been being have has had having do does did doing would
could ought i you he she it we they them his her its our their this that these
those as my me him us what which who whom whose where why how
hai hain ho ga gi ge tha thi the hon hai ke ki ka ko se mein me ne na nai nahi
aur or ye yeh wo woh jo to per par bhi bhee sirf bas bahut bohat kya kyon kyun
kab kahan kidhar kaise jaisa waisa itna utna jitna kuch sab sabhi har koi kisi
ne apna apne apni un unka unki unke tum tumhara tumhare tumhari main mera mere
meri hum hamara hamare aap aapka ap apke liye liyye wala wali wale walon tak
taraf darmiyan darmian beech andar bahar upar neeche pehle baad phir phr bhi
agar magar lekin kyunki kyuke taake takeh jese jaise wese waise
aik ek do teen char panch che saat aath nau das wala wali
""".split())


def extract_keywords(words):
    """words: [(word, start, end)] -> [keyword...] score order mein.

    Proper nouns (capitalized) ko double weight; stopwords/short words skip.
    """
    scored, order = {}, {}
    for idx, (w, _s, _e) in enumerate(words):
        k = re.sub(r"[^a-zA-Z0-9]", "", w).lower()
        if len(k) < 3 or k in STOPWORDS:
            continue
        bonus = 2 if w[:1].isupper() else 1
        scored[k] = scored.get(k, 0) + bonus
        order.setdefault(k, idx)
    return sorted(scored, key=lambda k: (-scored[k], order[k]))


def split_scenes(words, audio_dur, max_scene=6.0, max_scenes=12):
    """Word timestamps -> scenes.

    Har scene <= max_scene second; scenes poori audio duration ko tile
    karti hain (pehli 0 se, aakhri audio_dur tak). Har scene: keyword +
    alt keywords + text + start/end.
    """
    if not words:
        raise VVError("Transcription mein koi lafz nahi mila.")
    groups, cur = [], []
    for w, s, e in words:
        cur.append((w, s, e))
        if e - cur[0][1] >= max_scene:
            groups.append(cur)
            cur = []
    if cur:
        groups.append(cur)
    # chhoti scenes (<2s) ko parosi mein merge karo
    merged = []
    for g in groups:
        dur = g[-1][2] - g[0][1]
        if merged and dur < 2.0:
            merged[-1].extend(g)
        else:
            merged.append(list(g))
    groups = merged[:max_scenes]
    # boundaries: poori audio tile karo
    bounds = [0.0] + [g[-1][2] for g in groups[:-1]] + [audio_dur]
    global_kw = extract_keywords(words)
    scenes = []
    for i, g in enumerate(groups):
        start, end = bounds[i], bounds[i + 1]
        if end - start < 0.8:
            continue
        txt = " ".join(w for w, _s, _e in g)
        scene_kw = extract_keywords(g)
        kw = scene_kw[0] if scene_kw else (
            global_kw[0] if global_kw else "nature")
        alt = []
        for k in scene_kw[1:3] + global_kw[:3]:
            if k != kw and k not in alt:
                alt.append(k)
            if len(alt) >= 3:
                break
        scenes.append({
            "start": round(start, 2), "end": round(end, 2),
            "keyword": kw, "alt": alt, "text": txt,
        })
    if not scenes:
        raise VVError("Scenes nahi ban saken.")
    return scenes


def kenburns_cut(src, out, start, dur, w, h, zoom_in):
    """Slow zoom in/out + fade in/out, bilkul saaf (no text)."""
    frames = max(1, int(round(dur * 30)))
    bw, bh = w * 2, h * 2
    z = f"1+0.18*on/{frames}" if zoom_in else f"1.18-0.18*on/{frames}"
    fo = max(dur - 0.4, 0.0)
    vdur = rank.probe_duration(src)
    loop_args = []
    if 0 < vdur < dur:
        loop_args = ["-stream_loop", str(math.ceil(dur / vdur))]
    vf = (f"[0:v]scale={bw}:{bh}:force_original_aspect_ratio=increase,"
          f"crop={bw}:{bh},setsar=1,fps=30,"
          f"zoompan=z='{z}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)'"
          f":d=1:s={w}x{h}:fps=30,"
          f"fade=t=in:st=0:d=0.4,fade=t=out:st={fo:.2f}:d=0.4,"
          f"format=yuv420p[v]")
    cmd = (["ffmpeg", "-y", "-v", "error"] + loop_args +
           ["-ss", f"{start:.2f}", "-t", f"{dur:.2f}", "-i", src,
            "-filter_complex", vf, "-map", "[v]", "-an",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-movflags", "+faststart", out])
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(out):
        raise VVError(f"Scene render nahi ho saki: {r.stderr[-300:]}")
    return out


def build_voiceover_video(audio_path, scenes, ratio, workdir,
                         progress_cb=None):
    """Scenes -> final mp4 (voiceover muxed). Returns final path."""
    w, h = cg.RATIOS.get(ratio, cg.RATIOS["16:9"])
    seg_paths = []
    last_video = None
    for i, sc in enumerate(scenes):
        kw = sc["keyword"]
        dur = sc["end"] - sc["start"]
        if progress_cb:
            progress_cb(f"Scene {i + 1}/{len(scenes)}: '{kw}' ki video...")
        video = None
        for q in [kw] + sc.get("alt", []):
            try:
                urls = cg.search_videos(q, 1, workdir)
            except Exception:  # noqa: BLE001
                continue
            if urls:
                video = cg.download_1080(urls[0], workdir, f"vv{i}")
                if video:
                    break
        if not video:
            video = last_video  # pichli video reuse karo
        if not video:
            raise VVError(f"'{kw}' ke liye koi video nahi mili. "
                          f"Keyword badal kar dobara try karo.")
        last_video = video
        vdur = rank.probe_duration(video)
        start = rank.find_moment_start(video, dur) if vdur > dur else 0.0
        out = os.path.join(workdir, f"scene_{i:02d}.mp4")
        kenburns_cut(video, out, start, dur, w, h,
                     zoom_in=(i % 2 == 0))
        seg_paths.append(out)
        try:
            os.remove(video)  # disk bachao
        except OSError:  # noqa: BLE001
            pass
    lst = os.path.join(workdir, "list.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p in seg_paths:
            f.write(f"file '{p}'\n")
    vcat = os.path.join(workdir, "video.mp4")
    r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat",
                        "-safe", "0", "-i", lst, "-c", "copy", vcat],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise VVError(f"Video jor nahi saki: {r.stderr[-300:]}")
    final = os.path.join(workdir, "voiceover_video.mp4")
    r = subprocess.run(["ffmpeg", "-y", "-v", "error",
                        "-i", vcat, "-i", audio_path,
                        "-c:v", "copy", "-c:a", "aac", "-b:a", "128k",
                        "-shortest", "-movflags", "+faststart", final],
                       capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(final):
        raise VVError(f"Final video nahi ban saki: {r.stderr[-300:]}")
    return final
