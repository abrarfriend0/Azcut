"""CapCut-style SFX engine for Az Cut (v2.17).

Ports the 100 Web Audio recipes from the CapCut sound-effects guide to
numpy. Each recipe is a list of tone()/noise() events with the same
parameters as the browser version:
  tone: f, f1 (exp freq ramp), type, dur, vol, delay, attack, vib{rate,depth}
  noise: f, f1 (filter freq ramp), ftype, q, dur, vol, delay, attack
Output: float32 mono 44.1kHz, matching pipeline.SFX_SR.
"""
import json
import os

import numpy as np

SR = 44100

_HERE = os.path.dirname(os.path.abspath(__file__))
RECIPES_PATH = os.path.join(_HERE, "assets", "sfx_recipes.json")
META_PATH = os.path.join(_HERE, "assets", "sfx_meta.json")

_recipes = None
_meta = None
_cache = {}


def _load():
    global _recipes, _meta
    if _recipes is None:
        with open(RECIPES_PATH, encoding="utf-8") as f:
            _recipes = {r["name"]: r["events"] for r in json.load(f)}
    if _meta is None:
        with open(META_PATH, encoding="utf-8") as f:
            _meta = json.load(f)
    return _recipes, _meta


def list_sfx():
    """[(id, label, category)] for all 100 sounds."""
    _, meta = _load()
    return [(m["id"], m["label"], m["cat"]) for m in meta]


def _envelope(m, vol, attack):
    env = np.ones(m, dtype=np.float32)
    a = max(1, int(attack * SR))
    a = min(a, m)
    env[:a] = np.linspace(0.0, 1.0, a, dtype=np.float32)
    if m > a:
        # exponential decay to 0.001 (matches Web Audio exponentialRamp)
        env[a:] = np.exp(np.linspace(0.0, np.log(0.001 / max(vol, 1e-6)),
                                     m - a, dtype=np.float32))
    return (env * vol).astype(np.float32)


def _tone(n_total, p):
    f = max(float(p.get("f", 440)), 1.0)
    f1 = p.get("f1")
    f1 = max(float(f1), 1.0) if f1 else None
    dur = float(p.get("dur", 0.3))
    vol = min(float(p.get("vol", 0.4)), 0.6)
    delay = float(p.get("delay", 0))
    attack = float(p.get("attack", 0.006))
    typ = p.get("type", "sine")
    vib = p.get("vib")

    m = int(dur * SR)
    if m <= 0:
        return
    t = np.arange(m, dtype=np.float32) / SR
    if f1 and f1 != f:
        freq = f * (f1 / f) ** (t / dur)
    else:
        freq = np.full(m, f, dtype=np.float32)
    if vib:
        freq = freq + float(vib["depth"]) * np.sin(
            2 * np.pi * float(vib["rate"]) * t)
        freq = np.maximum(freq, 1.0)
    phase = 2 * np.pi * np.cumsum(freq, dtype=np.float64) / SR
    if typ == "square":
        osc = np.sign(np.sin(phase))
    elif typ == "sawtooth":
        osc = 2 * ((phase / (2 * np.pi)) % 1) - 1
    elif typ == "triangle":
        osc = 2 * np.abs(2 * ((phase / (2 * np.pi)) % 1) - 1) - 1
    else:
        osc = np.sin(phase)
    sig = (osc * _envelope(m, vol, attack)).astype(np.float32)
    start = int(delay * SR)
    end = min(n_total, start + m)
    return start, end, sig[:max(0, end - start)]


def _biquad_coeffs(ftype, freq, q):
    """RBJ cookbook coefficients for lowpass/highpass/bandpass."""
    w0 = 2 * np.pi * max(10.0, min(20000.0, freq)) / SR
    alpha = np.sin(w0) / (2 * max(0.1, q))
    cw = np.cos(w0)
    if ftype == "lowpass":
        b0 = (1 - cw) / 2
        b1 = 1 - cw
        b2 = (1 - cw) / 2
    elif ftype == "highpass":
        b0 = (1 + cw) / 2
        b1 = -(1 + cw)
        b2 = (1 + cw) / 2
    else:  # bandpass (constant 0 dB peak gain)
        b0 = alpha
        b1 = 0.0
        b2 = -alpha
    a0 = 1 + alpha
    a1 = -2 * cw
    a2 = 1 - alpha
    return b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0


def _noise(n_total, p, rng):
    f = max(float(p.get("f", 1000)), 10.0)
    f1 = p.get("f1")
    f1 = max(float(f1), 10.0) if f1 else None
    ftype = p.get("ftype", "bandpass")
    q = float(p.get("q", 1)) if p.get("q") is not None else 1.0
    dur = float(p.get("dur", 0.5))
    vol = min(float(p.get("vol", 0.4)), 0.6)
    delay = float(p.get("delay", 0))
    attack = float(p.get("attack", 0.012))

    m = int(dur * SR)
    if m <= 0:
        return
    x = rng.standard_normal(m, dtype=np.float32)
    # time-varying biquad (frequency ramps exponentially like Web Audio)
    if f1 and f1 != f:
        freqs = f * (f1 / f) ** (np.arange(m, dtype=np.float64) / m)
    else:
        freqs = np.full(m, f)
    y = np.zeros(m, dtype=np.float32)
    x1 = x2 = y1 = y2 = 0.0
    # update coefficients every 64 samples for speed
    step = 64
    for s0 in range(0, m, step):
        s1 = min(m, s0 + step)
        fm = float(freqs[(s0 + s1) // 2])
        b0, b1, b2, a1, a2 = _biquad_coeffs(ftype, fm, q)
        for n in range(s0, s1):
            xn = float(x[n])
            yn = b0 * xn + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2, x1, y2, y1 = x1, xn, y1, yn
            y[n] = yn
    sig = (y * _envelope(m, vol, attack)).astype(np.float32)
    start = int(delay * SR)
    end = min(n_total, start + m)
    return start, end, sig[:max(0, end - start)]


def render(name):
    """Render a named SFX to float32 mono 44.1kHz numpy buffer."""
    if name in _cache:
        return _cache[name]
    recipes, _ = _load()
    events = recipes.get(name)
    if not events:
        return None
    total_dur = 0.0
    for kind, p in events:
        total_dur = max(total_dur, float(p.get("delay", 0)) +
                        float(p.get("dur", 0.3)) + 0.1)
    n_total = int(total_dur * SR) + 64
    mix = np.zeros(n_total, dtype=np.float32)
    rng = np.random.default_rng(abs(hash(name)) % (2 ** 31))
    for kind, p in events:
        if kind == "tone":
            r = _tone(n_total, p)
        else:
            r = _noise(n_total, p, rng)
        if r:
            s, e, sig = r
            if e > s and len(sig):
                mix[s:e] += sig
    peak = np.max(np.abs(mix))
    if peak > 0.95:
        mix = (mix * (0.95 / peak)).astype(np.float32)
    _cache[name] = mix
    return mix
