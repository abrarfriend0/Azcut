"""Rank Cut (v2.0) - ranking video maker for Az Cut.

Workflow: topic -> fetch clips (Pexels API / YouTube via yt-dlp) ->
cut D-second 9:16 segments -> overlay rank numbers + title ->
concat -> final vertical MP4.

Style matches viral "Ranking Best X" shorts: bold title on top
(keyword in red), numbered ranks down the left side, the current
rank highlighted red.
"""

import glob
import math
import os
import random
import re
import subprocess
import threading
import datetime
from concurrent.futures import ThreadPoolExecutor

W, H = 1080, 1920
RED = (255, 59, 48)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

_ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")


class RankError(Exception):
    pass


def _font(size):
    from PIL import ImageFont
    ttf = os.path.join(_ASSETS_DIR, "Anton-Regular.ttf")
    try:
        if os.path.exists(ttf):
            return ImageFont.truetype(ttf, size)
    except Exception:
        pass
    return ImageFont.load_default()


def probe_duration(path):
    """Duration in seconds (ffmpeg stderr parse, like pipeline.py)."""
    r = subprocess.run(["ffmpeg", "-i", path],
                       capture_output=True, text=True)
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", r.stderr)
    if not m:
        return 0.0
    h, mnt, s = int(m.group(1)), int(m.group(2)), float(m.group(3))
    return h * 3600 + mnt * 60 + s


# ----------------------------------------------------------------------------
# Clip sources
# ----------------------------------------------------------------------------

def _download_many(dl_fn, pairs, progress_cb=None, label="Clip"):
    """Download (url, out) pairs with 4 parallel threads.

    Returns out paths in order; failed items are skipped. Much faster
    than sequential downloads when fetching several clips.
    """
    total = len(pairs)
    if total == 0:
        return []
    outs = [None] * total
    done_n = [0]
    lock = threading.Lock()

    def _one(i):
        url, out = pairs[i]
        try:
            dl_fn(url, out)
            outs[i] = out
        except Exception:  # noqa: BLE001
            outs[i] = None
        if progress_cb:
            with lock:
                done_n[0] += 1
                try:
                    progress_cb(f"{label} {done_n[0]}/{total} download ho raha hai...")
                except Exception:  # noqa: BLE001
                    pass

    with ThreadPoolExecutor(max_workers=min(4, total)) as ex:
        list(ex.map(_one, range(total)))
    return [o for o in outs if o]


def fetch_pexels_clips(api_key, topic, n, workdir, progress_cb=None):
    """Search Pexels videos, download n files. Returns [paths]."""
    import pexels
    res = pexels.search(api_key, topic, kind="video", per_page=max(n, 3))
    items = res.get("items") or []
    pairs = [(it["url"], os.path.join(workdir, f"pex_{i}.mp4"))
             for i, it in enumerate(items[:n])]
    return _download_many(pexels.download, pairs, progress_cb, "Pexels clip")


def fetch_pixabay_clips(api_key, topic, n, workdir, progress_cb=None):
    """Search Pixabay videos, download n files. Returns [paths]."""
    import pixabay
    res = pixabay.search_videos(api_key, topic, per_page=max(n * 2, 6))
    items = res.get("items") or []
    # zyada views wale pehle (engaging first)
    items.sort(key=lambda it: it.get("views") or 0, reverse=True)
    pairs = [(it["url"], os.path.join(workdir, f"pxb_{i}.mp4"))
             for i, it in enumerate(items[:n])]
    return _download_many(pixabay.download, pairs, progress_cb, "Pixabay clip")


def _engagement_score(v):
    """YouTube Shorts ranking jaisa score.

    Sirf views nahi — poora formula:
    - views (base)
    - engagement rate: likes + comments per view (zyada interaction = zyada score)
    - recency: pichle 1 saal ki viral video ko boost (fresh viral wins)
    """
    views = v.get("view_count") or 0
    if views <= 0:
        return 0.0
    likes = v.get("like_count") or 0
    comments = v.get("comment_count") or 0
    rate = (likes + comments * 3) / views
    boost = 1 + min(rate * 10, 2)  # max 3x engagement boost
    try:
        ud = str(v.get("upload_date") or "")
        if len(ud) == 8:
            up = datetime.date(int(ud[:4]), int(ud[4:6]), int(ud[6:8]))
            age = (datetime.date.today() - up).days
            if 0 <= age <= 365:
                boost *= 1.2  # fresh viral
    except Exception:  # noqa: BLE001
        pass
    return views * boost


def _is_shortish(v):
    """Asli Shorts jaisi clip: 3 minute ya kam."""
    d = v.get("duration") or 0
    return 0 < d <= 180


def fetch_youtube_clips(topic, n, workdir, query_extra="", engaging=True,
                      progress_cb=None):
    """Search YouTube shorts via yt-dlp, download n mp4s. Returns [paths].

    engaging=True: Shorts ranking strategy — pehle candidates ka metadata,
    phir engagement score (views + likes/comments rate + recency), asli
    Shorts (<=3 min) ko tarjeeh; sirf top scorers download hote hain.
    query_extra: mood keywords, masalan "funny" ya "shocking insane".
    """
    try:
        from yt_dlp import YoutubeDL
    except ImportError:
        raise RankError(
            "yt-dlp installed nahi hai - install.bat dobara chala kar "
            "libraries install karein.")
    query = f"ytsearch{max(n * 3, 12)}:{topic} {query_extra} #shorts".strip()
    base = {
        "quiet": True, "no_warnings": True, "noplaylist": True,
        "socket_timeout": 30, "retries": 2,
        # web pehle (HD), na chale to android (bot-check se bachao)
        "extractor_args": {"youtube": {"player_client": ["web", "android"]}},
    }
    with YoutubeDL(base) as ydl:
        try:
            # pehle sirf URLs (flat) - aik kharab video poori search nahi rokegi
            pl = ydl.extract_info(query, download=False, process=False)
        except Exception as e:  # noqa: BLE001
            raise RankError(f"YouTube search failed: {e}")
    urls = []
    for e in (pl.get("entries") or []):
        u = (e or {}).get("webpage_url") or (e or {}).get("url")
        if u and u not in urls:
            urls.append(u)
    # har video ka metadata alag se - jo na khule wo skip
    metas = []
    with YoutubeDL(base) as ydl:
        for u in urls[:max(n * 3, 12)]:
            try:
                v = ydl.extract_info(u, download=False)
            except Exception:  # noqa: BLE001
                continue
            if v and v.get("id"):
                metas.append(v)
    if engaging:
        # Shorts strategy: pehle asli chhoti videos (<=3 min) mein se
        # engagement score lagao; kam paren to sab mein se.
        shorts = [m for m in metas if _is_shortish(m)]
        pool = shorts if len(shorts) >= n else metas
        pool.sort(key=_engagement_score, reverse=True)
    else:
        pool = metas
    top = pool[:n]
    print(f"[rank] {len(metas)} videos checked "
          f"({sum(1 for m in metas if _is_shortish(m))} shorts), top: "
          f"{[(v.get('view_count'), v.get('duration')) for v in top]}")
    dl_opts = dict(
        base,
        format=("bv*[ext=mp4][height<=1080]+ba[ext=m4a]/"
                "b[ext=mp4][height<=1080]/b[ext=mp4]/b"),
        merge_output_format="mp4",
        outtmpl=os.path.join(workdir, "yt_%(id)s.%(ext)s"),
    )
    with YoutubeDL(dl_opts) as ydl:
        for j, v in enumerate(top):
            vid = v.get("id")
            url = (v.get("webpage_url")
                   or f"https://www.youtube.com/watch?v={vid}")
            try:
                ydl.download([url])
            except Exception:  # noqa: BLE001
                continue  # age-gated/bot-check wali skip, agli try karo
            if progress_cb:
                try:
                    progress_cb(f"YouTube clip {j + 1}/{len(top)} download ho raha hai...")
                except Exception:  # noqa: BLE001
                    pass
    got = sorted(glob.glob(os.path.join(workdir, "yt_*.mp4")),
                 key=os.path.getmtime)
    # download order view-sorted hai, is liye mtime order = engaging order
    return got[-n:] if len(got) >= n else got


# ----------------------------------------------------------------------------
# Overlay graphics (PIL -> transparent PNG per rank)
# ----------------------------------------------------------------------------

def make_overlay_png(rank, total, title_prefix, title_keyword, out_path):
    """Full-frame transparent PNG: title on top, rank list on the left."""
    from PIL import Image, ImageDraw
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    dr = ImageDraw.Draw(img)

    # --- title: "Ranking Best" white + keyword red, centered ---
    f_title = _font(96)
    pre = (title_prefix or "").strip()
    key = (title_keyword or "").strip()
    w_pre = dr.textlength(pre + " ", font=f_title) if pre else 0
    w_key = dr.textlength(key, font=f_title) if key else 0
    x0 = (W - w_pre - w_key) / 2
    y = 110
    if pre:
        dr.text((x0, y), pre + " ", font=f_title, fill=WHITE,
                stroke_width=5, stroke_fill=BLACK)
    if key:
        dr.text((x0 + w_pre, y), key, font=f_title, fill=RED,
                stroke_width=5, stroke_fill=BLACK)

    # --- rank numbers down the left, current one red ---
    f_num = _font(104)
    x, y0, dy = 64, 430, 150
    for i in range(1, total + 1):
        col = RED if i == rank else WHITE
        dr.text((x, y0 + (i - 1) * dy), f"{i}.", font=f_num, fill=col,
                stroke_width=6, stroke_fill=BLACK)

    img.save(out_path)
    return out_path


# ----------------------------------------------------------------------------
# Segment cutting + assembly
# ----------------------------------------------------------------------------

def _sample_loudness(src):
    """EBU R128 momentary loudness over time: [(t_seconds, lufs), ...].

    Empty list = no usable audio.
    """
    try:
        cmd = ["ffmpeg", "-hide_banner", "-v", "info", "-i", src,
               "-map", "0:a:0", "-af", "ebur128=peak=true",
               "-f", "null", "-"]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        samples = []
        for line in (r.stderr or "").splitlines():
            m = re.search(r"t:\s*([\d.]+).*?M:\s*(-?[\d.]+)", line)
            if m:
                try:
                    samples.append((float(m.group(1)), float(m.group(2))))
                except ValueError:
                    pass
        return samples
    except Exception:  # noqa: BLE001
        return []


def _window_scores(samples, dur, seconds, step=0.5):
    """[(start, mean_loudness)] for every sliding window."""
    out = []
    t = 0.0
    while t <= dur - seconds:
        vals = [v for (tt, v) in samples if t <= tt < t + seconds]
        if vals:
            out.append((t, sum(vals) / len(vals)))
        t += step
    return out


def _center_on_peak(samples, win_start, seconds, dur):
    """Re-center a window so its loudest instant sits ~65% in."""
    win = [(tt, v) for (tt, v) in samples
           if win_start <= tt < win_start + seconds]
    peak_t = (max(win, key=lambda s: s[1])[0] if win
              else win_start + seconds / 2)
    return min(max(peak_t - seconds * 0.65, 0.0), dur - seconds)


def find_moment_start(src, seconds):
    """Find the most engaging `seconds`-long window in a clip.

    Uses audio energy (EBU R128 momentary loudness): the shocking/funny
    moment — slip, splash, scream, laugh, crash — is almost always the
    loudest part. The window is picked by max mean loudness so the clip
    contains the buildup AND the peak, not just dead air.
    Falls back to a random start if detection fails (e.g. no audio).
    """
    dur = probe_duration(src)
    if dur <= 0:
        raise RankError("Could not get the clip duration.")
    if dur <= seconds:
        return 0.0
    try:
        samples = _sample_loudness(src)
        if len(samples) < 3:
            raise ValueError("no loudness data")
        scores = _window_scores(samples, dur, seconds)
        if not scores:
            raise ValueError("no windows")
        best_t = max(scores, key=lambda s: s[1])[0]
        return _center_on_peak(samples, best_t, seconds, dur)
    except Exception:
        return random.uniform(0, dur - seconds)


def find_moment_windows(src, seconds, count):
    """Top-`count` engaging windows, non-overlapping.

    Greedy: loudest window first, then the next loudest that does not
    overlap an already picked one. Each window is peak-centered like
    find_moment_start. Returns [start_seconds, ...] (may be fewer than
    count if the clip is short).
    """
    dur = probe_duration(src)
    if dur <= 0:
        raise RankError("Could not get the clip duration.")
    if dur <= seconds:
        return [0.0]
    samples = _sample_loudness(src)
    if len(samples) < 3:
        # no audio info: spread evenly
        n = max(1, min(count, int(dur // seconds)))
        return [round(i * (dur - seconds) / max(n - 1, 1), 2)
                for i in range(n)]
    scores = sorted(_window_scores(samples, dur, seconds),
                    key=lambda s: s[1], reverse=True)
    picked = []  # [(grid_start, score)]
    for t, v in scores:
        if all(abs(t - p[0]) >= seconds * 0.9 for p in picked):
            picked.append((t, v))
            if len(picked) >= count:
                break
    # peak-center each, then drop any that now overlap (loudest wins)
    centered = [(_center_on_peak(samples, t, seconds, dur), v)
                for t, v in picked]
    centered.sort(key=lambda s: s[1], reverse=True)
    final = []
    for c, _v in centered:
        if all(abs(c - f) >= seconds * 0.9 for f in final):
            final.append(c)
    final.sort()
    return final


def cut_segment(src, out, seconds, overlay_png):
    """Cut a `seconds`-long 9:16 segment with the overlay baked in."""
    dur = probe_duration(src)
    loop_args = []
    start = 0.0
    if dur <= 0:
        raise RankError("Could not get the clip duration.")
    if dur < seconds:
        loops = math.ceil(seconds / dur)
        loop_args = ["-stream_loop", str(loops)]
    else:
        start = find_moment_start(src, seconds)
    vf = ("[0:v]scale=1080:1920:force_original_aspect_ratio=increase,"
          "crop=1080:1920,setsar=1,fps=30,format=yuv420p[bg];"
          "[bg][1:v]overlay=0:0:format=yuv420[v]")
    cmd = (["ffmpeg", "-y", "-v", "error"] + loop_args +
           ["-ss", f"{start:.2f}", "-t", str(seconds), "-i", src,
            "-i", overlay_png, "-filter_complex", vf,
            "-map", "[v]", "-map", "0:a?",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-c:a", "aac", "-b:a", "128k",
            "-movflags", "+faststart", "-shortest", out])
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(out):
        raise RankError(f"Could not cut the clip: {r.stderr[-300:]}")
    return out


def concat_segments(segs, out):
    lst = out + ".txt"
    with open(lst, "w", encoding="utf-8") as f:
        for s in segs:
            f.write(f"file '{s}'\n")
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0",
           "-i", lst, "-c", "copy", "-movflags", "+faststart", out]
    r = subprocess.run(cmd, capture_output=True, text=True)
    try:
        os.remove(lst)
    except OSError:
        pass
    if r.returncode != 0 or not os.path.exists(out):
        raise RankError("Could not merge the clips.")
    return out


def build_rank_video(sources, out_path, title_prefix="Ranking Best",
                     title_keyword="", n_clips=5, seconds_per_clip=4,
                     order="asc", progress_cb=None):
    """Assemble the final ranking video from downloaded clip files."""
    workdir = os.path.dirname(out_path)
    n_clips = max(2, min(8, int(n_clips or 5)))
    seconds_per_clip = max(2, min(8, int(seconds_per_clip or 4)))
    clips = (sources or [])[:n_clips]
    if len(clips) < 2:
        raise RankError("Needed at least 2 clips - please try again.")

    total = len(clips)
    segs = []
    for i, src in enumerate(clips):
        rank = (i + 1) if order == "asc" else (total - i)
        ov = os.path.join(workdir, f"rank_ov_{i}.png")
        make_overlay_png(rank, total, title_prefix, title_keyword, ov)
        seg = os.path.join(workdir, f"rank_seg_{i}.mp4")
        if progress_cb:
            progress_cb(f"Clip {i + 1}/{total} cut ho raha hai...")
        cut_segment(src, seg, seconds_per_clip, ov)
        segs.append(seg)

    if progress_cb:
        progress_cb("Clips merge ho rahe hain...")
    return concat_segments(segs, out_path)
