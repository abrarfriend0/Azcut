"""Pixabay stock photos/videos for Az Cut.

Free API key from https://pixabay.com/api/docs/ (sign up free, key shows
on the docs page after login).
Stdlib only — no new dependency, PyInstaller-safe.

Pexels paused new API key issuance (2026), so Pixabay is the working
key-based stock source for Rank Cut / Auto Doodle / Studio.
"""

import json
import os
import urllib.error
import urllib.parse
import urllib.request

API_BASE = "https://pixabay.com/api"
VIDEO_BASE = "https://pixabay.com/api/videos"
ALLOWED_HOSTS = ("cdn.pixabay.com", "pixabay.com")


class PixabayError(Exception):
    pass


def _get(api_key, base, params):
    if not api_key:
        raise PixabayError(
            "Please paste your Pixabay API key first. "
            "Free key: pixabay.com -> Join -> pixabay.com/api/docs.")
    params = dict(params or {})
    params["key"] = api_key
    params.setdefault("safesearch", "true")
    qs = urllib.parse.urlencode(params)
    req = urllib.request.Request(
        f"{base}/?{qs}", headers={"User-Agent": "AzCut"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code in (400, 401, 403):
            raise PixabayError(
                "Pixabay rejected the API key — check the key "
                "(pixabay.com/api/docs).")
        if e.code == 429:
            raise PixabayError(
                "Pixabay rate limit hit — wait a minute and retry.")
        raise PixabayError(f"Pixabay API error ({e.code}).")
    except PixabayError:
        raise
    except Exception as e:  # noqa: BLE001
        raise PixabayError(f"Could not reach Pixabay: {e}")


def _best_video_url(videos):
    """Pick medium (720p) video file, else large, else small, else tiny."""
    for q in ("medium", "large", "small", "tiny"):
        v = (videos or {}).get(q)
        if v and v.get("url"):
            return v["url"]
    return None


def search_videos(api_key, query, per_page=12):
    """Search Pixabay videos. Returns {"items": [...]}.

    Item: {"url", "preview", "duration", "views"}.
    """
    data = _get(api_key, VIDEO_BASE,
                {"q": query, "per_page": max(3, min(50, per_page))})
    items = []
    for h in data.get("hits") or []:
        url = _best_video_url(h.get("videos"))
        if not url:
            continue
        items.append({
            "url": url,
            "preview": h.get("previewURL") or h.get("userImageURL") or "",
            "duration": h.get("duration") or 0,
            "views": h.get("views") or 0,
        })
    return {"items": items}


def search_photos(api_key, query, per_page=12):
    """Search Pixabay photos. Returns {"items": [...]}.

    Item: {"url", "preview"}.
    """
    data = _get(api_key, API_BASE,
                {"q": query, "image_type": "photo",
                 "per_page": max(3, min(50, per_page))})
    items = []
    for h in data.get("hits") or []:
        url = h.get("largeImageURL") or h.get("webformatURL")
        if not url:
            continue
        items.append({
            "url": url,
            "preview": h.get("previewURL") or h.get("webformatURL") or "",
        })
    return {"items": items}


def search(api_key, query, kind="photo", page=1, per_page=12):
    """Unified search matching pexels.search() shape (for Studio panel)."""
    if kind == "video":
        return search_videos(api_key, query, per_page=per_page)
    return search_photos(api_key, query, per_page=per_page)


def download(url, out_path):
    """Download a Pixabay file (host allowlist enforced)."""
    host = urllib.parse.urlparse(url).hostname or ""
    if not any(host == h or host.endswith("." + h) for h in ALLOWED_HOSTS):
        raise PixabayError(f"Blocked host: {host}")
    req = urllib.request.Request(url, headers={"User-Agent": "AzCut"})
    try:
        with urllib.request.urlopen(req, timeout=120) as r, \
                open(out_path, "wb") as f:
            while True:
                chunk = r.read(256 * 1024)
                if not chunk:
                    break
                f.write(chunk)
    except PixabayError:
        raise
    except Exception as e:  # noqa: BLE001
        raise PixabayError(f"Download failed: {e}")
    if not os.path.exists(out_path) or os.path.getsize(out_path) == 0:
        raise PixabayError("Downloaded file is empty.")
    return out_path
