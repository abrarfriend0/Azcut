"""NarrAsync core: narration transcription + script-cued timeline assembly."""

PIPELINE_VERSION = "2.20"

import os
import re
import shutil
import subprocess

import numpy as np

MODEL_NAME = os.environ.get("NARRASYNC_MODEL", "base")

TRANSCRIBE_MODELS = {
    "tiny": "Fast (tiny)",
    "base": "Balanced (base)",
    "small": "Accurate (small)",
}

_models = {}


def get_model(name=None):
    name = name or MODEL_NAME
    # name can be a model id ('tiny'/'base'/'small') or a local folder path
    # (the frozen installer bundles the model and points NARRASYNC_MODEL at it)
    if name not in TRANSCRIBE_MODELS and not os.path.isdir(name):
        name = "base"
    if name not in _models:
        from faster_whisper import WhisperModel
        _models[name] = WhisperModel(name, device="cpu", compute_type="int8")
    return _models[name]


def decode_audio(path):
    """Decode any audio file to mono 16kHz float32 PCM via ffmpeg."""
    raw = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", path,
         "-ac", "1", "-ar", "16000", "-f", "f32le", "-"],
        capture_output=True, check=True,
    ).stdout
    return np.frombuffer(raw, dtype=np.float32)


def audio_duration(path):
    """Duration in seconds via ffmpeg decode (no ffprobe needed)."""
    return len(decode_audio(path)) / 16000


def transcribe_groq(path, api_key, model="whisper-large-v3-turbo"):
    """v2.20: Groq cloud transcription — ~3 sec, word timestamps.

    Returns same format as transcribe(). Raises CueError on failure.
    """
    import urllib.request
    import json as _json

    # audio ko mp3 mein convert (Groq 25MB limit)
    audio = decode_audio(path)  # noqa: F841 (ensures ffmpeg available)
    tmp = path + ".groq.mp3"
    r = subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-i", path, "-ac", "1", "-ar", "16000",
         "-b:a", "64k", tmp],
        capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(tmp):
        raise CueError("Audio convert nahi ho saka (Groq).")
    try:
        if os.path.getsize(tmp) > 24 * 1024 * 1024:
            raise CueError(
                "Audio 25MB se bara hai — Groq free limit. Chhota clip use karo.")

        boundary = "----AzCutGroqBoundary"
        with open(tmp, "rb") as f:
            audio_data = f.read()

        parts = []
        parts.append(f"--{boundary}\r\n".encode())
        parts.append(b'Content-Disposition: form-data; name="model"\r\n\r\n')
        parts.append(f"{model}\r\n".encode())
        parts.append(f"--{boundary}\r\n".encode())
        parts.append(
            b'Content-Disposition: form-data; name="response_format"\r\n\r\n')
        parts.append(b"verbose_json\r\n")
        parts.append(f"--{boundary}\r\n".encode())
        parts.append(
            b'Content-Disposition: form-data; '
            b'name="timestamp_granularities[]"\r\n\r\n')
        parts.append(b"word\r\n")
        parts.append(f"--{boundary}\r\n".encode())
        parts.append(
            b'Content-Disposition: form-data; name="file"; '
            b'filename="audio.mp3"\r\n'
            b"Content-Type: audio/mpeg\r\n\r\n")
        parts.append(audio_data)
        parts.append(f"\r\n--{boundary}--\r\n".encode())
        body = b"".join(parts)

        req = urllib.request.Request(
            "https://api.groq.com/openai/v1/audio/transcriptions",
            data=body,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": f"multipart/form-data; boundary={boundary}",
                # v2.20: Cloudflare block se bachne ke liye browser headers
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0.0.0 Safari/537.36"),
                "Accept": "application/json",
                "Origin": "https://azcut.app",
            })
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = _json.loads(resp.read().decode("utf-8"))

        words = []
        for w in data.get("words", []):
            words.append({
                "word": (" " + w.get("word", "")).rstrip(),
                "start": float(w.get("start", 0)),
                "end": float(w.get("end", 0)),
            })
        # fallback: agar word timestamps na hon to segments se
        if not words:
            for seg in data.get("segments", []):
                txt = seg.get("text", "").strip()
                if txt:
                    words.append({
                        "word": " " + txt,
                        "start": float(seg.get("start", 0)),
                        "end": float(seg.get("end", 0)),
                    })
        dur = float(data.get("duration", 0)) or audio_duration(path)
        return {
            "words": words,
            "duration": dur,
            "text": data.get("text", "").strip(),
            "language": data.get("language", ""),
        }
    except urllib.error.HTTPError as e:
        try:
            err = e.read().decode("utf-8")[:300]
        except Exception:  # noqa: BLE001
            err = str(e)
        raise CueError(f"Groq error: {err}")
    finally:
        try:
            os.remove(tmp)
        except OSError:  # noqa: BLE001
            pass


def transcribe(path, model=None, groq_key=None):
    """Return {'words': [{word, start, end}], 'duration': seconds, 'text': str}.

    model: 'tiny' (fast), 'base' (balanced), 'small' (accurate).
    groq_key: if given, use Groq cloud (~3 sec) instead of local.
    """
    # v2.20: Groq fast mode
    if groq_key:
        return transcribe_groq(path, groq_key)
    audio = decode_audio(path)
    m = get_model(model)
    segments, _info = m.transcribe(audio, word_timestamps=True)
    # NOTE: keep full float precision here (no rounding) so adjacent cues
    # never collapse to the same timestamp; rounding is for display only.
    words = [
        {"word": w.word, "start": w.start, "end": w.end}
        for seg in segments for w in (seg.words or [])
    ]
    return {
        "words": words,
        # full precision: cue math needs exact values; rounding is for display only
        "duration": len(audio) / 16000,
        "text": "".join(w["word"] for w in words).strip(),
        # auto-detected language code, e.g. 'ur', 'en', 'hi' (may be '')
        "language": getattr(_info, "language", "") or "",
    }


def norm(w):
    return re.sub(r"[^a-z0-9]", "", w.lower())


class CueError(Exception):
    pass


def parse_cues(text):
    """Parse '[imgN] sentence...' lines; require consecutive numbering from 1."""
    cues = []
    for lineno, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        m = re.match(r"\[img(\d+)\]\s*(.*\S)", line)
        if not m:
            raise CueError(f"Line {lineno}: must be in '[imgN] sentence...' format.")
        cues.append((int(m.group(1)), m.group(2)))
    if not cues:
        raise CueError("No cues found. Write your script in '[img1] ...' format.")
    cues.sort(key=lambda c: c[0])
    if [n for n, _ in cues] != list(range(1, len(cues) + 1)):
        raise CueError("Cues must be numbered [img1], [img2], ... in order (no missing numbers).")
    return cues


def _word_edit(a, b):
    """Levenshtein distance between two word lists."""
    prev = list(range(len(b) + 1))
    for x in a:
        cur = [prev[0] + 1]
        for j, y in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (x != y)))
        prev = cur
    return prev[-1]


def _find_anchor(toks, anchor, prev_pos):
    """Find the anchor phrase in the transcript after prev_pos.

    Uses word-level edit distance over tight windows so the match must be
    (near-)contiguous: scattered words across the transcript don't count.
    Tolerates small transcription differences ('reports' vs 'report').
    """
    max_dist = 0 if len(anchor) <= 3 else (1 if len(anchor) <= 4 else 2)
    best, best_i = None, None
    for i in range(prev_pos + 1, len(toks)):
        for L in range(len(anchor), len(anchor) + 3):
            window = toks[i:i + L]
            if len(window) < len(anchor):
                continue
            d = _word_edit(anchor, window)
            if best is None or d < best:
                best, best_i = d, i
                if d == 0:
                    break
        if best == 0:
            break
    if best is not None and best <= max_dist:
        return best_i
    return None


def locate_cues(words, cues):
    """Map each cue to a start time via fuzzy anchor matching.

    The anchor (first ~6 words after the marker) is located in the
    transcript with LCS scoring, so small transcription differences
    (e.g. 'reports' heard as 'report') still match.
    """
    flat = [(i, norm(w["word"])) for i, w in enumerate(words)]
    flat = [(i, t) for i, t in flat if t]
    idx_of = [i for i, _ in flat]
    toks = [t for _, t in flat]
    starts = []
    prev_pos = -1  # each cue must be found AFTER the previous one
    for n, text in cues:
        anchor = [t for t in (norm(w) for w in text.split()) if t][:6]
        if not anchor:
            raise CueError(f"[img{n}] has no words after it.")
        pos = _find_anchor(toks, anchor, prev_pos)
        if pos is None:
            raise CueError(
                f"[img{n}] was not found in the transcript after the previous cue. "
                f"Make the cue words clearer: '{' '.join(anchor[:5])}...'")
        prev_pos = pos
        starts.append(words[idx_of[pos]]["start"])
    return starts


def parse_cue_times(text):
    """Parse '[imgN] mm:ss[.s] ...' lines for timestamp sync mode.

    Returns [(img_number, seconds)]. Numbers must be 1..N consecutive and
    times strictly increasing.
    """
    cues = []
    for lineno, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        m = re.match(r"\[img(\d+)\]\s*(\d+):(\d+(?:\.\d+)?)\b", line)
        if not m:
            raise CueError(
                f"Line {lineno}: must be in '[imgN] m:ss ...' format. "
                f"Example: [img1] 0:05 intro")
        secs = int(m.group(2)) * 60 + float(m.group(3))
        cues.append((int(m.group(1)), secs))
    if not cues:
        raise CueError("No cues found. Write in '[img1] 0:05 ...' format.")
    cues.sort(key=lambda c: c[0])
    if [n for n, _ in cues] != list(range(1, len(cues) + 1)):
        raise CueError("Cues must be numbered [img1], [img2], ... in order.")
    times = [t for _, t in cues]
    if any(b - a <= 0 for a, b in zip(times, times[1:])):
        raise CueError("Timestamps must keep increasing (each one later than the previous).")
    return cues


def parse_script_times(text):
    """Parse 'm:ss script...' lines for script-with-timestamps sync mode.

    Each line starts with a timestamp; images are arranged in order onto
    these times (first image at first time, etc.). No [imgN] markers.
    Returns [(seconds, text)]. Times must be strictly increasing.

    Example:
        0:00 Hello dosto, welcome to my channel
        0:30 Aaj hum baat karenge...
    """
    cues = []
    for lineno, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        m = re.match(r"(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)\s+(.*\S)", line)
        if not m:
            raise CueError(
                f"Line {lineno}: must start with a timestamp like '0:05'. "
                f"Example: 0:05 Hello dosto...")
        h, mm, ss = m.group(1), m.group(2), m.group(3)
        secs = (int(h) * 3600 if h else 0) + int(mm) * 60 + float(ss)
        cues.append((secs, m.group(4)))
    if not cues:
        raise CueError(
            "No timestamped lines found. Write like '0:05 Hello dosto...'")
    times = [t for t, _ in cues]
    if any(b - a <= 0 for a, b in zip(times, times[1:])):
        raise CueError(
            "Timestamps must keep increasing "
            "(each one later than the previous).")
    return cues


def draft_cues(words, count):
    """Split the transcript into `count` parts and draft '[imgN] ...' cues."""
    sents, cur = [], []
    for w in words:
        cur.append(w)
        if re.search(r"[.!?\u2026:;]$", w["word"].strip()):
            sents.append(cur)
            cur = []
    if cur:
        sents.append(cur)
    if not sents:
        sents = [words]
    total = sum(len(s) for s in sents)
    target = total / max(count, 1)
    groups, g = [], []
    for s in sents:
        g.append(s)
        acc = sum(len(x) for x in g)
        if len(groups) < count - 1 and acc >= target * (len(groups) + 1):
            groups.append(g)
            g = []
    if g:
        groups.append(g)
    while len(groups) < count:
        i = max(range(len(groups)), key=lambda k: sum(len(s) for s in groups[k]))
        flat_g = [w for s in groups[i] for w in s]
        half = len(flat_g) // 2
        if half == 0:
            break
        groups[i:i + 1] = [[flat_g[:half]], [flat_g[half:]]]
    lines = []
    for i, grp in enumerate(groups[:count], 1):
        head = "".join(w["word"] for s in grp for w in s)[:90].strip()
        lines.append(f"[img{i}] {head} ...")
    return "\n".join(lines)


VIDEO_EXTS = {".mp4", ".mov", ".m4v", ".webm", ".mkv", ".avi"}


# ----------------------------------------------------------------------------
# Style engine: transitions, keyframe motions, effects, captions
# ----------------------------------------------------------------------------

TRANSITIONS = {
    # v2.17: all 57 ffmpeg xfade transitions, CapCut-style names
    "fade": "Fade", "fadefast": "Flash Cut", "fadeslow": "Soft Mix",
    "fadeblack": "Dip to Black", "fadewhite": "Dip to White",
    "fadegrays": "Fade Grays", "dissolve": "Dissolve",
    "wipeleft": "Wipe Left", "wiperight": "Wipe Right",
    "wipeup": "Wipe Up", "wipedown": "Wipe Down",
    "wipetl": "Wipe ↖", "wipetr": "Wipe ↗",
    "wipebl": "Wipe ↙", "wipebr": "Wipe ↘",
    "slideleft": "Slide Left", "slideright": "Slide Right",
    "slideup": "Slide Up", "slidedown": "Slide Down",
    "smoothleft": "Push Left", "smoothright": "Push Right",
    "smoothup": "Push Up", "smoothdown": "Push Down",
    "coverleft": "Cover Left", "coverright": "Cover Right",
    "coverup": "Cover Up", "coverdown": "Cover Down",
    "revealleft": "Reveal Left", "revealright": "Reveal Right",
    "revealup": "Reveal Up", "revealdown": "Reveal Down",
    "circleopen": "Circle Open (Iris)", "circleclose": "Circle Close",
    "circlecrop": "Iris Crop", "rectcrop": "Rect Crop",
    "radial": "Radial Wipe",
    "vertopen": "Vertical Open", "vertclose": "Vertical Close",
    "horzopen": "Horizontal Open", "horzclose": "Horizontal Close",
    "diagtl": "Diagonal ↖", "diagtr": "Diagonal ↗",
    "diagbl": "Diagonal ↙", "diagbr": "Diagonal ↘",
    "hlslice": "Slice ←", "hrslice": "Slice →",
    "vuslice": "Slice ↑", "vdslice": "Slice ↓",
    "distance": "Zoom (Distance)", "zoomin": "Camera In",
    "hblur": "Blur Fade", "pixelize": "Pixelate (Glitch)",
    "squeezeh": "Squeeze Wide", "squeezev": "Squeeze Tall",
    "hlwind": "Wind ←", "hrwind": "Wind →",
    "vuwind": "Wind ↑", "vdwind": "Wind ↓",
}

MOTIONS = {
    "zoomin": "Zoom In",
    "zoomout": "Zoom Out",
    "panleft": "Pan Left",
    "panright": "Pan Right",
    "panup": "Pan Up",
    "pandown": "Pan Down",
    "pencildraw": "✏️ Pencil Draw",
    "smartmix": "🎨 Smart Mix",
    "explainer": "🎬 Explainer",
}

EFFECTS = {
    "grain": "Film Grain", "vhs": "VHS Retro", "rgbsplit": "RGB Split",
    "shake": "Camera Shake", "blurfocus": "Blur Focus-in",
    # v2.17: CapCut-style effects (all render in ffmpeg)
    "fisheye": "Fisheye", "vignette": "Vignette", "dream": "Dream Glow",
    "sharpen": "Sharpen", "softblur": "Soft Blur", "edgedetect": "Edge Art",
    "negate": "Invert", "sepia": "Sepia", "grayscale": "B&W Film",
    "pixelate": "Pixelate", "warm": "Warm Sunset", "cold": "Cold Blue",
    "fadefilm": "Faded Film", "clarity": "Clarity+",
}

CAPTION_STYLES = {
    "karaoke": "Karaoke (word highlight)",
    "standard": "Standard",
    "pop": "Pop (word by word)",
}

# ----------------------------------------------------------------------------
# Caption preset engine (v1.0): 30 ready templates, CapCut-style.
# Each preset overrides _CAP_DEFAULTS. resolve_caption_opts() merges a preset
# with the user's own tweaks into the final dict build_ass_file() renders.
# ----------------------------------------------------------------------------

CAPTION_FONTS = [
    "Arial", "Arial Black", "Montserrat", "Poppins", "Inter", "Oswald",
    "Bebas Neue", "Anton", "Roboto", "Impact", "Verdana", "Tahoma",
    "Trebuchet MS", "Consolas", "Merriweather",
    # Montra — viral bold caption font (Surplus Type Co, free for personal
    # use, NOT redistributable): install on Windows, then select it here.
    "Montra",
    # Urdu / Arabic script fonts (used if installed; falls back to Arial)
    "Noto Nastaliq Urdu", "Noto Naskh Arabic", "Noto Sans Arabic", "Amiri",
    "Aref Ruqaa", "Gulzar", "Jameel Noori Nastaleeq", "Scheherazade New",
    # v2.17: CapCut specimen fonts (DEMO versions — install on Windows to use,
    # like Montra; not bundled for licensing reasons)
    "Megazine Poster", "Melloida", "Rotifera", "Reflow Sans", "Naru Sans",
    "Lugio Sans", "Vynce Sans", "Travel Growth Sans", "Lenia Sans",
    "Somerun", "Lenia Mono", "Sketsa Handdrawn", "Davigo", "TBJ Milky",
]

CAPTION_GRIDS = {
    "top-left": "Top Left", "top-center": "Top Center", "top-right": "Top Right",
    "middle-left": "Middle Left", "middle-center": "Middle Center",
    "middle-right": "Middle Right",
    "bottom-left": "Bottom Left", "bottom-center": "Bottom Center",
    "bottom-right": "Bottom Right",
}

CAPTION_ANIMS = {
    "none": "Instant Cut",
    "fade": "Smooth Fade (In & Out)",
    "pop": "Pop Zoom (Punch In)",
    "slide_up": "Slide Up & Rise",
    "slide_down": "Slide Down",
}

_CAP_DEFAULTS = dict(
    font="Montserrat", bold=True, size=64,
    color="#FFFFFF", hl="#FFE600",
    outline=2, outline_color="#000000", shadow=1, glow=None,
    grid="bottom-center", dx=0, dy=0,
    wpl=4, lines=1, karaoke="word", anim="pop", uppercase=False, box=False,
    box_alpha=0,  # 0=solid black bar, 255=fully transparent bar
    wordbox=False,  # explainer: yellow/red boxes on important/danger words
    hl2="#FF3B30",  # danger-word box color (red)
)

# Words that get a RED box in explainer kinetic captions
DANGER_WORDS = {
    "danger", "dangerous", "warning", "warn", "stop", "never", "risk", "risky",
    "threat", "die", "death", "dead", "kill", "killed", "crisis", "fail",
    "failed", "failure", "wrong", "bad", "hate", "fear", "afraid", "attack",
    "destroy", "destroyed", "lose", "lost", "problem", "mistake", "error",
    "catastrophe", "disaster", "toxic", "poison", "virus", "war",
}

# Explainer section background colors: white, black, red, blue, yellow
EXPLAINER_BGS = ["#FFFFFF", "#14161A", "#E53935", "#1E88E5", "#FFD600"]


def _P(**kw):
    d = dict(_CAP_DEFAULTS)
    d.update(kw)
    return d


CAPTION_PRESETS = {
    # ---- Top 10 viral templates ----
    "hormozi": _P(label="Hormozi Pop",
                  font="Montserrat", size=68, color="#FFFFFF", hl="#FFE600",
                  outline=2, wpl=3, anim="pop", grid="bottom-center"),
    "mrbeast": _P(label="Beast Bold",
                  font="Arial Black", size=72, color="#FFFFFF", hl="#FF3B30",
                  outline=3, wpl=4, anim="pop"),
    "karaoke_pop": _P(label="Moving Karaoke Pop",
                      font="Poppins", size=64, color="#FFFFFF", hl="#00E676",
                      outline=2, wpl=3, anim="pop", karaoke="word"),
    "minimal": _P(label="Minimal Clean",
                  font="Inter", bold=False, size=54, color="#FFFFFF", hl="#FFFFFF",
                  outline=0, shadow=1, wpl=6, anim="fade", karaoke="none"),
    "neon": _P(label="Neon Glow",
               font="Montserrat", size=64, color="#00F0FF", hl="#FFFFFF",
               outline=0, glow="#00F0FF", shadow=0, wpl=4, anim="fade"),
    "outline_punch": _P(label="Outline Punch",
                        font="Oswald", size=76, color="#FFFFFF", hl="#FFFFFF",
                        outline=4, outline_color="#111111", wpl=3, anim="pop"),
    "typewriter": _P(label="Typewriter",
                     font="Consolas", size=56, color="#E8E8E8", hl="#E8E8E8",
                     outline=1, wpl=8, anim="fade", karaoke="reveal"),
    "ticker": _P(label="News Ticker",
                 font="Arial", size=52, color="#FFFFFF", hl="#FFD60A", box=True,
                 outline=0, shadow=0, wpl=8, anim="none", karaoke="none"),
    "cinema": _P(label="Cinematic",
                 font="Oswald", size=58, color="#FFF8E7", hl="#FFC93C",
                 outline=1, shadow=2, wpl=5, anim="fade", dy=-30),
    "glitch": _P(label="Glitch Pop",
                 font="Arial Black", size=66, color="#FFFFFF", hl="#FF2FB3",
                 outline=2, outline_color="#00E5FF", wpl=3, anim="pop"),
    # ---- More styles ----
    "luxury": _P(label="Luxury Gold",
                 font="Merriweather", size=60, color="#F5E6C8", hl="#D4AF37",
                 outline=1, shadow=2, wpl=5, anim="fade"),
    "sport": _P(label="Sport Energy",
                font="Oswald", size=70, color="#FFFFFF", hl="#FF6B00",
                outline=3, wpl=3, anim="slide_up"),
    "comic": _P(label="Comic Punch",
                font="Arial Black", size=66, color="#FFE93C", hl="#FFFFFF",
                outline=3, outline_color="#D32F2F", wpl=3, anim="pop"),
    "retro": _P(label="Retro Wave",
                font="Impact", size=68, color="#FF9E00", hl="#00E5FF",
                outline=2, wpl=4, anim="fade"),
    "fire": _P(label="Fire Words",
               font="Montserrat", size=68, color="#FFFFFF", hl="#FF5722",
               outline=2, glow="#FF5722", wpl=3, anim="pop"),
    "ocean": _P(label="Ocean Calm",
                font="Poppins", bold=False, size=58, color="#E0F7FA", hl="#4DD0E1",
                outline=1, wpl=6, anim="fade"),
    "mono": _P(label="Mono Code",
               font="Consolas", size=54, color="#C8FFC8", hl="#FFFF00",
               outline=0, shadow=0, wpl=8, anim="none", karaoke="word"),
    "soft_shadow": _P(label="Soft Shadow",
                      font="Inter", size=60, color="#FFFFFF", hl="#FFFFFF",
                      outline=0, shadow=4, wpl=5, anim="fade", karaoke="none"),
    "upper_punch": _P(label="Uppercase Punch",
                      font="Oswald", size=64, color="#FFFFFF", hl="#FFE600",
                      outline=2, wpl=4, anim="pop", uppercase=True),
    "gentle": _P(label="Gentle Fade",
                 font="Poppins", bold=False, size=56, color="#FFFFFF", hl="#FFE0B2",
                 outline=1, wpl=7, anim="fade", karaoke="none"),
    # ---- Urdu / Arabic ----
    "urdu_nastaliq": _P(label="Urdu Nastaliq",
                        font="Noto Nastaliq Urdu", size=60, color="#FFFFFF", hl="#FFE600",
                        outline=2, wpl=5, anim="fade"),
    "urdu_naskh": _P(label="Urdu Naskh",
                     font="Noto Naskh Arabic", size=62, color="#FFFFFF", hl="#7CFC00",
                     outline=2, wpl=5, anim="fade"),
    "urdu_modern": _P(label="Urdu Modern",
                      font="Noto Sans Arabic", size=60, color="#FFFFFF", hl="#00E5FF",
                      outline=2, wpl=5, anim="pop"),
    "urdu_ruqaa": _P(label="Ruqaa Style",
                     font="Aref Ruqaa", size=64, color="#FFF3D6", hl="#FFB300",
                     outline=1, shadow=2, wpl=5, anim="fade"),
    "urdu_gulzar": _P(label="Gulzar Display",
                      font="Gulzar", size=66, color="#FFFFFF", hl="#FF4081",
                      outline=2, wpl=4, anim="pop"),
    # ---- Fun & utility ----
    "bubble": _P(label="Bubble Box",
                 font="Poppins", size=58, color="#1A1A2E", hl="#1A1A2E", box=True,
                 outline=0, shadow=0, wpl=5, anim="pop", karaoke="none"),
    "karaoke_classic": _P(label="Classic Karaoke",
                          font="Arial", size=60, color="#FFFFFF", hl="#0000FF",
                          outline=2, wpl=6, anim="none", karaoke="word"),
    "marker": _P(label="Marker Highlight",
                 font="Montserrat", size=62, color="#111111", hl="#111111",
                 outline=0, shadow=0, box=True, wpl=4, anim="pop", karaoke="none"),
    "tiny_top": _P(label="Tiny Top",
                   font="Inter", size=40, color="#FFFFFF", hl="#FFFFFF",
                   outline=1, wpl=8, anim="fade", karaoke="none", grid="top-center"),
    "big_center": _P(label="Big Center",
                     font="Montserrat", size=84, color="#FFFFFF", hl="#FFE600",
                     outline=3, wpl=3, anim="pop", grid="middle-center"),
    # ---- Professional guide presets (v1.1) ----
    "cine_pro": _P(label="Cinematic Pro",
                   font="Montserrat", size=62, color="#FFFFFF", hl="#FFE600",
                   outline=2, shadow=2, wpl=6, lines=2, anim="fade",
                   grid="bottom-center", dy=-40, karaoke="word"),
    # ---- Doodle video captions: motion + text bar + stroke ----
    "doodle_pop": _P(label="Doodle Pop",
                   font="Montserrat", size=64, color="#FFFFFF", hl="#FFE600",
                   outline=3, outline_color="#000000", shadow=1,
                   box=True, box_alpha=128,
                   wpl=4, lines=2, anim="pop", karaoke="word",
                   grid="bottom-center", dy=-40),
    # ---- Explainer kinetic typography: yellow/red word boxes ----
    "explainer": _P(label="Explainer",
                   font="Montserrat", size=68, color="#FFFFFF", hl="#FFE600",
                   hl2="#FF3B30",
                   outline=2, outline_color="#000000", shadow=1,
                   box=True, box_alpha=140, wordbox=True,
                   wpl=3, lines=1, anim="pop", karaoke="word",
                   grid="middle-center"),
    "action_impact": _P(label="Action Impact",
                        font="Anton", size=78, color="#FFFFFF", hl="#FF3B30",
                        outline=3, wpl=3, anim="pop", uppercase=True,
                        grid="middle-center"),
    "story_fade": _P(label="Story Fade",
                     font="Poppins", bold=False, size=58, color="#FFFFFF", hl="#FFE0B2",
                     outline=1, shadow=1, wpl=7, lines=2, anim="fade",
                     karaoke="none", dy=-40),
    "danger_red": _P(label="Danger Red",
                     font="Montserrat", size=68, color="#FFFFFF", hl="#FF3B30",
                     outline=2, wpl=3, anim="pop", uppercase=True),
    "center_moment": _P(label="Center Moment",
                        font="Montserrat", size=76, color="#FFFFFF", hl="#FFE600",
                        outline=3, wpl=4, anim="fade", grid="middle-center"),
    "lower_third": _P(label="Lower Third Safe",
                      font="Inter", size=56, color="#FFFFFF", hl="#FFE600",
                      outline=2, shadow=2, wpl=6, lines=2, anim="fade",
                      grid="bottom-center", dy=-90,
                      karaoke="word"),
    "docu": _P(label="Documentary",
               font="Inter", bold=False, size=56, color="#F5F5F5", hl="#FFFFFF",
               outline=1, shadow=2, wpl=8, lines=2, anim="fade",
               karaoke="none", dy=-40),
    "gold_title": _P(label="Gold Title",
                     font="Merriweather", size=72, color="#FFFFFF", hl="#D4AF37",
                     outline=2, shadow=3, wpl=4, anim="fade",
                     grid="middle-center", uppercase=True),
    # ---- v2.17: CapCut-style templates (50 total) ----
    "gold_luxe": _P(label="Gold Luxe",
                    font="Merriweather", size=64, color="#FFD700", hl="#FFF8DC",
                    outline=1, outline_color="#3a2a00", shadow=2, glow="#FFD700",
                    wpl=3, anim="fade", uppercase=True, grid="middle-center"),
    "viral_duo": _P(label="Viral Duo (Podcast)",
                    font="Montserrat", size=72, color="#00E676", hl="#FFFFFF",
                    outline=2, shadow=2, glow="#00E676", wpl=6, anim="pop",
                    uppercase=True, grid="middle-center", duo=True,
                    duo_colors=["#00E676", "#40C4FF", "#FFD740"]),
    "tiktok_native": _P(label="TikTok Native",
                        font="Montserrat", size=56, color="#FFFFFF", hl="#FE2C55",
                        outline=2, wpl=4, lines=2, anim="pop", dy=-40,
                        hl2="#25F4EE", grid="bottom-center"),
    "pill_words": _P(label="Pill Words",
                     font="Montserrat", size=52, color="#FFFFFF", hl="#FFE600",
                     outline=0, wpl=3, anim="pop", box=True, box_alpha=180,
                     wordbox=True),
    "dark_card": _P(label="Dark Card",
                    font="Montserrat", bold=False, size=48, color="#FFFFFF",
                    hl="#FFB300", outline=0, wpl=5, lines=2, anim="fade",
                    karaoke="line", box=True, box_alpha=200),
    "fire_words": _P(label="Fire Words",
                     font="Anton", size=76, color="#FF6B00", hl="#FFE600",
                     outline=2, outline_color="#7a1e00", shadow=2, glow="#FF3B00",
                     wpl=3, anim="pop", uppercase=True, grid="middle-center"),
    "frost_bite": _P(label="Frost Bite",
                     font="Montserrat", size=60, color="#E0F7FF", hl="#00E5FF",
                     outline=1, outline_color="#003a4a", shadow=1, glow="#00E5FF",
                     wpl=3, anim="fade", uppercase=True, grid="middle-center"),
    "sticker_pop": _P(label="Sticker Pop",
                      font="Montserrat", size=64, color="#FFFFFF", hl="#FFE600",
                      outline=3, outline_color="#FFFFFF", shadow=2,
                      wpl=3, anim="pop", grid="middle-center"),
    "pastel_dream": _P(label="Pastel Dream",
                       font="Merriweather", bold=False, size=54, color="#FFF0F5",
                       hl="#FFB7D5", outline=1, outline_color="#8a4a6b",
                       shadow=1, wpl=4, lines=2, anim="fade", karaoke="line"),
    "caps_space": _P(label="Caps Space",
                     font="Montserrat", size=52, color="#FFFFFF", hl="#FFB300",
                     outline=2, wpl=3, anim="slide_up", uppercase=True),
    "zoom_punch": _P(label="Zoom Punch",
                     font="Anton", size=84, color="#FFFFFF", hl="#FFE600",
                     outline=3, wpl=2, anim="pop", uppercase=True,
                     grid="middle-center"),

}

TOP_PRESETS = ["hormozi", "mrbeast", "karaoke_pop", "minimal", "neon",
               "outline_punch", "typewriter", "ticker", "cinema", "glitch"]


def detect_script_font(text):
    """v2.20: auto-detect text script, return suitable font or None.
    Returns None if Latin (use user's selected font)."""
    if not text:
        return None
    # sample first 200 chars
    sample = text[:200]
    arabic = sum(1 for c in sample if "\u0600" <= c <= "\u06FF")
    devanagari = sum(1 for c in sample if "\u0900" <= c <= "\u097F")
    cjk = sum(1 for c in sample if "\u4e00" <= c <= "\u9fff")
    thai = sum(1 for c in sample if "\u0e00" <= c <= "\u0e7f")
    total = len(sample)
    if arabic > total * 0.2:
        return "Noto Nastaliq Urdu"  # Urdu/Arabic/Persian
    if devanagari > total * 0.2:
        return "Noto Sans Devanagari"  # Hindi/Marathi
    if cjk > total * 0.2:
        return "Noto Sans CJK SC"  # Chinese
    if thai > total * 0.2:
        return "Noto Sans Thai"
    return None


def resolve_caption_opts(opts):
    """Merge a preset id + user tweaks into the final caption dict."""
    opts = dict(opts or {})
    preset_id = opts.pop("preset", "hormozi")
    base = dict(_CAP_DEFAULTS)
    if preset_id in CAPTION_PRESETS:
        p = CAPTION_PRESETS[preset_id]
        base.update({k: v for k, v in p.items() if k != "label"})
    # legacy keys from older UI versions
    if "font_size" in opts:
        opts["size"] = opts.pop("font_size")
    if "hl_color" in opts:
        opts["hl"] = opts.pop("hl_color")
    if "style" in opts and "karaoke" not in opts:
        opts["karaoke"] = {"karaoke": "word", "pop": "reveal"}.get(opts.pop("style"), "none")
    if "layout" in opts:
        lay = opts.pop("layout")
        if lay == "two" and "lines" not in opts:
            opts["lines"] = 2
        if "wpl" not in opts:
            opts["wpl"] = 4
    if "position" in opts and "grid" not in opts:
        pos = opts.pop("position")
        opts["grid"] = {"top": "top-center", "middle": "middle-center"}.get(pos, "bottom-center")
    # v2.20: X%/Y% sliders — convert to grid + pixel offsets
    if "pos_x" in opts or "pos_y" in opts:
        px = float(opts.pop("pos_x", 50))
        py = float(opts.pop("pos_y", 84))
        # nearest grid anchor
        col = "left" if px < 34 else ("right" if px > 66 else "center")
        row = "top" if py < 34 else ("bottom" if py > 66 else "middle")
        opts["grid"] = f"{row}-{col}"
        # dx/dy: offset from anchor in pixels (computed at render time via W/H)
        # store percentages; _caption_xy will apply them
        opts["_pos_x_pct"] = px
        opts["_pos_y_pct"] = py
        opts["dx"] = 0
        opts["dy"] = 0
    base.update(opts)
    # sanitize
    base["size"] = max(20, min(160, int(base.get("size", 64))))
    base["wpl"] = max(1, min(20, int(base.get("wpl", 4))))
    base["outline"] = max(0, min(8, int(base.get("outline", 2))))
    base["shadow"] = max(0, min(8, int(base.get("shadow", 1))))
    base["dx"] = max(-600, min(600, int(base.get("dx", 0))))
    base["dy"] = max(-400, min(400, int(base.get("dy", 0))))
    base["lines"] = 2 if int(base.get("lines", 1)) >= 2 else 1
    if base.get("grid") not in CAPTION_GRIDS:
        base["grid"] = "bottom-center"
    if base.get("anim") not in CAPTION_ANIMS:
        base["anim"] = "pop"
    if base.get("karaoke") not in ("word", "reveal", "none"):
        base["karaoke"] = "word"
    return base

# ----------------------------------------------------------------------------
# Procedural sound effects (synthesized with numpy, no audio files needed).
# Each transition type gets a matching SFX, auto-placed at cut points.
# ----------------------------------------------------------------------------
SFX_SR = 44100

TRANSITION_SFX = {
    "dissolve": "soft_whoosh",    # gentle airy sweep
    "fadeblack": "drop",          # deep falling sweep
    "wipeleft": "whoosh",         # classic whoosh
    "slideleft": "whoosh",
    "distance": "riser",          # rising sweep for zoom
    "circleopen": "pop",          # iris pop
    "hblur": "soft_whoosh",
    "pixelize": "glitch",         # digital glitch blips
    "fadewhite": "flash",         # camera flash snap
}


def _sfx_env(n, attack=0.12):
    """Raised-cosine attack/decay envelope."""
    a = max(1, int(n * attack))
    env = np.empty(n, dtype=np.float32)
    env[:a] = 0.5 - 0.5 * np.cos(np.pi * np.arange(a) / a)
    tail = np.arange(n - a)
    env[a:] = 0.5 + 0.5 * np.cos(np.pi * tail / max(1, n - a))
    return env


def _sfx_chirp(dur, f0, f1, gain=0.6):
    """Sine sweep from f0 to f1 Hz."""
    n = int(dur * SFX_SR)
    t = np.arange(n) / SFX_SR
    f = f0 + (f1 - f0) * (t / dur)
    phase = 2 * np.pi * np.cumsum(f) / SFX_SR
    return (gain * np.sin(phase) * _sfx_env(n)).astype(np.float32)


def _sfx_noise(dur, seed=7, gain=0.5, attack=0.15):
    """Shaped white-noise burst (whoosh body)."""
    n = int(dur * SFX_SR)
    rng = np.random.default_rng(seed)
    x = rng.standard_normal(n).astype(np.float32)
    # swept one-pole lowpass -> rising brightness
    fc = np.linspace(500, 6000, n)
    a = 1 - np.exp(-2 * np.pi * fc / SFX_SR)
    y = np.empty(n, dtype=np.float32)
    acc = 0.0
    for i in range(n):
        acc += a[i] * (x[i] - acc)
        y[i] = acc
    y /= max(1e-6, np.max(np.abs(y)))
    return (gain * y * _sfx_env(n, attack)).astype(np.float32)


def _sfx_tone(dur, freq, decay, gain=0.6):
    """Decaying sine (pop / thump)."""
    n = int(dur * SFX_SR)
    t = np.arange(n) / SFX_SR
    return (gain * np.sin(2 * np.pi * freq * t) * np.exp(-t * decay)
            * _sfx_env(n, attack=0.02)).astype(np.float32)


def _sfx_glitch(dur=0.55, seed=21):
    """Random digital blips."""
    n = int(dur * SFX_SR)
    y = np.zeros(n, dtype=np.float32)
    rng = np.random.default_rng(seed)
    pos = 0
    while pos < n - 100:
        blen = int(rng.integers(int(0.02 * SFX_SR), int(0.07 * SFX_SR)))
        freq = float(rng.uniform(300, 3200))
        t = np.arange(blen) / SFX_SR
        blip = np.sin(2 * np.pi * freq * t) * _sfx_env(blen, attack=0.3)
        end = min(n, pos + blen)
        y[pos:end] += blip[:end - pos] * 0.55
        pos += blen + int(rng.integers(int(0.01 * SFX_SR), int(0.06 * SFX_SR)))
    return y


def _sfx_ting(dur=0.9, seed=31):
    """Bright bell-like 'ting' (sine + harmonic, long decay)."""
    n = int(dur * SFX_SR)
    t = np.arange(n) / SFX_SR
    y = (np.sin(2 * np.pi * 1568 * t) * 0.6
         + np.sin(2 * np.pi * 2093 * t) * 0.3
         + np.sin(2 * np.pi * 2637 * t) * 0.15)
    return (0.5 * y * np.exp(-t * 5.5) * _sfx_env(n, attack=0.01)).astype(np.float32)


def _sfx_shutter():
    """Camera shutter: two mechanical clicks."""
    n = int(0.35 * SFX_SR)
    y = np.zeros(n, dtype=np.float32)
    for start, seed in ((0, 41), (int(0.09 * SFX_SR), 42)):
        click = _sfx_noise(0.035, seed=seed, gain=0.8, attack=0.02)
        end = min(n, start + len(click))
        y[start:end] += click[:end - start]
    tone = _sfx_tone(0.05, 2400, 60, gain=0.25)
    y[:len(tone)] += tone
    return y


def _sfx_splash(dur=0.9, seed=51):
    """Water splash: noise burst with falling brightness."""
    n = int(dur * SFX_SR)
    rng = np.random.default_rng(seed)
    x = rng.standard_normal(n).astype(np.float32)
    fc = np.linspace(6500, 500, n)
    a = 1 - np.exp(-2 * np.pi * fc / SFX_SR)
    y = np.empty(n, dtype=np.float32)
    acc = 0.0
    for i in range(n):
        acc += a[i] * (x[i] - acc)
        y[i] = acc
    y /= max(1e-6, np.max(np.abs(y)))
    return (0.6 * y * _sfx_env(n, attack=0.04)).astype(np.float32)


def _sfx_cap_open():
    """Bottle cap pop: metallic ping + pressure release hiss."""
    n = int(0.4 * SFX_SR)
    y = np.zeros(n, dtype=np.float32)
    ping = _sfx_tone(0.12, 880, 28, gain=0.55)
    y[:len(ping)] += ping
    hiss = _sfx_noise(0.22, seed=61, gain=0.35, attack=0.05)
    y[:len(hiss)] += hiss
    return y


def _sfx_click():
    """Short UI click."""
    n = int(0.07 * SFX_SR)
    y = _sfx_noise(0.07, seed=71, gain=0.5, attack=0.02)
    tone = _sfx_tone(0.05, 1250, 70, gain=0.4)
    y[:len(tone)] += tone
    return y


SFX_KINDS = {
    "soft_whoosh": "Soft Whoosh",
    "whoosh": "Whoosh",
    "riser": "Riser",
    "drop": "Drop",
    "pop": "Pop",
    "ting": "Ting",
    "click": "Click",
    "shutter": "Camera Shutter",
    "splash": "Splash",
    "cap_open": "Bottle Cap Open",
    "glitch": "Glitch",
    "flash": "Flash",
    "thump": "Thump",
    "shimmer": "Shimmer",
}

# --- v2.15: user-supplied real recordings (assets/sfx/) ---
USER_SFX_FILES = {
    "typing_loop": "typing-loop.mp3",      # keyboard typing (his file)
    "shutter_real": "shutter-real.mp3",     # real camera shutter (his file)
    "cap_open_real": "cap-open-real.mp3",   # real bottle cap (his file)
    "retrieve_pop": "retrieve-pop.mp3",     # retrieve pop (his file)
}
USER_SFX = {
    "typing_loop": "\u2328\ufe0f Typing Loop (yours)",
    "shutter_real": "\U0001f4f7 Camera Shutter (real)",
    "cap_open_real": "\U0001f37e Bottle Cap Open (real)",
    "retrieve_pop": "\U0001f514 Retrieve Pop (yours)",
}
SFX_KINDS_ALL = {**SFX_KINDS, **USER_SFX}
_user_sfx_cache = {}


def _load_user_sfx(kind):
    """Decode a user-supplied mp3 from assets/sfx/ to float32 mono 44.1kHz."""
    if kind in _user_sfx_cache:
        return _user_sfx_cache[kind]
    fname = USER_SFX_FILES.get(kind)
    if not fname:
        return None
    path = os.path.join(_ASSETS_DIR, "sfx", fname)
    if not os.path.exists(path):
        return None
    try:
        r = subprocess.run(
            ["ffmpeg", "-v", "error", "-i", path,
             "-ac", "1", "-ar", str(SFX_SR), "-f", "f32le", "-"],
            capture_output=True)
        if r.returncode != 0 or not r.stdout:
            return None
        buf = np.frombuffer(r.stdout, dtype=np.float32).copy()
        _user_sfx_cache[kind] = buf
        return buf
    except Exception:
        return None


def is_capcut_sfx(kind):
    """v2.17: True for cc_<id> CapCut-library sounds."""
    if not (isinstance(kind, str) and kind.startswith("cc_")):
        return False
    try:
        from capcut_sfx import list_sfx
        want = kind[3:]
        return any(i == want for i, _, _ in list_sfx())
    except Exception:
        return False


def valid_sfx_kind(kind):
    """v2.17: SFX_KINDS_ALL + user files + CapCut library."""
    return bool(kind) and (kind in SFX_KINDS_ALL or is_capcut_sfx(kind))


def synthesize_sfx(kind):
    if kind in USER_SFX_FILES:  # v2.15: user-supplied real recordings
        buf = _load_user_sfx(kind)
        if buf is not None:
            return buf
    if isinstance(kind, str) and kind.startswith("cc_"):  # v2.17: CapCut lib
        try:
            from capcut_sfx import render as _cc_render
            buf = _cc_render(kind[3:])
            if buf is not None:
                return buf
        except Exception:
            pass
    if kind == "whoosh":
        return _sfx_noise(0.7, seed=11, gain=0.55)
    if kind == "soft_whoosh":
        return _sfx_noise(0.8, seed=12, gain=0.38, attack=0.25)
    if kind == "riser":
        return _sfx_chirp(0.8, 180, 2600, gain=0.5)
    if kind == "drop":
        return _sfx_chirp(0.7, 1600, 110, gain=0.5)
    if kind == "pop":
        tone = _sfx_tone(0.28, 660, 16, gain=0.6)
        click = _sfx_noise(0.06, seed=13, gain=0.35, attack=0.02)
        tone[:len(click)] += click
        return tone
    if kind == "thump":
        return _sfx_tone(0.5, 58, 9, gain=0.7)
    if kind == "shimmer":
        n = int(0.7 * SFX_SR)
        t = np.arange(n) / SFX_SR
        y = (np.sin(2 * np.pi * 2800 * t) * (0.6 + 0.4 * np.sin(2 * np.pi * 26 * t))
             * np.exp(-t * 6) * _sfx_env(n, attack=0.03))
        return (0.4 * y).astype(np.float32)
    if kind == "glitch":
        return _sfx_glitch()
    if kind == "ting":
        return _sfx_ting()
    if kind == "shutter":
        return _sfx_shutter()
    if kind == "splash":
        return _sfx_splash()
    if kind == "cap_open":
        return _sfx_cap_open()
    if kind == "click":
        return _sfx_click()
    if kind == "flash":
        snap = _sfx_noise(0.14, seed=14, gain=0.6, attack=0.02)
        pop = _sfx_tone(0.3, 880, 14, gain=0.45)
        out = np.zeros(max(len(snap), len(pop)), dtype=np.float32)
        out[:len(pop)] += pop
        out[:len(snap)] += snap
        return out
    return _sfx_noise(0.6, seed=99, gain=0.4)


def _write_wav_mono(path, data, sr=SFX_SR):
    """Write float32 mono [-1,1] to 16-bit PCM WAV."""
    import wave
    pcm = (np.clip(data, -1.0, 1.0) * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())


def _event_buffer(kw):
    """Buffer for an extra SFX event: SFX_KINDS_ALL key or audio file path."""
    if isinstance(kw, str) and valid_sfx_kind(kw):
        return synthesize_sfx(kw)
    if isinstance(kw, str) and os.path.exists(kw):
        try:
            r = subprocess.run(
                ["ffmpeg", "-v", "error", "-i", kw, "-ac", "1",
                 "-ar", str(SFX_SR), "-f", "f32le", "-"],
                capture_output=True)
            if r.returncode == 0 and r.stdout:
                return np.frombuffer(r.stdout, dtype=np.float32).copy()
        except Exception:
            pass
    return None


def build_sfx_track(transition, bounds, t_trans, out_path, gain=0.5, kind=None,
                    extra_events=None):
    """Mix transition SFX at every cut point; return wav path or None.

    kind: explicit SFX_KINDS_ALL key (user's choice); otherwise the transition's
    default from TRANSITION_SFX is used.
    extra_events: v2.15 list of (time_sec, kind_or_audio_path, gain) mixed at
    absolute times (e.g. B-roll typing sounds).
    """
    kind = kind or TRANSITION_SFX.get(transition)
    if kind and not valid_sfx_kind(kind):
        kind = None
    extra_events = extra_events or []
    if (not kind or len(bounds) < 3) and not extra_events:
        return None
    total = bounds[-1]
    mix = np.zeros(int(total * SFX_SR) + SFX_SR * 4, dtype=np.float32)
    if kind and len(bounds) >= 3:
        sfx = synthesize_sfx(kind)
        for i in range(1, len(bounds) - 1):
            # cut i in the final (xfade-overlapped) timeline sits at bounds[i] - t_trans*i
            center = bounds[i] - t_trans * i
            start = int(max(0.0, center - (len(sfx) / SFX_SR) * 0.5) * SFX_SR)
            end = start + len(sfx)
            if end > len(mix):
                mix = np.pad(mix, (0, end - len(mix)))
            mix[start:end] += sfx * gain
    for (t, kw, g) in extra_events:
        buf = _event_buffer(kw)
        if buf is None:
            continue
        start = int(max(0.0, t) * SFX_SR)
        end = start + len(buf)
        if end > len(mix):
            mix = np.pad(mix, (0, end - len(mix)))
        mix[start:end] += buf * max(0.0, min(1.0, g))
    _write_wav_mono(out_path, mix)
    return out_path


_ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
_PENCIL_IMG = None  # cached (img, tip_xy)


def _pencil_image():
    """Yellow pencil (diagonal, tip at bottom-left), drawn with PIL. Cached."""
    global _PENCIL_IMG
    if _PENCIL_IMG is not None:
        return _PENCIL_IMG
    from PIL import Image, ImageDraw
    import math
    S = 200
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    dr = ImageDraw.Draw(img)
    dx, dy = math.sqrt(2) / 2, -math.sqrt(2) / 2   # up-right
    vx, vy = math.sqrt(2) / 2, math.sqrt(2) / 2    # perpendicular
    tx, ty, L, w = 40, 150, 100, 26
    def pt(t, s):
        return (tx + dx * t + vx * s, ty + dy * t + vy * s)
    b0 = 26
    dr.polygon([pt(b0, -w / 2), pt(b0, w / 2), pt(L, w / 2), pt(L, -w / 2)],
               fill=(245, 197, 66, 255), outline=(96, 64, 24, 255), width=2)
    dr.polygon([pt(8, 0), pt(b0, -w / 2), pt(b0, w / 2)],
               fill=(233, 196, 158, 255), outline=(96, 64, 24, 255), width=2)
    dr.polygon([pt(0, 0), pt(8, -6), pt(8, 6)], fill=(52, 52, 52, 255))
    dr.polygon([pt(L, -w / 2), pt(L, w / 2), pt(L + 16, w / 2), pt(L + 16, -w / 2)],
               fill=(198, 198, 206, 255), outline=(96, 64, 24, 255), width=2)
    dr.polygon([pt(L + 16, -w / 2), pt(L + 16, w / 2), pt(L + 34, w / 2), pt(L + 34, -w / 2)],
               fill=(240, 140, 156, 255), outline=(96, 64, 24, 255), width=2)
    _PENCIL_IMG = (img, (tx, ty))
    return _PENCIL_IMG


def _hand_font(size):
    """Handwriting font for doodle labels (bundled, OFL). Falls back to default."""
    from PIL import ImageFont
    ttf = os.path.join(_ASSETS_DIR, "GochiHand-Regular.ttf")
    try:
        if os.path.exists(ttf):
            return ImageFont.truetype(ttf, size)
    except Exception:
        pass
    return ImageFont.load_default()


def pencil_draw_clip(img_path, out_path, duration, label=None, draw_time=0.8,
                     fps=30, width=1280, height=720, paper=(246, 241, 231)):
    """Whiteboard-style draw-on clip: a pencil draws the image left-to-right,
    then an optional handwritten label fades in below.

    img_path: source doodle image (any size; scaled to fill the frame).
    label: handwritten caption drawn under the doodle (None to skip).
    draw_time: seconds the pencil takes (smaller = faster).
    """
    from PIL import Image, ImageDraw
    W, H = width, height
    paper_img = Image.new("RGB", (W, H), paper)
    doodle = Image.open(img_path).convert("RGB").resize((W, H), Image.LANCZOS)
    pencil, tip = _pencil_image()
    label_img = None
    if label:
        label_img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        fnt = _hand_font(max(40, int(H * 0.083)))
        ImageDraw.Draw(label_img).text((int(W * 0.055), int(H * 0.883)),
                                       str(label), font=fnt, fill=(56, 52, 48, 255))
    n = max(1, int(round(duration * fps)))
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24",
           "-s", f"{W}x{H}", "-framerate", str(fps), "-i", "-",
           "-c:v", "libx264", "-preset", "medium", "-pix_fmt", "yuv420p", out_path]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    try:
        for i in range(n):
            t = i / fps
            if t < draw_time:
                fx = int(W * min(1.0, t / draw_time))
                feather = max(8, W // 38)
                mask = Image.new("L", (W, H), 0)
                md = ImageDraw.Draw(mask)
                md.rectangle([0, 0, max(0, fx - feather), H], fill=255)
                for x in range(max(0, fx - feather), fx):
                    a = int(255 * (x - (fx - feather)) / feather)
                    md.line([(x, 0), (x, H)], fill=a)
                frame = Image.composite(doodle, paper_img.copy(), mask)
                if t < draw_time + 0.15:
                    frame.paste(pencil, (fx - tip[0], int(H * 0.44) - tip[1]), pencil)
            else:
                frame = doodle.copy()
                if label_img is not None:
                    la = min(1.0, max(0.0, (t - draw_time) / 0.45))
                    if la > 0:
                        ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
                        lc = label_img.copy()
                        lc.putalpha(label_img.split()[3].point(lambda v: int(v * la)))
                        ov.alpha_composite(lc)
                        frame = Image.alpha_composite(
                            frame.convert("RGBA"), ov).convert("RGB")
            proc.stdin.write(frame.tobytes())
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()
    if proc.returncode != 0:
        raise RuntimeError("pencil draw render failed")
    return out_path


def _overlay_png(style, text, W, H):
    """Render a text overlay as an RGBA PIL image.

    style: "pill" (blue badge top-right + pointer line, like the 3D-icon
      scenes) or "big" (large bold center word, kinetic).
    """
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    dr = ImageDraw.Draw(img)
    try:
        bold = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
        f_pill = ImageFont.truetype(bold, max(20, int(H * 0.055)))
        f_big = ImageFont.truetype(bold, max(28, int(H * 0.105)))
    except Exception:
        f_pill = f_big = ImageFont.load_default()
    text = str(text or "").strip()
    if not text:
        return img
    blue = (43, 95, 217, 255)
    if style == "pill":
        bb = dr.textbbox((0, 0), text, font=f_pill)
        tw, th = bb[2] - bb[0], bb[3] - bb[1]
        px, py = 30, 16
        bw, bh = tw + px * 2, th + py * 2
        bx, by = W - bw - 60, 84
        dr.rounded_rectangle([bx, by, bx + bw, by + bh], radius=bh // 2, fill=blue)
        dr.text((bx + px - bb[0], by + py - bb[1]), text,
                font=f_pill, fill=(255, 255, 255, 255))
        dr.line([(bx + 24, by + bh), (bx - 150, by + bh + 130)], fill=blue, width=5)
    else:  # big kinetic word
        bb = dr.textbbox((0, 0), text, font=f_big)
        tw = bb[2] - bb[0]
        dr.text(((W - tw) // 2 - bb[0], int(H * 0.36) - bb[1]), text,
                font=f_big, fill=(255, 255, 255, 255),
                stroke_width=3, stroke_fill=(20, 20, 20, 255))
    return img


def _rawvideo_pipe(out_path, W, H, fps):
    """Open an ffmpeg rawvideo pipe for PIL frames. Returns (proc, write_fn, close_fn)."""
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24",
           "-s", f"{W}x{H}", "-framerate", str(fps), "-i", "-",
           "-c:v", "libx264", "-preset", "medium", "-pix_fmt", "yuv420p", out_path]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    def close():
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()
        if proc.returncode != 0:
            raise RuntimeError("clip render failed: " + out_path)
    return proc, proc.stdin.write, close


def photo_clip(img_path, out_path, duration, overlay=None, fps=30,
               width=1280, height=720):
    """Slow zoom-in on a photo + optional RGBA overlay (fades in/out)."""
    from PIL import Image
    W, H = width, height
    base = Image.open(img_path).convert("RGB")
    s = max(W * 1.18 / base.width, H * 1.18 / base.height)
    big = base.resize((int(base.width * s) + 1, int(base.height * s) + 1),
                      Image.LANCZOS)
    n = max(1, int(round(duration * fps)))
    proc, write, close = _rawvideo_pipe(out_path, W, H, fps)
    try:
        for i in range(n):
            t = i / fps
            z = 1.0 + 0.12 * min(1.0, t / max(0.1, duration))
            cw, ch = int(W * 1.18 / z), int(H * 1.18 / z)
            x0, y0 = (big.width - cw) // 2, (big.height - ch) // 2
            frame = big.crop((x0, y0, x0 + cw, y0 + ch)).resize((W, H), Image.LANCZOS)
            if overlay is not None:
                a_in = min(1.0, max(0.0, (t - 0.3) / 0.4))
                a_out = min(1.0, max(0.0, (duration - t - 0.15) / 0.5))
                la = min(a_in, a_out)
                if la > 0:
                    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
                    oc = overlay.copy()
                    oc.putalpha(overlay.split()[3].point(lambda v: int(v * la)))
                    ov.alpha_composite(oc)
                    frame = Image.alpha_composite(
                        frame.convert("RGBA"), ov).convert("RGB")
            write(frame.tobytes())
    finally:
        close()
    return out_path


def _bg_brightness(hex_color):
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255


def explainer_clip(img_path, out_path, duration, bg_color="#FFFFFF", label=None,
                   fps=24, width=1280, height=720):
    """Explainer style segment: the icon pops in (ease-out scale-up) on a solid
    color-coded section background, with an optional label underneath.

    Matches the kinetic explainer reference (color sections + animated icons).
    """
    from PIL import Image, ImageDraw
    W, H = width, height
    bg = Image.new("RGB", (W, H), bg_color)
    icon = Image.open(img_path).convert("RGBA")
    max_w, max_h = int(W * 0.62), int(H * 0.56)
    s = min(max_w / icon.width, max_h / icon.height, 1.0)
    iw, ih = max(1, int(icon.width * s)), max(1, int(icon.height * s))
    icon = icon.resize((iw, ih), Image.LANCZOS)
    dark_text = _bg_brightness(bg_color) > 0.55
    text_c = (30, 30, 34) if dark_text else (255, 255, 255)
    font = _hand_font(int(H * 0.052))
    pop_dur = min(0.5, duration * 0.4)
    n_pop = max(1, int(round(pop_dur * fps)))
    n_total = max(1, int(round(duration * fps)))
    proc, write, close = _rawvideo_pipe(out_path, W, H, fps)
    try:
        for i in range(n_total):
            if i < n_pop:
                t = (i + 1) / n_pop
                ease = 1 - (1 - t) ** 3  # ease-out cubic
                sc = 0.7 + 0.3 * ease
            else:
                sc = 1.0
            frame = bg.copy()
            pw, ph = max(1, int(iw * sc)), max(1, int(ih * sc))
            ic = icon.resize((pw, ph), Image.LANCZOS)
            ix, iy = (W - pw) // 2, (H - ph) // 2 - int(H * 0.05)
            frame.paste(ic, (ix, iy), ic)
            if label:
                dr = ImageDraw.Draw(frame)
                bb = dr.textbbox((0, 0), label, font=font)
                tw = bb[2] - bb[0]
                ty = iy + ph + int(H * 0.025)
                dr.text(((W - tw) // 2, ty), label, font=font, fill=text_c)
            write(frame.tobytes())
    finally:
        close()
    return out_path


def video_overlay_clip(in_path, out_path, duration, overlay_path):
    """Burn a fading overlay PNG onto a stock video clip (no audio kept)."""
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", in_path,
           "-loop", "1", "-framerate", "30", "-t", f"{duration:.3f}",
           "-i", overlay_path, "-filter_complex",
           f"[1:v]format=rgba,fade=t=in:st=0.3:d=0.4:alpha=1,"
           f"fade=t=out:st={max(0.4, duration - 0.7):.3f}:d=0.5:alpha=1[ov];"
           f"[0:v][ov]overlay=(W-w)/2:(H-h)/2:shortest=1,format=yuv420p[v]",
           "-map", "[v]", "-an", "-c:v", "libx264", "-preset", "medium",
           out_path]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("video overlay failed: " + r.stderr[-600:])
    return out_path


def _motion_filter(motion, tf, W, H, fps):
    """Ken Burns style motion via zoompan. Input is pre-scaled to 2560x1440."""
    pre = "scale=2560:1440:force_original_aspect_ratio=increase,crop=2560:1440"
    cx, cy = "iw/2-(iw/zoom/2)", "ih/2-(ih/zoom/2)"
    if motion == "zoomin":
        z, x, y = f"1+0.18*on/{tf}", cx, cy
    elif motion == "zoomout":
        z, x, y = f"1.18-0.18*on/{tf}", cx, cy
    elif motion == "panleft":
        z, x, y = "1.3", f"(iw-iw/zoom)*(1-on/{tf})", cy
    elif motion == "panright":
        z, x, y = "1.3", f"(iw-iw/zoom)*on/{tf}", cy
    elif motion == "panup":
        z, x, y = "1.3", cx, f"(ih-ih/zoom)*(1-on/{tf})"
    elif motion == "pandown":
        z, x, y = "1.3", cx, f"(ih-ih/zoom)*on/{tf}"
    else:
        return None
    zp = (f"zoompan=z='{z}':x='{x}':y='{y}':d=1:s={W}x{H}:fps={fps}")
    return f"{pre},{zp},setsar=1"


# ----------------------------------------------------------------------------
# v2.17: CapCut-style Adjustments (16 sliders) -> ffmpeg filter chain
# ----------------------------------------------------------------------------
ADJUSTMENTS = [
    ("brightness", "Brightness"), ("contrast", "Contrast"),
    ("exposure", "Exposure"), ("highlights", "Highlights"),
    ("shadows", "Shadows"), ("whites", "Whites"), ("blacks", "Blacks"),
    ("saturation", "Saturation"), ("temperature", "Temperature"),
    ("tint", "Tint"), ("hue", "Hue"), ("fade", "Fade"),
    ("sharpness", "Sharpness"), ("definition", "Definition"),
    ("vignette", "Vignette"), ("grain", "Grain"),
]


def adjustments_filter(adj):
    """Build an ffmpeg filter string from {name: -100..100} adjustments."""
    def g(k):
        try:
            return max(-100, min(100, int(adj.get(k, 0) or 0)))
        except (ValueError, TypeError):
            return 0

    parts = []
    b = g("brightness")
    if b:
        parts.append(f"eq=brightness={b / 100:.3f}")
    e = g("exposure")
    if e:
        parts.append(f"eq=brightness={e / 100 * 1.5:.3f}")
    c = g("contrast")
    if c:
        parts.append(f"eq=contrast={1 + c / 100:.3f}")
    s = g("saturation")
    if s:
        parts.append(f"eq=saturation={1 + s / 100:.3f}")
    # tone curves: highlights / shadows / whites / blacks
    hl, sh, wh, bl = g("highlights"), g("shadows"), g("whites"), g("blacks")
    if hl or sh or wh or bl:
        pts = [[0.0, 0.0], [0.25, 0.25], [0.5, 0.5], [0.75, 0.75], [1.0, 1.0]]
        if sh:
            pts[0][1] = max(0.0, sh * 0.003)
        if bl:
            pts[0][1] = max(0.0, pts[0][1] + bl * 0.002)
        if hl:
            pts[3][1] = min(1.0, max(0.0, 0.75 + hl * 0.0025))
        if wh:
            pts[4][1] = min(1.0, max(0.0, 1.0 + wh * 0.003))
        curve = " ".join(f"{x:.3f}/{y:.3f}" for x, y in pts)
        parts.append(f"curves=all='{curve}'")
    t = g("temperature")
    if t:
        parts.append(f"colorbalance=rs={t * 0.004:.3f}:bs={-t * 0.004:.3f}")
    ti = g("tint")
    if ti:
        parts.append(f"colorbalance=gs={ti * 0.004:.3f}")
    hu = g("hue")
    if hu:
        parts.append(f"hue=h={hu * 1.8:.1f}")
    fd = max(0, min(100, g("fade")))
    if fd:
        parts.append(f"eq=contrast={1 - fd / 250:.3f}:brightness={fd / 250:.3f}")
    shp = g("sharpness")
    if shp > 0:
        parts.append(f"unsharp=5:5:{shp / 100 * 1.5:.2f}:5:5:0.0")
    elif shp < 0:
        parts.append(f"boxblur={-shp / 100 * 2:.2f}:1")
    dfn = max(0, min(100, g("definition")))
    if dfn:
        parts.append(f"unsharp=7:7:{dfn / 100:.2f}:7:7:0.0")
    vg = max(0, min(100, g("vignette")))
    if vg:
        ang = 3.14159 / max(2.2, 5 - vg / 100 * 2.8)
        parts.append(f"vignette=angle={ang:.3f}")
    gr = max(0, min(100, g("grain")))
    if gr:
        parts.append(f"noise=alls={gr * 0.35:.1f}:allf=t")
    return ",".join(parts)


def _effect_filter(effect, W, H):
    if effect == "grain":
        return "noise=alls=7:allf=t"
    if effect == "vhs":
        return "noise=alls=5:allf=t,eq=contrast=1.05:saturation=1.35,vignette=angle=PI/5"
    if effect == "rgbsplit":
        return "handled-inline"  # special-cased in build_video (multi-stream)
    if effect == "shake":
        return (f"crop=iw-24:ih-24:'12+7*sin(2*PI*t*3)':"
                f"'12+7*cos(2*PI*t*2.2)',scale={W}:{H}")
    if effect == "blurfocus":
        # NOTE: modern ffmpeg evaluates gblur sigma once (no per-frame 't'),
        # so animate via timeline editing: strong blur -> medium -> light.
        return ("gblur=sigma=8:enable='lt(t,0.5)',"
                "gblur=sigma=4:enable='between(t,0.5,1)',"
                "gblur=sigma=1.5:enable='between(t,1,1.5)'")
    if effect == "fisheye":
        return "lenscorrection=k1=0.4:k2=0.4"
    if effect == "vignette":
        return "vignette=angle=PI/5"
    if effect == "dream":
        return "gblur=sigma=1.2,eq=saturation=1.35:contrast=1.04:brightness=0.03"
    if effect == "sharpen":
        return "unsharp=5:5:1.0:5:5:0.0"
    if effect == "softblur":
        return "gblur=sigma=2"
    if effect == "edgedetect":
        return "edgedetect=mode=colormix"
    if effect == "negate":
        return "negate"
    if effect == "sepia":
        return ("colorchannelmixer=.393:.769:.189:0:.349:.686:.168:0:"
                ".272:.534:.131")
    if effect == "grayscale":
        return "eq=saturation=0"
    if effect == "pixelate":
        return (f"scale={W // 8}:{H // 8},"
                f"scale={W}:{H}:flags=neighbor")
    if effect == "warm":
        return "colorbalance=rs=0.25:gs=0.08:bs=-0.15,eq=saturation=1.15"
    if effect == "cold":
        return "colorbalance=rs=-0.15:gs=0.02:bs=0.25,eq=saturation=1.1"
    if effect == "fadefilm":
        return "eq=contrast=0.85:brightness=0.08:saturation=0.85"
    if effect == "clarity":
        return "unsharp=7:7:0.8:7:7:0.0,eq=contrast=1.08:saturation=1.1"
    return ""
    return None


def _ass_time(s):
    h = int(s // 3600)
    m = int((s % 3600) // 60)
    return f"{h}:{m:02d}:{s % 60:05.2f}"


def _hex_to_ass(h):
    h = h.lstrip("#")
    return f"&H00{h[4:6]}{h[2:4]}{h[0:2]}".upper()


def words_to_txt(words):
    """Plain transcript text from word timestamps."""
    return "".join(w["word"] for w in words).strip()


def _vtt_time(s):
    ms = int(round(max(0.0, s) * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    sec, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{sec:02d}.{ms:03d}"


def _mmss(s):
    s = int(max(0.0, s))
    return f"{s // 60:02d}:{s % 60:02d}"


def words_to_vtt(words):
    """WebVTT subtitles from word timestamps (YouTube/Vimeo friendly)."""
    cues, cur = [], []
    for w in words:
        cur.append(w)
        dur = w["end"] - cur[0]["start"]
        if len(cur) >= 10 or dur > 4.0 or w["word"].strip().endswith((".", "!", "?", "…")):
            cues.append(cur)
            cur = []
    if cur:
        cues.append(cur)
    out = ["WEBVTT", ""]
    for c in cues:
        text = "".join(x["word"] for x in c).strip()
        out.append(f"{_vtt_time(c[0]['start'])} --> {_vtt_time(c[-1]['end'])}\n{text}\n")
    return "\n".join(out)


def words_to_stamped(words):
    """Script with timestamps: one [mm:ss] line per sentence/chunk.

    Example:
        [00:00] Look at this amazing jump over the pool.
        [00:04] What a moment, absolutely shocking finish.
    """
    chunks, cur = [], []
    for w in words:
        cur.append(w)
        dur = w["end"] - cur[0]["start"]
        if (len(cur) >= 14 or dur > 8.0
                or w["word"].strip().endswith((".", "!", "?", "…"))):
            chunks.append(cur)
            cur = []
    if cur:
        chunks.append(cur)
    lines = []
    for c in chunks:
        text = "".join(x["word"] for x in c).strip()
        if text:
            lines.append(f"[{_mmss(c[0]['start'])}] {text}")
    return "\n".join(lines)


EXPORT_FORMATS = {
    "srt": ("words_to_srt", "transcript.srt"),
    "txt": ("words_to_txt", "transcript.txt"),
    "vtt": ("words_to_vtt", "transcript.vtt"),
    "stamped": ("words_to_stamped", "script-with-timestamps.txt"),
}


def _srt_time(s):
    ms = int(round(max(0.0, s) * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    sec, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"


def words_to_srt(words):
    """Group word timestamps into SRT subtitle cues (max ~2 lines each)."""
    cues, cur = [], []
    for w in words:
        cur.append(w)
        dur = w["end"] - cur[0]["start"]
        if len(cur) >= 10 or dur > 4.0 or w["word"].strip().endswith((".", "!", "?", "…")):
            cues.append(cur)
            cur = []
    if cur:
        cues.append(cur)
    out = []
    for i, c in enumerate(cues, 1):
        text = "".join(x["word"] for x in c).strip()
        if len(text) > 42:  # wrap long cues to 2 lines
            sp = text.rfind(" ", 0, 45)
            if sp > 10:
                text = text[:sp] + "\n" + text[sp + 1:]
        out.append(f"{i}\n{_srt_time(c[0]['start'])} --> {_srt_time(c[-1]['end'])}\n{text}\n")
    return "\n".join(out)


def _caption_xy(grid, W, H, dx, dy, pos_x_pct=None, pos_y_pct=None):
    """Anchor point for the 9-grid + user offsets.
    v2.20: if pos_x_pct/pos_y_pct given, use exact percentages."""
    if pos_x_pct is not None and pos_y_pct is not None:
        x = W * pos_x_pct / 100 + dx
        y = H * pos_y_pct / 100 + dy
        return int(x), int(y)
    row, col = grid.split("-")
    x = {"left": W * 0.25, "center": W / 2, "right": W * 0.75}[col] + dx
    y = {"top": H * 0.16, "middle": H / 2, "bottom": H * 0.84}[row] + dy
    return int(x), int(y)


def _grid_to_ass_align(grid):
    row, col = grid.split("-")
    base = {"left": 1, "center": 2, "right": 3}[col]
    return base + {"bottom": 0, "middle": 3, "top": 6}[row]


def _anim_tags(anim, x, y):
    if anim == "fade":
        return r"{\fad(180,180)}"
    if anim == "pop":
        return r"{\fscx25\fscy25\t(0,280,\fscx100\fscy100)}"
    if anim == "slide_up":
        return r"{\move(%d,%d,%d,%d,0,320)}" % (x, y + 60, x, y)
    if anim == "slide_down":
        return r"{\move(%d,%d,%d,%d,0,320)}" % (x, y - 60, x, y)
    return ""


def _wordbox_class(word):
    """Classify a word for explainer boxes: 'danger' (red), 'hot' (yellow), or None."""
    raw = word.strip().strip(".,!?…:;\"'()")
    w = raw.lower()
    if not w:
        return None
    if w in DANGER_WORDS:
        return "danger"
    if len(w) > 5 or any(ch.isdigit() for ch in w) or (raw.isupper() and len(raw) > 1):
        return "hot"
    return None


def _emit_wordbox_line(events, ws, p, x, y, end=None):
    """Explainer kinetic line: important words get yellow boxes, danger words red.

    Uses inline {\\rYB}/{\\rRB} style switches so each word carries its own box.
    """
    s0 = ws[0]["start"]
    s1 = end if end is not None else ws[-1]["end"] + 0.25
    upper = (lambda s: s.upper()) if p["uppercase"] else (lambda s: s)
    parts = []
    for w in ws:
        cls = _wordbox_class(w["word"])
        txt = upper(w["word"])
        if cls == "danger":
            parts.append(r"{\rRB}" + txt + r"{\rCap}")
        elif cls == "hot":
            parts.append(r"{\rYB}" + txt + r"{\rCap}")
        else:
            parts.append(txt)
    text = "".join(parts).strip()
    tags = r"{\\pos(%d,%d)}" % (x, y) + _anim_tags(p["anim"], x, y)
    if p["glow"]:
        tags += r"{\\blur2}"
    events.append(f"Dialogue: 0,{_ass_time(s0)},{_ass_time(s1)},Cap,,0,0,0,,{tags}{text}")


def _emit_duo_line(events, ws, p, x, y, end=None, color_idx=0):
    """v2.19 Viral Duo: keywords (ALL CAPS, colored, glow) on top line,
    rest of sentence (white, smaller) below. Colors cycle per cue."""
    s0 = ws[0]["start"]
    s1 = end if end is not None else ws[-1]["end"] + 0.25
    colors = p.get("duo_colors") or ["#00E676", "#40C4FF", "#FFD740"]
    kw_color = colors[color_idx % len(colors)]
    kw_ass = _hex_to_ass(kw_color)
    # split: first 2-3 words = keywords, rest = context
    n_kw = 3 if len(ws) > 5 else 2
    n_kw = min(n_kw, len(ws))
    kws = " ".join(w["word"] for w in ws[:n_kw]).upper().strip()
    rest = " ".join(w["word"] for w in ws[n_kw:]).strip()
    tags = r"{\pos(%d,%d)}" % (x, y) + _anim_tags(p["anim"], x, y)
    tags += r"{\blur2}"
    # keywords: bigger, colored with glow
    kw_size = int(p["size"] * 1.15)
    line1 = r"{\fs%d\1c%s}" % (kw_size, kw_ass) + kws
    if rest:
        # context: smaller, white, below
        rest_size = int(p["size"] * 0.62)
        line2 = r"{\fs%d\1c&HFFFFFF&}" % rest_size + rest
        text = line1 + r"\N" + line2
    else:
        text = line1
    events.append(f"Dialogue: 0,{_ass_time(s0)},{_ass_time(s1)},Cap,,0,0,0,,{tags}{text}")


def _emit_caption_line(events, ws, p, x, y, end=None):
    """Emit one ASS dialogue event from a word chunk + resolved preset.

    end: explicit line end time; defaults to last word end + 0.25s tail.
    Pass a clamped end so the tail never overlaps the next line's pop-in.
    """
    s0 = ws[0]["start"]
    s1 = end if end is not None else ws[-1]["end"] + 0.25
    upper = (lambda s: s.upper()) if p["uppercase"] else (lambda s: s)

    def karaoke_text(part):
        out = []
        for w in part:
            k = max(1, int(round((w["end"] - w["start"]) * 100)))
            out.append("{\\k%d}%s" % (k, upper(w["word"])))
        return "".join(out)

    def plain_text(part):
        return upper("".join(w["word"] for w in part)).strip()

    halves = [ws]
    if p["lines"] == 2 and len(ws) > 1:
        mid = len(ws) // 2
        halves = [ws[:mid], ws[mid:]]

    tags = r"{\pos(%d,%d)}" % (x, y) + _anim_tags(p["anim"], x, y)
    if p["glow"]:
        tags += r"{\blur2}"
    if p["karaoke"] == "word":
        text = "\\N".join(karaoke_text(h) for h in halves)
        events.append(f"Dialogue: 0,{_ass_time(s0)},{_ass_time(s1)},Cap,,0,0,0,,{tags}{text}")
    elif p["karaoke"] == "reveal":
        for j in range(len(ws)):
            t = plain_text(ws[:j + 1])
            events.append(
                f"Dialogue: 0,{_ass_time(ws[j]['start'])},{_ass_time(s1)},Cap,,0,0,0,,{tags}{t}")
    else:
        text = "\\N".join(plain_text(h) for h in halves)
        events.append(f"Dialogue: 0,{_ass_time(s0)},{_ass_time(s1)},Cap,,0,0,0,,{tags}{text}")


def build_ass_file(words, segments, opts, W, H, path, extra_events=None):
    """Write an ASS subtitle file from word timestamps (preset engine v2).

    opts: preset id + tweaks; see resolve_caption_opts().
    segments: [(start, end)] per cue segment.
    extra_events: v2.15 optional (style_lines, dialogue_lines) to append —
    e.g. B-roll typewriter text overlays generated by broll.py.
    """
    p = resolve_caption_opts(opts)
    primary = _hex_to_ass(p["color"])
    secondary = _hex_to_ass(p["hl"])
    outline_c = _hex_to_ass(p["glow"] or p["outline_color"])
    back_c = (f"&H{max(0, min(255, int(p.get('box_alpha', 0)))):02X}000000"
              if p["box"] else "&H80000000")
    border = 3 if p["box"] else 1
    align = _grid_to_ass_align(p["grid"])
    x, y = _caption_xy(p["grid"], W, H, p["dx"], p["dy"],
                       p.get("_pos_x_pct"), p.get("_pos_y_pct"))
    bold = -1 if p["bold"] else 0

    L = ["[Script Info]", "ScriptType: v4.00+",
         f"PlayResX: {W}", f"PlayResY: {H}", "WrapStyle: 2",
         "[V4+ Styles]",
         "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, "
         "OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, "
         "ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
         "Alignment, MarginL, MarginR, MarginV, Encoding",
         f"Style: Cap,{p['font']},{p['size']},{primary},{secondary},{outline_c},"
         f"{back_c},{bold},0,0,0,100,100,0,0,{border},{p['outline']},{p['shadow']},"
         f"{align},20,20,24,1",
         "[Events]",
         "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, "
         "Effect, Text"]
    wordbox = bool(p.get("wordbox"))
    if wordbox:
        # YB: black text on yellow box | RB: white text on red box
        yb = _hex_to_ass("#FFE600")
        rb = _hex_to_ass(p.get("hl2") or "#FF3B30")
        blk = _hex_to_ass("#000000")
        wht = _hex_to_ass("#FFFFFF")
        L.insert(-2,
                 f"Style: YB,{p['font']},{p['size']},{blk},{blk},{yb},"
                 f"{yb},{bold},0,0,0,100,100,0,0,3,1,0,"
                 f"{align},20,20,24,1")
        L.insert(-2,
                 f"Style: RB,{p['font']},{p['size']},{wht},{wht},{rb},"
                 f"{rb},{bold},0,0,0,100,100,0,0,3,1,0,"
                 f"{align},20,20,24,1")
    # collect all caption line groups first (across segments, chronological)
    all_groups = []
    for s0, s1 in segments:
        seg_words = [w for w in words if s0 - 0.05 <= w["start"] < s1]
        cur = []
        for w in seg_words:
            cur.append(w)
            if len(cur) >= p["wpl"] or w["word"].strip().endswith((".", "!", "?", "…")):
                all_groups.append(cur)
                cur = []
        if cur:
            all_groups.append(cur)
    # clamp each line's tail so it never overlaps the next line's start
    # (avoids double-text ghosting with pop/slide animations)
    for gi, grp in enumerate(all_groups):
        if gi + 1 < len(all_groups):
            nxt = all_groups[gi + 1][0]["start"]
            end = min(grp[-1]["end"] + 0.25, nxt)
        else:
            end = grp[-1]["end"] + 0.25
        if p.get("duo"):
            _emit_duo_line(L, grp, p, x, y, end=end, color_idx=gi)
        elif wordbox:
            _emit_wordbox_line(L, grp, p, x, y, end=end)
        else:
            _emit_caption_line(L, grp, p, x, y, end=end)
    if extra_events:  # v2.15: B-roll overlays etc.
        style_lines, dialogue_lines = extra_events
        for sl in style_lines:
            L.insert(-2, sl)
        L.extend(dialogue_lines)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(L))


def build_video(audio_path, image_paths, cue_starts, out_path, total_duration,
                width=1280, height=720, fps=30,
                transition="none", motion="none", effect="none",
                captions=None, words=None, sfx_on=True,
                sfx_kind=None, sfx_vol=0.5, labels=None, draw_time=0.8,
                kinds=None, ass_extra=None, sfx_extra=None,
                x264_preset="medium", adjustments=None, color_filter=""):
    """Assemble the final MP4: each image/clip covers its cued segment.

    transition: key of TRANSITIONS (xfade between segments, centered on cues)
    motion: key of MOTIONS (Ken Burns on images; clips stay static).
      "pencildraw" renders each image as a whiteboard draw-on clip first
      (hard cuts; transition is forced to "none").
      "smartmix" styles each segment by kinds[i]: "doodle" -> pencil draw,
      "photo" -> slow zoom + pill/big overlay, "video" -> as-is + overlay.
    kinds: per-segment kind list for smartmix ("doodle"/"photo"/"video").
    effect: key of EFFECTS (applied to the whole video)
    captions: None or caption-opts dict (see resolve_caption_opts)
    words: word-timestamp list (needed for captions)
    sfx_on: auto-place a matching sound effect at each transition cut
    labels: optional per-segment handwritten labels (pencildraw only)
    draw_time: seconds the pencil takes per segment (pencildraw only)
    ass_extra: v2.15 (style_lines, dialogue_lines) appended to the ASS file
    sfx_extra: v2.15 [(time, kind_or_audio_path, gain)] mixed into SFX track
    x264_preset: v2.15 "veryfast" (fast export) or "medium" (best quality)
    adjustments: v2.17 {name: -100..100} CapCut-style color adjustments
    """
    W, H = width, height
    n = len(image_paths)
    bounds = [0.0] + list(cue_starts[1:]) + [total_duration]
    durs = [bounds[i + 1] - bounds[i] for i in range(n)]
    if any(d <= 0 for d in durs):
        raise CueError("A segment has zero/negative duration — check your cue order.")

    _draw_tmp = None
    try:
        # --- pencil-draw motion: pre-render each image as a draw-on clip ---
        if motion == "pencildraw":
            import tempfile
            _draw_tmp = tempfile.mkdtemp(prefix="azcut_draw_")
            drawn = []
            for i, img in enumerate(image_paths):
                ext = os.path.splitext(img)[1].lower()
                if ext in VIDEO_EXTS:
                    drawn.append(img)  # video clips can't be drawn; keep as-is
                    continue
                lbl = labels[i] if labels and i < len(labels) else None
                out = os.path.join(_draw_tmp, f"draw{i}.mp4")
                pencil_draw_clip(img, out, durs[i], label=lbl, draw_time=draw_time,
                                 fps=fps, width=W, height=H)
                drawn.append(out)
            image_paths = drawn
            motion = "none"
            transition = "none"  # hard cuts suit the whiteboard style
        # --- smart mix: each segment styled by its kind ---
        elif motion == "smartmix":
            import tempfile
            _draw_tmp = tempfile.mkdtemp(prefix="azcut_mix_")
            kinds = kinds or []
            segs = []
            ov_cycle = ["pill", "big"]
            ov_idx = 0
            for i, img in enumerate(image_paths):
                kind = kinds[i] if i < len(kinds) else "doodle"
                lbl = (labels[i] if labels and i < len(labels) else "") or ""
                out = os.path.join(_draw_tmp, f"mix{i}.mp4")
                if kind == "video":
                    style = ov_cycle[ov_idx % 2]; ov_idx += 1
                    ov_path = os.path.join(_draw_tmp, f"ov{i}.png")
                    _overlay_png(style, lbl, W, H).save(ov_path)
                    video_overlay_clip(img, out, durs[i], ov_path)
                elif kind == "photo":
                    style = ov_cycle[ov_idx % 2]; ov_idx += 1
                    ov = _overlay_png(style, lbl, W, H)
                    photo_clip(img, out, durs[i], overlay=ov, fps=fps,
                               width=W, height=H)
                else:  # doodle -> pencil draw + handwritten label
                    pencil_draw_clip(img, out, durs[i], label=lbl or None,
                                     draw_time=draw_time, fps=fps,
                                     width=W, height=H)
                segs.append(out)
            image_paths = segs
            motion = "none"
            transition = "none"
        # --- explainer: color-coded section backgrounds + icon pop-in ---
        elif motion == "explainer":
            import tempfile
            _draw_tmp = tempfile.mkdtemp(prefix="azcut_exp_")
            segs = []
            for i, img in enumerate(image_paths):
                ext = os.path.splitext(img)[1].lower()
                if ext in VIDEO_EXTS:
                    segs.append(img)  # stock clips play as-is
                    continue
                out = os.path.join(_draw_tmp, f"exp{i}.mp4")
                bgc = EXPLAINER_BGS[i % len(EXPLAINER_BGS)]
                lbl = labels[i] if labels and i < len(labels) else None
                explainer_clip(img, out, durs[i], bg_color=bgc, label=lbl,
                               fps=fps, width=W, height=H)
                segs.append(out)
            image_paths = segs
            motion = "none"
            transition = "none"  # hard cuts between color sections
            if captions is not None:
                captions = {"preset": "explainer"}
        # --- transition overlap: extend inputs so xfades land centered on cues ---
        T = 0.0
        if transition in TRANSITIONS and n > 1:
            T = min(0.5, min(durs) * 0.49)
            if T < 0.05:
                transition = "none"
                T = 0.0
        if T > 0:
            in_durs = [durs[0] + T / 2] + [d + T for d in durs[1:-1]] + [durs[-1] + T / 2]
        else:
            in_durs = list(durs)

        cmd = ["ffmpeg", "-y"]
        for img, d in zip(image_paths, in_durs):
            ext = os.path.splitext(img)[1].lower()
            if ext in VIDEO_EXTS:
                cmd += ["-stream_loop", "-1", "-t", f"{d:.3f}", "-i", img]
            else:
                cmd += ["-loop", "1", "-framerate", str(fps), "-t", f"{d:.3f}", "-i", img]
        cmd += ["-i", audio_path]

        # --- auto sound effects at each transition cut (+ v2.15 extra events) ---
        sfx_path = None
        if (sfx_on and T > 0) or sfx_extra:
            sfx_path = build_sfx_track(transition, bounds, T,
                                       out_path + ".sfx.wav",
                                       gain=max(0.0, min(1.0, sfx_vol)),
                                       kind=sfx_kind,
                                       extra_events=sfx_extra)
        if sfx_path:
            cmd += ["-i", sfx_path]
            sfx_idx = n + 1

        # --- per-segment video chain ---
        filters = []
        for i, img in enumerate(image_paths):
            ext = os.path.splitext(img)[1].lower()
            is_video = ext in VIDEO_EXTS
            if not is_video and motion in MOTIONS:
                tf = max(1, round(in_durs[i] * fps))
                chain = _motion_filter(motion, tf, W, H, fps)
            elif is_video:
                chain = (f"scale={W}:{H}:force_original_aspect_ratio=decrease,"
                         f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps},"
                         f"trim=duration={in_durs[i]:.3f},setpts=PTS-STARTPTS")
            else:
                chain = (f"scale={W}:{H}:force_original_aspect_ratio=decrease,"
                         f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps}")
            filters.append(f"[{i}:v]{chain}[v{i}]")

        # --- join segments: xfade chain or plain concat ---
        if T > 0:
            cur = "[v0]"
            offset = in_durs[0] - T
            for i in range(1, n):
                out = f"[x{i}]"
                filters.append(
                    f"{cur}[v{i}]xfade=transition={transition}:"
                    f"duration={T:.3f}:offset={offset:.3f}{out}")
                cur = out
                offset += in_durs[i] - T
            vmix = cur
        else:
            filters.append("".join(f"[v{i}]" for i in range(n)) + f"concat=n={n}:v=1:a=0[vmix]")
            vmix = "[vmix]"

        # --- whole-video effect ---
        veff = vmix
        eff = _effect_filter(effect, W, H)
        if eff:
            # rgbsplit internally consumes/produces multiple streams; handle labels
            if effect == "rgbsplit":
                # rewrite: feed vmix into the split recipe, output [veff]
                filters.append(f"{vmix}split=3[rs][gs][bs];"
                               f"[rs]pad=iw+8:ih:8:0,crop=iw-8:ih:0:0,format=gbrp[rr];"
                               f"[gs]format=gbrp[gg];"
                               f"[bs]pad=iw+8:ih:0:0,crop=iw-8:ih:8:0,format=gbrp[bb];"
                               f"[rr][gg][bb]mergeplanes=0x001020:gbrp,format=yuv420p[veff]")
            else:
                filters.append(f"{vmix}{eff}[veff]")
            veff = "[veff]"

        # --- captions (ASS burn-in) + v2.15 B-roll overlays ---
        vout = veff
        adj = adjustments_filter(adjustments) if adjustments else ""
        if color_filter:
            adj = (color_filter + "," + adj) if adj else color_filter
        if adj:
            filters.append(f"{veff}{adj}[vadj]")
            vout = "[vadj]"
        need_ass = bool((captions and words) or ass_extra)
        if need_ass:
            segments = [(bounds[i], bounds[i + 1]) for i in range(n)]
            ass_path = out_path + ".ass"
            if captions and words:
                build_ass_file(words, segments, captions, W, H, ass_path,
                               extra_events=ass_extra)
            else:
                # captions off but B-roll text on: overlay-only ASS
                build_ass_file([], segments, {"preset": "pop"}, W, H,
                               ass_path, extra_events=ass_extra)
            esc = ass_path.replace("\\", "/").replace(":", "\\:")
            vsrc = vout
            vout = "[vout]"
            filters.append(f"{vsrc}subtitles='{esc}'{vout}")

        if sfx_path:
            filters.append(f"[{n}:a][{sfx_idx}:a]"
                           f"amix=inputs=2:duration=first:dropout_transition=0[aout]")
            amap = ["-map", "[aout]"]
        else:
            amap = ["-map", f"{n}:a"]

        cmd += ["-filter_complex", ";".join(filters),
                "-map", vout] + amap + [
                "-c:v", "libx264", "-preset", x264_preset, "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", "160k", "-shortest", out_path]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("ffmpeg failed: " + r.stderr[-1500:])
        return {"durations": [round(d, 2) for d in durs], "path": out_path}
    finally:
        if _draw_tmp:
            import shutil
            shutil.rmtree(_draw_tmp, ignore_errors=True)


INTRO_ASSET = os.path.join(_ASSETS_DIR, "intro-azstudio.mp4")


def intro_duration():
    """Duration of the bundled silent AZ Studio intro, or 0 if missing."""
    if not os.path.exists(INTRO_ASSET):
        return 0.0
    try:
        r = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries",
             "format=duration", "-of", "csv=p=0", INTRO_ASSET],
            capture_output=True, text=True)
        return max(0.0, float((r.stdout or "0").strip() or 0))
    except Exception:
        return 0.0


def prepend_intro(main_path, width, height, fps=30):
    """Prepend the silent AZ Studio intro to a finished video.

    Returns the intro duration prepended (0 on failure/missing asset).
    The main video (with its in-sync narration) is untouched; the intro
    is silent, letterboxed to WxH, and concatenated in front.
    """
    if not os.path.exists(INTRO_ASSET):
        return 0.0
    dur = intro_duration()
    if dur <= 0:
        return 0.0
    tmp = main_path + ".intro.mp4"
    vf = (f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
          f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps},"
          f"format=yuv420p")
    cmd = ["ffmpeg", "-y", "-v", "error",
           "-i", INTRO_ASSET, "-i", main_path,
           "-filter_complex",
           f"[0:v]{vf}[v0];"
           f"anullsrc=r=44100:cl=stereo:d={dur:.2f}[a0];"
           f"[v0][a0][1:v][1:a]concat=n=2:v=1:a=1[v][a]",
           "-map", "[v]", "-map", "[a]",
           "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "160k", "-shortest", tmp]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(tmp):
        return 0.0
    os.replace(tmp, main_path)
    return round(dur, 2)


# ----------------------------------------------------------------------------
# Kinetic title cards (doodle-video style): solid background + big bold words
# appearing one by one, each active word highlighted.
# ----------------------------------------------------------------------------

TITLECARD_THEMES = {
    "black-yellow": {"label": "Black + Yellow highlight",
                     "bg": "#0B0B0B", "fg": "#FFFFFF",
                     "hl": "#FFD500", "hl_text": "#000000"},
    "red-black": {"label": "Red + Black highlight",
                  "bg": "#C8102E", "fg": "#FFFFFF",
                  "hl": "#111111", "hl_text": "#FFFFFF"},
    "blue-white": {"label": "Blue + White highlight",
                   "bg": "#1E5AA8", "fg": "#FFFFFF",
                   "hl": "#FFFFFF", "hl_text": "#1E5AA8"},
    "yellow-pink": {"label": "Yellow + Pink highlight",
                    "bg": "#FFD500", "fg": "#111111",
                    "hl": "#FF2E88", "hl_text": "#FFFFFF"},
}


def make_title_card(text, out_path, duration=5.0, width=1280, height=720,
                    theme="black-yellow", font="Montserrat", fps=30):
    """Render a kinetic-typography title card to MP4.

    Solid `theme` background; words pop in one by one with the active
    word highlighted (thick highlight outline). Returns out_path.
    """
    words = (text or "").split()
    if not words:
        raise CueError("Please write the card text first.")
    th = TITLECARD_THEMES.get(theme) or TITLECARD_THEMES["black-yellow"]
    duration = max(1.0, min(30.0, float(duration)))
    W, H = int(width), int(height)
    n = len(words)
    step = duration / n
    size = max(48, int(96 * W / 1280))
    fg, hl, hl_t = (_hex_to_ass(th["fg"]), _hex_to_ass(th["hl"]),
                    _hex_to_ass(th["hl_text"]))
    bg_ass = _hex_to_ass(th["bg"])
    # wrap into lines of ~5 words for the big look
    lines, cur = [], []
    for w in words:
        cur.append(w)
        if len(cur) >= 5:
            lines.append(cur)
            cur = []
    if cur:
        lines.append(cur)

    def render(upto):
        """Render all words up to index `upto` (active = highlighted)."""
        out_lines = []
        idx = 0
        for ln in lines:
            parts = []
            for w in ln:
                if idx < upto:
                    parts.append(
                        r"{\1c%s\3c%s\b1}" % (fg, bg_ass) + w)
                elif idx == upto:
                    parts.append(
                        r"{\1c%s\3c%s\bord10\b1}" % (hl_t, hl) + w)
                idx += 1
            out_lines.append(" ".join(parts))
        return r"\N".join(out_lines)

    L = ["[Script Info]", "ScriptType: v4.00+",
         f"PlayResX: {W}", f"PlayResY: {H}", "WrapStyle: 0",
         "[V4+ Styles]",
         "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, "
         "OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, "
         "ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
         "Alignment, MarginL, MarginR, MarginV, Encoding",
         f"Style: Card,{font},{size},{fg},{fg},{bg_ass},"
         f"&H00000000,-1,0,0,0,100,100,0,0,1,2,0,5,20,20,24,1",
         "[Events]",
         "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, "
         "Effect, Text"]
    for j in range(n):
        t0 = j * step
        t1 = (j + 1) * step if j < n - 1 else duration
        L.append(f"Dialogue: 0,{_ass_time(t0)},{_ass_time(t1)},"
                 f"Card,,0,0,0,,{render(j)}")
    ass_path = out_path + ".ass"
    with open(ass_path, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    bg_hex = th["bg"].lstrip("#")
    esc = ass_path.replace("\\", "/").replace(":", "\\:")
    cmd = ["ffmpeg", "-y", "-f", "lavfi", "-i",
           f"color=c=0x{bg_hex}:s={W}x{H}:d={duration:.2f}:r={fps}",
           "-vf", f"subtitles='{esc}'",
           "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
           "-t", f"{duration:.2f}", out_path]
    r = subprocess.run(cmd, capture_output=True, text=True)
    try:
        os.remove(ass_path)
    except OSError:
        pass
    if r.returncode != 0:
        raise RuntimeError("Title card render failed: " + r.stderr[-1200:])
    return out_path


# ----------------------------------------------------------------------------
# Phase 1 tools: Caption Generator (burn-in) + AI Clipper (9:16 auto-reframe)
# ----------------------------------------------------------------------------

def _video_dims(path):
    """Return (width, height). Prefers OpenCV; falls back to ffprobe."""
    try:
        import cv2
    except ImportError:
        cv2 = None
    if cv2 is not None:
        cap = cv2.VideoCapture(path)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        cap.release()
        if w > 0 and h > 0:
            return w, h
    # fallback: ffprobe (ships with every ffmpeg install)
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height", "-of", "csv=p=0", path],
        capture_output=True, text=True)
    try:
        w, h = (int(x) for x in r.stdout.strip().split(","))
    except (ValueError, TypeError):
        raise CueError("Could not read the video size — the file looks broken.")
    if w <= 0 or h <= 0:
        raise CueError("Could not read the video — the file looks broken.")
    return w, h


def _aspect_target(W, H, aspect):
    """Center-crop dims for an export aspect ratio.

    Returns (TW, TH, pre_filter). Only crops (never pads); when the source
    already fits, returns the source dims with no filter.
    """
    def even(x):
        return max(2, (int(x) // 2) * 2)
    if aspect == "9:16":
        tw = even(H * 9 / 16)
        if tw >= W:
            return W, H, ""
        return tw, H, f"crop={tw}:{H},"
    if aspect == "1:1":
        if W == H:
            return W, H, ""
        s = even(min(W, H))
        return s, s, f"crop={s}:{s},"
    if aspect == "16:9":
        th = even(W * 9 / 16)
        if th >= H:
            return W, H, ""
        return W, th, f"crop={W}:{th},"
    return W, H, ""


def burn_captions(video_path, out_path, opts, words=None, model=None, language="", groq_key=None):
    """Transcribe the video's audio and burn styled captions into a new MP4.

    opts: preset id + tweaks (see resolve_caption_opts).
    words: pre-transcribed word list (skips transcription); each word's
      start/end are relative to video_path.
    model: transcription model ('tiny'/'base'/'small') when transcribing.
    language: detected language code; auto-detected when transcribing.
    """
    if words is None:
        tr = transcribe(video_path, model=model, groq_key=groq_key)
        words = tr["words"]
        language = tr.get("language", "")
    if not words:
        raise CueError("No speech found in the audio — cannot make captions.")
    # v2.20: auto-switch font for non-Latin scripts (Urdu/Hindi/Chinese/etc.)
    full_text = "".join(w.get("word", "") for w in words)
    script_font = detect_script_font(full_text)
    if script_font:
        opts = dict(opts or {})
        opts["font"] = script_font
    # chunk words into caption segments (~4s each)
    segments, cue3, cur = [], [], [words[0]]

    def _flush():
        s0, s1 = cur[0]["start"], cur[-1]["end"]
        txt = "".join(x["word"] for x in cur).strip()
        segments.append((s0, s1))
        cue3.append([round(s0, 2), round(s1, 2), txt])

    for w in words[1:]:
        if (w["start"] - cur[0]["start"] > 4.0
                or w["word"].strip().endswith((".", "!", "?", "…"))):
            _flush()
            cur = [w]
        else:
            cur.append(w)
    if cur:
        _flush()
    W, H = _video_dims(video_path)
    o = opts or {}
    TW, TH, pre = _aspect_target(W, H, o.get("aspect", "source"))
    ass_path = out_path + ".ass"
    build_ass_file(words, segments, opts, TW, TH, ass_path)
    esc = ass_path.replace("\\", "/").replace(":", "\\:")
    vf = pre + f"subtitles='{esc}'"
    if o.get("fps") in (24, 30, 60):
        vf += f",fps={o['fps']}"
    cmd = ["ffmpeg", "-y", "-i", video_path, "-vf", vf,
           "-c:v", "libx264", "-preset", "medium", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-movflags", "+faststart", out_path]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("ffmpeg failed: " + r.stderr[-1500:])
    return {"path": out_path, "words": len(words), "cues": cue3,
            "language": language, "words_list": words}


def _media_duration(path):
    """Media duration in seconds, parsed from ffmpeg stderr."""
    r = subprocess.run(["ffmpeg", "-i", path], capture_output=True, text=True)
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", r.stderr)
    if not m:
        return 0.0
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))


def find_engaging_clips(video_path, n_clips=3, clip_dur=30.0, min_gap=5.0):
    """Find the most engaging moments of a video, any language.

    Scores 0.5s windows by audio RMS energy (loud = exciting: shouting,
    laughter, music peaks), smooths it, and greedily picks the top
    non-overlapping clip windows. Language-independent — it never looks
    at words. Returns [(start, end), ...] in seconds.
    """
    audio = decode_audio(video_path)
    sr = 16000
    win = int(0.5 * sr)
    n = len(audio) // win
    dur = len(audio) / sr
    if n < 4 or dur <= 0:
        raise CueError("Video is too short for auto clips.")
    rms = np.sqrt(np.mean(audio[:n * win].reshape(n, win) ** 2, axis=1) + 1e-9)
    k = 6  # ~3s smoothing
    smooth = np.convolve(rms, np.ones(k) / k, mode="same")
    cw = max(2, int(clip_dur / 0.5))
    gapw = max(1, int(min_gap / 0.5))
    used = np.zeros(n, dtype=bool)
    picks = []
    for _ in range(max(1, n_clips)):
        best, best_i = -1.0, None
        for i in range(0, max(1, n - cw)):
            if used[i:i + cw].any():
                continue
            sc = float(smooth[i:i + cw].mean())
            if sc > best:
                best, best_i = sc, i
        if best_i is None or best <= 1e-6:
            break
        picks.append(best_i * 0.5)
        used[max(0, best_i - gapw):min(n, best_i + cw + gapw)] = True
    picks.sort()
    if not picks:
        # flat/silent audio: spread clips evenly
        step = (dur - clip_dur) / max(1, n_clips)
        picks = [max(0.0, min(i * step, dur - clip_dur)) for i in range(n_clips)]
    return [(round(s, 2), round(min(s + clip_dur, dur), 2)) for s in picks]


def make_auto_clips(video_path, out_dir, n_clips=3, clip_dur=30.0,
                    cam="face", captions=None, model=None, groq_key=None):
    """Cut the N most engaging clips, reframe to 9:16, burn captions.

    captions: caption opts dict (resolve_caption_opts) or None.
    Returns list of mp4 paths.
    """
    segs = find_engaging_clips(video_path, n_clips, clip_dur)
    words = None
    if captions is not None:
        words = transcribe(video_path, model=model, groq_key=groq_key)["words"]
    paths = []
    for i, (s, e) in enumerate(segs, 1):
        seg = os.path.join(out_dir, f"seg{i}.mp4")
        r = subprocess.run(
            ["ffmpeg", "-y", "-ss", str(s), "-t", str(round(e - s, 2)),
             "-i", video_path, "-c", "copy", seg],
            capture_output=True, text=True)
        if r.returncode != 0 or not os.path.exists(seg):
            raise RuntimeError("ffmpeg trim failed: " + r.stderr[-800:])
        vert = os.path.join(out_dir, f"clip{i}.mp4")
        reframe_916(seg, vert, track_faces=(cam == "face"))
        try:
            os.remove(seg)
        except OSError:
            pass
        if captions is not None and words:
            wseg = [dict(w, start=max(0.0, w["start"] - s), end=max(0.0, w["end"] - s))
                    for w in words if s - 0.05 <= w["start"] < e]
            tmp = vert + ".cap.mp4"
            burn_captions(vert, tmp, captions, words=wseg)
            os.replace(tmp, vert)
        paths.append(vert)
    return paths


def preview_caption_clip(video_path, out_path, opts, model=None, preview_dur=5.0, groq_key=None):
    """Render a short (middle 5s) sample of the video with captions burned.

    Real WYSIWYG preview for the Caption Generator: same renderer, tiny
    audio slice, fast model. Returns burn_captions info dict.
    """
    dur = _media_duration(video_path)
    start = max(0.0, (dur - preview_dur) / 2) if dur > preview_dur else 0.0
    clip = out_path + ".pv.mp4"
    r = subprocess.run(
        ["ffmpeg", "-y", "-ss", str(round(start, 2)), "-t", str(preview_dur),
         "-i", video_path, "-c:v", "libx264", "-preset", "veryfast",
         "-pix_fmt", "yuv420p", "-c:a", "aac", clip],
        capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("ffmpeg preview trim failed: " + r.stderr[-800:])
    try:
        info = burn_captions(clip, out_path, opts, model=model, groq_key=groq_key)
    finally:
        try:
            os.remove(clip)
        except OSError:
            pass
    return info


def preview_studio_clip(audio_path, image_path, out_path, opts, words,
                        preview_dur=5.0):
    """Render a 5s studio sample (first image + first 5s of audio) with
    captions burned. Real WYSIWYG preview for Studio captions."""
    wseg = [w for w in words if w["start"] < preview_dur]
    build_video(audio_path, [image_path], [0.0], out_path,
                total_duration=preview_dur, width=1280, height=720,
                captions=opts, words=wseg, sfx_on=False)
    return out_path


def reframe_916(in_path, out_path, track_faces=True):
    """Auto-reframe a landscape video to 9:16 vertical (Shorts/Reels).

    Faces are detected with OpenCV and the crop window is centered on the
    median face position, so the speaker stays framed (track_faces=True).
    With track_faces=False a plain center crop is used. Falls back to a
    center crop when no faces are found. Already-vertical videos pass
    through (re-encoded).
    """
    W, H = _video_dims(in_path)
    crop_w = int(H * 9 / 16)
    crop_w -= crop_w % 2  # even width for yuv420p
    faces_found = 0
    if crop_w >= W or W <= H:
        filt = "scale=trunc(iw/2)*2:trunc(ih/2)*2"
    else:
        if track_faces:
            try:
                import cv2
            except ImportError:
                raise CueError(
                    "OpenCV is not installed (needed for face detection). "
                    "Please run install.bat again to install the new libraries.")
            # v2.20: DYNAMIC face tracking — video ko 8s segments mein baanto,
            # har segment mein main speaker dhoondo, crop window uske peeche chale
            cap = cv2.VideoCapture(in_path)
            fps = cap.get(cv2.CAP_PROP_FPS) or 30
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
            duration = total_frames / fps if fps and total_frames else 0
            cascade = cv2.CascadeClassifier(
                cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
            seg_len = 8.0  # seconds per tracking segment
            n_segs = max(1, int(duration / seg_len) + 1)
            seg_cx = []
            for si in range(n_segs):
                t0 = si * seg_len
                cap.set(cv2.CAP_PROP_POS_MSEC, (t0 + seg_len / 2) * 1000)
                ret, frame = cap.read()
                if not ret:
                    seg_cx.append(W / 2)
                    continue
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                scale = 1.0
                if W > 640:
                    scale = W / 640.0
                    gray = cv2.resize(gray, (640, int(H / scale)))
                faces = cascade.detectMultiScale(gray, 1.2, 4)
                if len(faces):
                    # sab se BARA chehra = main speaker
                    x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])
                    cx = (x + fw / 2) * scale
                    seg_cx.append(cx)
                    faces_found += 1
                else:
                    seg_cx.append(W / 2)
            cap.release()
            # smooth: sudden jumps se bacho (moving average)
            smooth = []
            for i, cx in enumerate(seg_cx):
                lo = max(0, i - 1)
                hi = min(len(seg_cx), i + 2)
                smooth.append(sum(seg_cx[lo:hi]) / (hi - lo))
            # ffmpeg crop with time-based x: har segment ka apna x0
            x_exprs = []
            for i, cx in enumerate(smooth):
                x0 = int(min(max(cx - crop_w / 2, 0), W - crop_w))
                x0 -= x0 % 2
                t0 = i * seg_len
                x_exprs.append((t0, x0))
            # build nested if() expression: if(lt(t,8),x0,if(lt(t,16),x1,x2))
            expr = str(x_exprs[-1][1])
            for i in range(len(x_exprs) - 2, -1, -1):
                t_next = x_exprs[i + 1][0]
                x_cur = x_exprs[i][1]
                expr = f"if(lt(t,{t_next}),{x_cur},{expr})"
            filt = f"crop={crop_w}:{H}:x='{expr}':y=0"
        else:
            cx = W / 2  # plain centered crop
            x0 = int(min(max(cx - crop_w / 2, 0), W - crop_w))
            x0 -= x0 % 2
            filt = f"crop={crop_w}:{H}:{x0}:0"
    cmd = ["ffmpeg", "-y", "-i", in_path, "-vf", filt,
           "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-movflags", "+faststart", out_path]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("ffmpeg failed: " + r.stderr[-1500:])
    return {"path": out_path, "faces": faces_found}


# ----------------------------------------------------------------------------
# Auto Doodle Video: voiceover -> scenes -> keywords -> visuals
# ----------------------------------------------------------------------------

DOODLE_PROMPT_SUFFIX = (
    "hand-drawn doodle style, clean black line art on plain white background, "
    "simple minimal icon illustration, no shading, no text")

_STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "if", "then", "else", "when",
    "while", "of", "at", "by", "for", "with", "about", "into", "through",
    "during", "before", "after", "above", "below", "to", "from", "up",
    "down", "in", "out", "on", "off", "over", "under", "again", "further",
    "once", "here", "there", "all", "any", "both", "each", "few", "more",
    "most", "other", "some", "such", "no", "nor", "not", "only", "own",
    "same", "so", "than", "too", "very", "can", "will", "just", "don",
    "should", "now", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "having", "do", "does", "did", "doing", "would",
    "could", "ought", "i", "you", "he", "she", "it", "we", "they", "them",
    "his", "her", "its", "our", "their", "this", "that", "these", "those",
    "am", "as", "my", "me", "him", "us", "what", "which", "who", "whom",
    "why", "how", "where", "whether", "because", "until", "against",
    "between", "really", "quite", "also", "much", "many", "get", "got",
    "make", "made", "take", "took", "come", "came", "go", "went", "see",
    "saw", "know", "knew", "think", "thought", "say", "said", "like",
    "want", "need", "one", "two", "three", "first", "last", "new", "old",
    "big", "small", "great", "good", "well", "every", "today", "time",
    "times", "people", "person", "thing", "things", "something", "nothing",
    "everything", "way", "ways", "part", "kind", "sort", "lot", "lots",
    "bit", "may", "might", "must", "shall", "let", "lets", "us",
}


def split_scenes(words, n_scenes):
    """Split transcribed words into n scenes (sentence-aware, balanced).

    Returns [{text, start, end}] with word-level timings.
    """
    sents, cur = [], []
    for w in words:
        cur.append(w)
        if re.search(r"[.!?\u2026:;]$", w["word"].strip()):
            sents.append(cur)
            cur = []
    if cur:
        sents.append(cur)
    if not sents:
        sents = [words]
    n = max(1, min(int(n_scenes or 8), len(sents)))
    total = sum(len(s) for s in sents)
    target = total / n
    groups, g = [], []
    for s in sents:
        g.append(s)
        if len(groups) < n - 1 and sum(len(x) for x in g) >= target * (len(groups) + 1):
            groups.append(g)
            g = []
    if g:
        groups.append(g)
    while len(groups) < n:
        i = max(range(len(groups)),
                key=lambda k: sum(len(s) for s in groups[k]))
        flat = [w for s in groups[i] for w in s]
        half = len(flat) // 2
        if half == 0:
            break
        groups[i:i + 1] = [[flat[:half]], [flat[half:]]]
    scenes = []
    for grp in groups[:n]:
        ws = [w for s in grp for w in s]
        scenes.append({
            "text": " ".join(w["word"] for w in ws).strip(),
            "start": ws[0]["start"],
            "end": ws[-1]["end"],
        })
    return scenes


def extract_keywords(text, top_k=3):
    """Heuristic keywords: frequent non-stopwords, longer preferred."""
    toks = re.findall(r"[A-Za-z']+", (text or "").lower())
    freq = {}
    for t in toks:
        t = t.strip("'")
        if len(t) < 4 or t in _STOPWORDS:
            continue
        freq[t] = freq.get(t, 0) + 1
    ranked = sorted(freq, key=lambda t: (freq[t], len(t)), reverse=True)
    return ranked[:max(1, top_k)]
