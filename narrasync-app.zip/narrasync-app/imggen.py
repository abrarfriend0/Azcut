"""Gemini AI image generation for Az Cut (bulk storyboard images).

Uses the official Gemini API (generateContent with responseModalities
["TEXT","IMAGE"]). Needs a free API key from Google AI Studio
(https://aistudio.google.com/apikey). Stdlib only — no new dependency.
"""

import base64
import json
import os
import re
import time
import urllib.error
import urllib.request

IMGGEN_MODELS = {
    "gemini-2.5-flash-image": "Fast (Nano Banana)",
    "gemini-3-pro-image-preview": "Pro quality (slower)",
}

IMGGEN_ASPECTS = {
    "16:9": "16:9",
    "9:16": "9:16",
    "1:1": "1:1",
    "4:5": "4:5",
}


class ImgGenError(Exception):
    pass


def generate_image(api_key, prompt, aspect="16:9",
                   model="gemini-2.5-flash-image", timeout=180):
    """Generate one image; return PNG bytes. Raises ImgGenError."""
    api_key = (api_key or "").strip()
    if not api_key:
        raise ImgGenError(
            "Please paste your Gemini API key first. "
            "Get a free one from Google AI Studio.")
    if model not in IMGGEN_MODELS:
        model = "gemini-2.5-flash-image"
    ar = IMGGEN_ASPECTS.get(aspect, "16:9")
    url = ("https://generativelanguage.googleapis.com/v1beta/models/"
           f"{model}:generateContent")
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseModalities": ["TEXT", "IMAGE"],
            "imageConfig": {"aspectRatio": ar},
        },
    }
    req = urllib.request.Request(
        url, data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json",
                 "x-goog-api-key": api_key},
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8")) \
                .get("error", {}).get("message", e.reason)
        except Exception:  # noqa: BLE001
            msg = e.reason
        if e.code in (400, 401, 403):
            msg += " (check that your API key is correct)"
        elif e.code == 429:
            msg += " (free quota used up — try again later)"
        raise ImgGenError(f"Gemini API error ({e.code}): {msg}")
    except ImgGenError:
        raise
    except Exception as e:  # noqa: BLE001
        raise ImgGenError(f"Could not reach Gemini API: {e}")
    parts = data.get("candidates", [{}])[0] \
        .get("content", {}).get("parts", [])
    for part in parts:
        inline = part.get("inlineData") or part.get("inline_data")
        if inline and inline.get("data"):
            return base64.b64decode(inline["data"])
    texts = " ".join(p.get("text", "") for p in parts if p.get("text"))[:200]
    raise ImgGenError(
        "Gemini did not return an image. " + texts)


def parse_bulk_prompts(text):
    """Parse storyboard prompts, one per line.

    Lines starting with '#' may carry a timecode, like the Flow bulk
    generator format: '#0-00 Ethan sitting in cafe...' ->
    ('0-00', 'Ethan sitting in cafe...'). Plain lines are prompts without
    timecodes. Returns [(tag, prompt), ...].
    """
    out = []
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        tag = ""
        if line.startswith("#"):
            line = line[1:].strip()
            bits = line.split(None, 1)
            if len(bits) == 2 and any(c.isdigit() for c in bits[0]):
                tag, line = bits[0], bits[1].strip()
        # strip parenthetical timecodes like "(1:03)" at the start
        line = re.sub(r"^\(\s*[\d:\-]+\s*\)\s*", "", line)
        if line:
            out.append((tag, line))
    if not out:
        raise ImgGenError("Please write at least one image prompt.")
    return out


def bulk_generate(api_key, prompts, out_dir, aspect="16:9",
                  model="gemini-2.5-flash-image", progress=None):
    """Generate images one by one into out_dir as 01.png, 02.png, ...

    prompts: [(tag, prompt), ...]. progress(i, total) is called before
    each image. A single failed image is skipped (recorded in `failed`)
    so one bad prompt never kills a long run; a 429 quota error stops
    the run gracefully. Returns (paths, failed) where failed is
    [(number, error), ...].
    """
    paths, failed = [], []
    for i, (_tag, prompt) in enumerate(prompts, 1):
        if progress:
            progress(i, len(prompts))
        try:
            img = generate_image(api_key, prompt, aspect=aspect, model=model)
        except ImgGenError as e:
            failed.append((i, str(e)))
            if "(429)" in str(e):
                break  # free quota exhausted — no point continuing
            continue
        p = os.path.join(out_dir, f"{i:02d}.png")
        with open(p, "wb") as f:
            f.write(img)
        paths.append(p)
        time.sleep(1)  # be polite to the free tier
    if not paths:
        raise ImgGenError(failed[0][1] if failed else
                          "No images were generated.")
    return paths, failed


# 15 graphic styles for AI-generated video visuals (v1.9).
# id -> (label, prompt suffix appended to the scene keyword)
IMAGE_STYLES = {
    "hand_doodle": (
        "Cinematic Hand-Drawn Doodle",
        "cinematic hand-drawn doodle, thick outlines, textured shading, "
        "storybook atmosphere, documentary feel, no text"),
    "ink_sketch": (
        "Bold Ink Sketch",
        "bold ink sketch animation style, expressive black ink lines, "
        "rough organic strokes, minimal earthy colors, no text"),
    "comic_2d": (
        "2D Educational Comic",
        "2D educational comic style, clean bold outlines, flat colors, "
        "simplified characters, highly readable visuals, no text"),
    "watercolor": (
        "Storybook Watercolor",
        "storybook watercolor doodle, hand-drawn figures with soft "
        "watercolor backgrounds and atmospheric depth, no text"),
    "cave_art": (
        "Vintage Cave-Art",
        "vintage cave-art illustration, primitive visual language, rock "
        "textures, earthy pigments, prehistoric atmosphere, no text"),
    "dark_survival": (
        "Dark Survival Doodle",
        "dark survival doodle, muted colors, dramatic shadows, intense "
        "composition, danger-focused storytelling, no text"),
    "stick_figure": (
        "Minimalist Stick-Figure",
        "minimalist stick-figure documentary style, extremely simple "
        "characters with cinematic environments, strong visual "
        "storytelling, no text"),
    "graphic_novel": (
        "Graphic Novel Ink",
        "graphic novel ink style, bold black outlines, dramatic framing, "
        "textured backgrounds, strong contrast, no text"),
    "paper_cutout": (
        "Paper Cutout 2D",
        "paper cutout 2D animation style, layered paper-like shapes, "
        "simple characters, handcrafted depth, no text"),
    "flat_vector": (
        "Flat Vector Comic",
        "flat vector documentary comic, geometric shapes, consistent "
        "outlines, clean colors, modern educational appearance, no text"),
    "chalkboard": (
        "Chalkboard Illustration",
        "chalkboard illustration style, chalk-like strokes on dark "
        "background, simple diagrams and characters, no text"),
    "colored_pencil": (
        "Colored Pencil Storybook",
        "colored pencil storybook style, visible pencil texture, warm "
        "natural colors, hand-drawn children's-book aesthetic, no text"),
    "woodcut": (
        "Woodcut Engraving",
        "woodcut engraving animation style, historical carved-line "
        "appearance, dense black linework, ancient documentary mood, "
        "no text"),
    "gouache": (
        "Gouache Adventure",
        "gouache adventure illustration, bold painted shapes, slightly "
        "textured surfaces, cinematic landscapes, no text"),
    "sketch_wash": (
        "Sketch + Color Wash",
        "cinematic sketch with color wash, detailed black sketch lines "
        "combined with selective earthy color washes, dramatic "
        "documentary feel, no text"),
}
