"""Gemini AI image generation for Az Cut (bulk storyboard images).

Uses the official Gemini API (generateContent with responseModalities
["TEXT","IMAGE"]). Needs a free API key from Google AI Studio
(https://aistudio.google.com/apikey). Stdlib only — no new dependency.
"""

import base64
import json
import time
import urllib.error
import urllib.request

IMGGEN_MODELS = {
    "gemini-2.5-flash-image": "Fast (Nano Banana)",
    "gemini-3-pro-image-preview": "Pro quality (slower)",
}

IMGGEN_ASPECTS = {
    "16:9": "16:9",
    "9:16": "9:16",
    "1:1": "1:1",
    "4:5": "4:5",
}

MAX_PROMPTS = 20


class ImgGenError(Exception):
    pass


def generate_image(api_key, prompt, aspect="16:9",
                   model="gemini-2.5-flash-image", timeout=180):
    """Generate one image; return PNG bytes. Raises ImgGenError."""
    api_key = (api_key or "").strip()
    if not api_key:
        raise ImgGenError(
            "Please paste your Gemini API key first. "
            "Get a free one from Google AI Studio.")
    if model not in IMGGEN_MODELS:
        model = "gemini-2.5-flash-image"
    ar = IMGGEN_ASPECTS.get(aspect, "16:9")
    url = ("https://generativelanguage.googleapis.com/v1beta/models/"
           f"{model}:generateContent")
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseModalities": ["TEXT", "IMAGE"],
            "imageConfig": {"aspectRatio": ar},
        },
    }
    req = urllib.request.Request(
        url, data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json",
                 "x-goog-api-key": api_key},
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8")) \
                .get("error", {}).get("message", e.reason)
        except Exception:  # noqa: BLE001
            msg = e.reason
        if e.code in (400, 401, 403):
            msg += " (check that your API key is correct)"
        elif e.code == 429:
            msg += " (free quota used up — try again later)"
        raise ImgGenError(f"Gemini API error ({e.code}): {msg}")
    except ImgGenError:
        raise
    except Exception as e:  # noqa: BLE001
        raise ImgGenError(f"Could not reach Gemini API: {e}")
    parts = data.get("candidates", [{}])[0] \
        .get("content", {}).get("parts", [])
    for part in parts:
        inline = part.get("inlineData") or part.get("inline_data")
        if inline and inline.get("data"):
            return base64.b64decode(inline["data"])
    texts = " ".join(p.get("text", "") for p in parts if p.get("text"))[:200]
    raise ImgGenError(
        "Gemini did not return an image. " + texts)


def parse_bulk_prompts(text):
    """Parse storyboard prompts, one per line.

    Lines starting with '#' may carry a timecode, like the Flow bulk
    generator format: '#0-00 Ethan sitting in cafe...' ->
    ('0-00', 'Ethan sitting in cafe...'). Plain lines are prompts without
    timecodes. Returns [(tag, prompt), ...].
    """
    out = []
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        tag = ""
        if line.startswith("#"):
            line = line[1:].strip()
            bits = line.split(None, 1)
            if len(bits) == 2 and any(c.isdigit() for c in bits[0]):
                tag, line = bits[0], bits[1].strip()
        if line:
            out.append((tag, line))
    if not out:
        raise ImgGenError("Please write at least one image prompt.")
    if len(out) > MAX_PROMPTS:
        raise ImgGenError(
            f"Maximum {MAX_PROMPTS} prompts per batch — split into two runs.")
    return out


def bulk_generate(api_key, prompts, out_dir, aspect="16:9",
                  model="gemini-2.5-flash-image", progress=None):
    """Generate images one by one into out_dir as 01.png, 02.png, ...

    prompts: [(tag, prompt), ...]. progress(i, total) is called before
    each image. Returns [paths].
    """
    import os
    paths = []
    for i, (_tag, prompt) in enumerate(prompts, 1):
        if progress:
            progress(i, len(prompts))
        img = generate_image(api_key, prompt, aspect=aspect, model=model)
        p = os.path.join(out_dir, f"{i:02d}.png")
        with open(p, "wb") as f:
            f.write(img)
        paths.append(p)
        time.sleep(1)  # be polite to the free tier
    return paths
