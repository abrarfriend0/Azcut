"""Smart Explainer video stages for Az Cut v2.18.

Four stages matching the reference style:
  1. icon_canvas: off-white bg, 3D icons with pencil wipe reveal + labels
  2. kinetic: solid color bg, floating circles, words appear with text bars
  3. stock_card: off-white bg, rounded video card for real-world footage
  4. typewriter: text types out with cursor

All stages render via PIL frames -> ffmpeg (same pattern as pencil_draw_clip).
"""
import os
import subprocess
import math
import random

from PIL import Image, ImageDraw, ImageFont

OFFWHITE = (248, 247, 242)
KINETIC_BGS = [
    ("black", (12, 12, 14), (255, 255, 255)),
    ("red", (200, 30, 35), (255, 255, 255)),
    ("blue", (25, 80, 160), (255, 255, 255)),
    ("yellow", (255, 200, 30), (20, 20, 20)),
]
BAR_COLORS = [(255, 200, 30), (240, 140, 156), (20, 20, 20)]


def _font(size, bold=False):
    from pipeline import _ASSETS_DIR
    cands = []
    if bold:
        cands.append(os.path.join(_ASSETS_DIR, "Montserrat-ExtraBold.ttf"))
    cands.append(os.path.join(_ASSETS_DIR, "Montserrat-SemiBold.ttf"))
    cands += ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
              "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
    for p in cands:
        try:
            if os.path.exists(p):
                return ImageFont.truetype(p, size)
        except Exception:
            continue
    return ImageFont.load_default()


def _ffmpeg_writer(out_path, fps, w, h):
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24",
           "-s", f"{w}x{h}", "-framerate", str(fps), "-i", "-",
           "-c:v", "libx264", "-preset", "medium", "-pix_fmt", "yuv420p", out_path]
    return subprocess.Popen(cmd, stdin=subprocess.PIPE)


def icon_canvas_clip(icon_paths, labels, out_path, duration=4.0, fps=30,
                     width=1280, height=720, pill_text=None):
    """Off-white canvas, icons revealed by pencil wipe, label under each."""
    from pipeline import _pencil_image
    W, H = width, height
    bg = Image.new("RGB", (W, H), OFFWHITE)
    pencil, tip = _pencil_image()
    pscale = 0.55
    pw, ph = int(pencil.width * pscale), int(pencil.height * pscale)
    pencil_s = pencil.resize((pw, ph), Image.LANCZOS)

    n = len(icon_paths)
    # grid: up to 3 per row
    per_row = min(3, n)
    rows = (n + per_row - 1) // per_row
    cell_w, cell_h = W // per_row, int(H * 0.72) // max(1, rows)
    icon_size = min(cell_w, cell_h) - 90

    icons = []
    for ip in icon_paths:
        try:
            im = Image.open(ip).convert("RGBA")
            # whiten background: make near-corner-color transparent-ish
            # (simple: paste on white then use as-is)
            bgw = Image.new("RGBA", im.size, (255, 255, 255, 255))
            bgw.paste(im, (0, 0), im)
            im = bgw.convert("RGB")
            im.thumbnail((icon_size, icon_size), Image.LANCZOS)
            icons.append(im)
        except Exception:
            icons.append(None)

    # positions (centered grid)
    positions = []
    for i in range(n):
        r, c = divmod(i, per_row)
        row_n = min(per_row, n - r * per_row)
        x0 = (W - row_n * cell_w) // 2
        cx = x0 + c * cell_w + cell_w // 2
        cy = 90 + r * cell_h + cell_h // 2 - 30
        positions.append((cx, cy))

    draw_time_each = min(1.2, duration / max(1, n) * 0.7)
    proc = _ffmpeg_writer(out_path, fps, W, H)
    try:
        nframes = max(1, int(round(duration * fps)))
        for fi in range(nframes):
            t = fi / fps
            frame = bg.copy()
            dr = ImageDraw.Draw(frame)
            for i, (im, (cx, cy)) in enumerate(zip(icons, positions)):
                if im is None:
                    continue
                iw, ih = im.size
                ix, iy = cx - iw // 2, cy - ih // 2
                start = i * (duration / max(1, n)) * 0.8
                lt = t - start
                if lt <= 0:
                    continue
                if lt < draw_time_each:
                    fx = int(iw * min(1.0, lt / draw_time_each))
                    feather = max(6, iw // 20)
                    mask = Image.new("L", (iw, ih), 0)
                    md = ImageDraw.Draw(mask)
                    md.rectangle([0, 0, max(0, fx - feather), ih], fill=255)
                    for x in range(max(0, fx - feather), fx):
                        a = int(255 * (x - (fx - feather)) / feather)
                        md.line([(x, 0), (x, ih)], fill=a)
                    frame.paste(im, (ix, iy), mask)
                    # pencil at reveal edge
                    px = ix + fx - int(tip[0] * pscale)
                    py = iy + int(ih * 0.44) - int(tip[1] * pscale)
                    frame.paste(pencil_s, (px, py), pencil_s)
                else:
                    frame.paste(im, (ix, iy))
                # label under icon (lowercase bold)
                if i < len(labels) and labels[i]:
                    fnt = _font(30, bold=True)
                    txt = str(labels[i]).lower()
                    try:
                        bb = dr.textbbox((0, 0), txt, font=fnt)
                        tw = bb[2] - bb[0]
                    except Exception:
                        tw = len(txt) * 18
                    dr.text((cx - tw / 2, iy + ih + 12), txt,
                            font=fnt, fill=(60, 60, 60))
            # optional pill label (like "Fundamentally")
            if pill_text and t > 0.5:
                fnt = _font(28, bold=True)
                try:
                    bb = dr.textbbox((0, 0), pill_text, font=fnt)
                    tw, th = bb[2] - bb[0], bb[3] - bb[1]
                except Exception:
                    tw, th = len(pill_text) * 16, 28
                px0, py0 = W - tw - 90, 70
                dr.rounded_rectangle([px0 - 18, py0 - 12, px0 + tw + 18,
                                      py0 + th + 12], radius=22,
                                     fill=(60, 130, 200))
                dr.text((px0, py0), pill_text, font=fnt, fill=(255, 255, 255))
                # pointer line to first icon
                if positions:
                    dr.line([(px0 - 18, py0 + 10), (positions[0][0] + 60,
                             positions[0][1] - 40)], fill=(60, 130, 200), width=3)
            proc.stdin.write(frame.tobytes())
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()
    if not os.path.exists(out_path):
        raise RuntimeError("icon canvas render failed")


def kinetic_clip(words, highlights, out_path, duration=4.0, fps=30,
                 width=1280, height=720, bg_idx=0):
    """Solid bg, floating circles, words appear one by one, bars on highlights."""
    W, H = width, height
    name, bg_col, fg_col = KINETIC_BGS[bg_idx % len(KINETIC_BGS)]
    random.seed(42)
    circles = [(random.randint(0, W), random.randint(0, H),
                random.randint(20, 90)) for _ in range(14)]
    dots = [(random.randint(0, W), random.randint(0, H),
             random.randint(2, 5)) for _ in range(30)]

    # layout words into lines
    fnt = _font(64, bold=True)
    lines, cur, cur_w = [], [], 0
    max_w = W - 160
    tmp = Image.new("RGB", (10, 10))
    td = ImageDraw.Draw(tmp)
    for w in words:
        try:
            ww = td.textbbox((0, 0), w + " ", font=fnt)[2]
        except Exception:
            ww = len(w) * 40
        if cur_w + ww > max_w and cur:
            lines.append(cur)
            cur, cur_w = [], 0
        cur.append(w)
        cur_w += ww
    if cur:
        lines.append(cur)
    line_h = 92
    total_h = len(lines) * line_h
    y0 = (H - total_h) // 2

    per_word = duration / max(1, len(words))
    proc = _ffmpeg_writer(out_path, fps, W, H)
    try:
        nframes = max(1, int(round(duration * fps)))
        for fi in range(nframes):
            t = fi / fps
            frame = Image.new("RGB", (W, H), bg_col)
            dr = ImageDraw.Draw(frame, "RGBA")
            for (cx, cy, r) in circles:
                dr.ellipse([cx - r, cy - r, cx + r, cy + r],
                           outline=(255, 255, 255, 40), width=2)
            for (cx, cy, r) in dots:
                dr.ellipse([cx - r, cy - r, cx + r, cy + r],
                           fill=(255, 255, 255, 50))
            wi = 0
            for li, line in enumerate(lines):
                # measure line width for centering
                lw = 0
                wws = []
                for w in line:
                    try:
                        ww = td.textbbox((0, 0), w + " ", font=fnt)[2]
                    except Exception:
                        ww = len(w) * 40
                    wws.append(ww)
                    lw += ww
                x = (W - lw) / 2
                y = y0 + li * line_h
                for w, ww in zip(line, wws):
                    if t >= wi * per_word:
                        hl = w.lower().strip(".,!?") in highlights
                        if hl:
                            bar_col = BAR_COLORS[0] if name != "yellow" else (20, 20, 20)
                            txt_col = (20, 20, 20) if name != "yellow" else (255, 200, 30)
                            # pop-in scale
                            lt = t - wi * per_word
                            sc = min(1.0, 0.6 + lt * 4)
                            pad = 10
                            dr.rectangle([x - pad, y - 6, x + ww - 20 + pad, y + 68],
                                         fill=bar_col)
                            dr.text((x, y), w, font=fnt, fill=txt_col)
                        else:
                            dr.text((x, y), w, font=fnt, fill=fg_col)
                    x += ww
                    wi += 1
            proc.stdin.write(frame.tobytes())
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()
    if not os.path.exists(out_path):
        raise RuntimeError("kinetic render failed")


def stock_card_clip(video_path, out_path, duration=5.0, fps=30,
                    width=1280, height=720):
    """Off-white bg with rounded video card (for real-world footage)."""
    W, H = width, height
    cw, chh = int(W * 0.72), int(H * 0.68)
    cx, cy = (W - cw) // 2, (H - chh) // 2
    # extract a centered thumbnail strip via ffmpeg, then round corners
    import tempfile
    tmp = tempfile.mktemp(suffix=".mp4")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", video_path,
                    "-t", str(duration), "-vf",
                    f"scale={cw}:{chh}:force_original_aspect_ratio=increase,"
                    f"crop={cw}:{chh},fps={fps}",
                    "-c:v", "libx264", "-preset", "fast", "-pix_fmt", "yuv420p",
                    tmp], check=True)
    # rounded mask
    mask = Image.new("L", (cw, chh), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, cw, chh], radius=36, fill=255)
    # read frames and composite
    cmd = ["ffmpeg", "-v", "error", "-i", tmp, "-f", "rawvideo",
           "-pix_fmt", "rgb24", "-s", f"{cw}x{chh}", "-r", str(fps), "-"]
    proc_in = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    proc_out = _ffmpeg_writer(out_path, fps, W, H)
    try:
        nframes = int(round(duration * fps))
        for _ in range(nframes):
            raw = proc_in.stdout.read(cw * chh * 3)
            if len(raw) < cw * chh * 3:
                break
            card = Image.frombytes("RGB", (cw, chh), raw)
            frame = Image.new("RGB", (W, H), OFFWHITE)
            # drop shadow
            sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            ImageDraw.Draw(sh).rounded_rectangle(
                [cx + 10, cy + 14, cx + cw + 10, cy + chh + 14],
                radius=36, fill=(0, 0, 0, 60))
            frame = Image.alpha_composite(frame.convert("RGBA"), sh).convert("RGB")
            frame.paste(card, (cx, cy), mask)
            ImageDraw.Draw(frame).rounded_rectangle(
                [cx, cy, cx + cw, cy + chh], radius=36,
                outline=(255, 255, 255), width=8)
            proc_out.stdin.write(frame.tobytes())
    finally:
        try:
            proc_out.stdin.close()
        except Exception:
            pass
        proc_out.wait()
        proc_in.wait()
    try:
        os.remove(tmp)
    except Exception:
        pass
    if not os.path.exists(out_path):
        raise RuntimeError("stock card render failed")


def typewriter_clip(text, out_path, duration=4.0, fps=30,
                    width=1280, height=720):
    """Off-white bg, text types out with blinking cursor."""
    W, H = width, height
    fnt = _font(54, bold=True)
    chars = list(text)
    cps = len(chars) / max(0.1, duration - 0.6)  # leave 0.6s hold
    proc = _ffmpeg_writer(out_path, fps, W, H)
    try:
        nframes = max(1, int(round(duration * fps)))
        for fi in range(nframes):
            t = fi / fps
            nch = min(len(chars), int(t * cps))
            shown = "".join(chars[:nch])
            frame = Image.new("RGB", (W, H), OFFWHITE)
            dr = ImageDraw.Draw(frame)
            # wrap
            tmp = Image.new("RGB", (10, 10))
            td = ImageDraw.Draw(tmp)
            words, lines, cur = shown.split(" "), [], ""
            for w in words:
                test = (cur + " " + w).strip()
                try:
                    ww = td.textbbox((0, 0), test, font=fnt)[2]
                except Exception:
                    ww = len(test) * 32
                if ww > W - 200 and cur:
                    lines.append(cur)
                    cur = w
                else:
                    cur = test
            if cur:
                lines.append(cur)
            y = H // 2 - len(lines) * 36
            cursor = "▍" if (fi // 12) % 2 == 0 and nch < len(chars) else ""
            for li, line in enumerate(lines):
                try:
                    bb = td.textbbox((0, 0), line, font=fnt)
                    lw = bb[2] - bb[0]
                except Exception:
                    lw = len(line) * 32
                suffix = cursor if li == len(lines) - 1 else ""
                dr.text(((W - lw) / 2, y + li * 72), line + suffix,
                        font=fnt, fill=(40, 40, 40))
            proc.stdin.write(frame.tobytes())
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()
    if not os.path.exists(out_path):
        raise RuntimeError("typewriter render failed")


# ---------------------------------------------------------------------------
# Auto stage selection: concrete -> stock, abstract -> icons, statements -> kinetic
# ---------------------------------------------------------------------------

CONCRETE = {
    # law/legal
    "law": "law", "legal": "law", "court": "law", "lawyer": "law",
    "justice": "law", "gavel": "law", "contract": "law",
    # medical
    "hospital": "hospital", "doctor": "hospital", "medical": "hospital",
    "surgery": "hospital", "patient": "hospital", "clinic": "hospital",
    # industrial
    "factory": "factory", "manufacturing": "factory", "industry": "factory",
    "warehouse": "factory",
    # office/work
    "office": "office", "meeting": "office", "business": "office",
    "workplace": "office",
    # places
    "city": "city", "street": "city", "market": "market", "shop": "market",
    "store": "market",
    # nature/world
    "globe": "earth", "world": "earth", "global": "earth", "map": "earth",
    "ocean": "nature", "forest": "nature", "mountain": "nature",
}

# words that trigger kinetic text emphasis (get a colored bar)
EMPHASIS = {"never", "always", "every", "all", "massive", "huge", "critical",
            "important", "key", "secret", "truth", "lie", "kill", "dead",
            "danger", "warning", "stop", "now", "today"}

STOPWORDS = set("""a an the and or but in on at to for of with by from as is are
was were be been being have has had do does did will would can could should
may might must shall it its this that these those i you he she we they them
his her their our your my me him us what when where who whom which how why
not no yes so if then than too very just about into over after before between
during while".split()""")


def extract_keywords(text, max_kw=3):
    """Top content keywords from a segment (frequency-weighted, no stopwords)."""
    import re
    from collections import Counter
    words = re.findall(r"[a-zA-Z]{4,}", text.lower())
    words = [w for w in words if w not in STOPWORDS]
    return [w for w, _ in Counter(words).most_common(max_kw)]


def plan_stages(words, max_seg_words=14):
    """Split transcribed words into segments; pick a stage per segment.

    Returns list of dicts: {kind, text, start, end, keywords}.
    kind: 'icons' | 'kinetic' | 'stock' | 'typewriter'
    """
    # group words into sentence-ish segments
    segments, cur = [], []
    for w in words:
        cur.append(w)
        txt = w["word"]
        if (txt.rstrip().endswith((".", "!", "?")) or len(cur) >= max_seg_words):
            segments.append(cur)
            cur = []
    if cur:
        segments.append(cur)

    plan = []
    for seg in segments:
        text = "".join(w["word"] for w in seg).strip()
        if not text:
            continue
        start, end = seg[0]["start"], seg[-1]["end"]
        kws = extract_keywords(text)
        low = text.lower()

        # 1. concrete -> stock footage
        stock_kw = None
        for kw in kws:
            if kw in CONCRETE:
                stock_kw = CONCRETE[kw]
                break
        if stock_kw:
            plan.append({"kind": "stock", "text": text, "start": start,
                         "end": end, "keywords": kws, "stock_kw": stock_kw})
            continue
        # 2. short punchy statement with emphasis -> kinetic
        if len(kws) <= 8 and any(e in low for e in EMPHASIS):
            plan.append({"kind": "kinetic", "text": text, "start": start,
                         "end": end, "keywords": kws})
            continue
        # 3. default: icons (abstract concepts get 3D icons)
        plan.append({"kind": "icons", "text": text, "start": start,
                     "end": end, "keywords": kws})
    return plan


def build_smart_explainer(audio_path, out_path, progress=None,
                          width=1280, height=720, fps=30):
    """Full auto pipeline: audio -> transcribe -> plan -> render -> mux audio.

    progress: optional callable(step_text, fraction).
    """
    import tempfile
    from pipeline import transcribe as _transcribe
    import icon_lib

    def _pg(txt, frac):
        if progress:
            try:
                progress(txt, frac)
            except Exception:
                pass

    _pg("Transcribing audio…", 0.05)
    tr = _transcribe(audio_path)
    words = tr["words"]
    if not words:
        raise RuntimeError("No speech detected in audio")
    total_dur = tr["duration"]

    _pg("Planning stages…", 0.15)
    plan = plan_stages(words)

    tmpdir = tempfile.mkdtemp(prefix="smartexp_")
    clips = []
    bg_idx = 0
    n = len(plan)
    for i, seg in enumerate(plan):
        dur = max(1.5, seg["end"] - seg["start"] + 0.4)
        cp = os.path.join(tmpdir, f"seg{i:03d}.mp4")
        _pg(f"Rendering {i+1}/{n}: {seg['kind']}…", 0.15 + 0.65 * i / max(1, n))
        try:
            if seg["kind"] == "icons":
                ipaths, labels = [], []
                for kw in seg["keywords"][:3]:
                    p = icon_lib.get_icon(kw)
                    if p:
                        ipaths.append(p)
                        labels.append(kw)
                if not ipaths:
                    # fallback: kinetic text
                    words_l = seg["text"].split()
                    hl = {w.lower().strip(".,!?") for w in words_l
                          if w.lower().strip(".,!?") in EMPHASIS}
                    kinetic_clip(words_l, hl, cp, duration=dur,
                                 bg_idx=bg_idx, width=width, height=height)
                    bg_idx += 1
                else:
                    icon_canvas_clip(ipaths, labels, cp, duration=dur,
                                     width=width, height=height)
            elif seg["kind"] == "kinetic":
                words_l = seg["text"].split()
                hl = {w.lower().strip(".,!?") for w in words_l
                      if w.lower().strip(".,!?") in EMPHASIS}
                kinetic_clip(words_l, hl, cp, duration=dur,
                             bg_idx=bg_idx, width=width, height=height)
                bg_idx += 1
            elif seg["kind"] == "stock":
                # fetch a pixabay video for the concrete keyword
                vp = _fetch_stock_video(seg.get("stock_kw") or seg["keywords"][0],
                                        tmpdir)
                if vp:
                    stock_card_clip(vp, cp, duration=dur,
                                    width=width, height=height)
                else:
                    typewriter_clip(seg["text"], cp, duration=dur,
                                    width=width, height=height)
            else:
                typewriter_clip(seg["text"], cp, duration=dur,
                                width=width, height=height)
            clips.append(cp)
        except Exception as e:
            # never let one segment kill the video: typewriter fallback
            try:
                typewriter_clip(seg["text"][:120], cp, duration=dur,
                                width=width, height=height)
                clips.append(cp)
            except Exception:
                pass

    if not clips:
        raise RuntimeError("Smart Explainer render produced no clips")

    _pg("Assembling video…", 0.85)
    lst = os.path.join(tmpdir, "list.txt")
    with open(lst, "w") as f:
        for c in clips:
            f.write(f"file '{c}'\n")
    silent = os.path.join(tmpdir, "silent.mp4")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0",
                    "-i", lst, "-c", "copy", silent], check=True)
    # mux narration audio
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", silent,
                    "-i", audio_path, "-c:v", "copy", "-c:a", "aac",
                    "-shortest", out_path], check=True)
    _pg("Done!", 1.0)
    return out_path


def _fetch_stock_video(keyword, tmpdir):
    """Fetch one Pixabay video for a keyword. Returns path or None."""
    try:
        from pixabay import search_videos
        from pipeline import DATA as _DATA
        import json
        kf = os.path.join(_DATA, "api_keys.json")
        key = ""
        if os.path.exists(kf):
            try:
                key = json.load(open(kf)).get("pixabay", "")
            except Exception:
                key = ""
        if not key:
            return None
        vids = search_videos(key, keyword, per_page=3)
        if not vids:
            return None
        url = vids[0].get("url") or vids[0].get("preview_url")
        if not url:
            return None
        out = os.path.join(tmpdir, f"stock_{keyword}.mp4")
        import urllib.request
        req = urllib.request.Request(url, headers={"User-Agent": "AzCut/2.18"})
        with urllib.request.urlopen(req, timeout=60) as r, open(out, "wb") as f:
            f.write(r.read())
        return out if os.path.getsize(out) > 10000 else None
    except Exception:
        return None
