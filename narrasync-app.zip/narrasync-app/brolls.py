"""v2.20 B-Rolls Collector — script -> scenes -> stock footage library.

Paste a narration script, get an organized visual library: each scene gets
its own set of stock video options (Pixabay/Pexels) to preview and collect.
"""
import re

from broll import pick_important_words

# stopwords for cleaner search queries
_STOP = set("""
a an the and or but of to in on at for with as by from is are was were be been
it its this that these those he she they we you i my our their his her your
will would can could should shall may might must do does did done have has had
not no yes so very just about into over after before between through during
each other more most such only own same than too when where who whom whose
what which how why there here then now today
""".split())


def split_scenes(script, max_scenes=12):
    """Split a narration script into scenes (1-3 sentences each).

    Returns [{"text": str, "keywords": [...], "query": str}].
    """
    script = (script or "").strip()
    if not script:
        return []
    # split into sentences
    sents = [s.strip() for s in re.split(r"(?<=[.!?…])\s+", script) if s.strip()]
    if not sents:
        return []
    # group 2 sentences per scene (1 if very long)
    scenes, cur = [], []
    for s in sents:
        cur.append(s)
        words = sum(len(x.split()) for x in cur)
        if len(cur) >= 2 or words >= 40:
            scenes.append(" ".join(cur))
            cur = []
        if len(scenes) >= max_scenes:
            break
    if cur and len(scenes) < max_scenes:
        scenes.append(" ".join(cur))
    out = []
    for text in scenes:
        kws = pick_important_words(text, max_words=4)
        # build a clean search query from keywords (drop stopwords)
        qwords = [w for w in kws if w.lower() not in _STOP][:3]
        if not qwords:
            words = [w for w in re.findall(r"[A-Za-z']+", text) if w.lower() not in _STOP]
            qwords = words[:3]
        out.append({
            "text": text,
            "keywords": kws,
            "query": " ".join(qwords) or "cinematic b-roll",
        })
    return out


def collect_footage(scenes, pixabay_key="", pexels_key="", per_scene=4,
                    progress=None):
    """Search stock footage for each scene.

    Returns scenes with "clips": [{"url","preview","duration","source"}].
    Pixabay first, Pexels as fallback per scene.
    """
    import pixabay as _px
    try:
        import pexels as _pe
    except Exception:
        _pe = None

    for i, sc in enumerate(scenes):
        if progress:
            progress(i + 1, len(scenes))
        clips = []
        q = sc["query"]
        # Pixabay videos
        if pixabay_key:
            try:
                r = _px.search_videos(pixabay_key, q, per_page=per_scene)
                for it in r.get("items", [])[:per_scene]:
                    clips.append({
                        "url": it["url"],
                        "preview": it.get("preview", ""),
                        "duration": it.get("duration", 0),
                        "source": "pixabay",
                    })
            except Exception:
                pass
        # Pexels fallback if Pixabay gave nothing
        if not clips and pexels_key and _pe is not None:
            try:
                r = _pe.search(pexels_key, q, kind="video", per_page=per_scene)
                for it in (r.get("items") or [])[:per_scene]:
                    if not it.get("url"):
                        continue
                    clips.append({
                        "url": it["url"],
                        "preview": it.get("thumb") or "",
                        "duration": 0,
                        "source": "pexels",
                    })
            except Exception:
                pass
        sc["clips"] = clips
    return scenes
