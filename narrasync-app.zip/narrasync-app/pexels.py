"""Pexels stock photos/videos for Az Cut (Scriblume-style Doodle+Stock).

Free API key from https://www.pexels.com/api/ (200 req/hour, 20k/month).
Stdlib only — no new dependency, PyInstaller-safe.
"""

import json
import urllib.error
import urllib.parse
import urllib.request

API_BASE = "https://api.pexels.com"
ALLOWED_HOSTS = ("pexels.com", "vimeo.com", "vimeocdn.com", "akamaized.net")


class PexelsError(Exception):
    pass


def _get(api_key, path, params):
    if not api_key:
        raise PexelsError(
            "Please paste your Pexels API key first. "
            "Get a free one at pexels.com/api/.")
    qs = urllib.parse.urlencode(params)
    req = urllib.request.Request(
        f"{API_BASE}{path}?{qs}",
        headers={"Authorization": api_key, "User-Agent": "AzCut"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise PexelsError(
                "Pexels rejected the API key (401/403) — check the key.")
        if e.code == 429:
            raise PexelsError(
                "Pexels rate limit hit — wait a minute and retry.")
        raise PexelsError(f"Pexels API error ({e.code}).")
    except PexelsError:
        raise
    except Exception as e:  # noqa: BLE001
        raise PexelsError(f"Could not reach Pexels: {e}")


def _best_video_file(files):
    """Pick a sensible mp4: smallest HD, else SD, else anything."""
    mp4s = [f for f in (files or [])
            if f.get("file_type") == "video/mp4" and f.get("link")]
    if not mp4s:
        return None
    for q in ("hd", "sd", "uhd"):
        cands = [f for f in mp4s if f.get("quality") == q]
        if cands:
            cands.sort(key=lambda f: f.get("width") or 0)
            return cands[0]
    return sorted(mp4s, key=lambda f: f.get("width") or 0)[0]


def search(api_key, query, kind="photo", page=1, per_page=12):
    """Search Pexels. Returns {items, total}; each item has
    id/kind/thumb/url/w/h/photographer."""
    query = (query or "").strip()
    if not query:
        raise PexelsError("Please type something to search for.")
    per_page = max(1, min(30, int(per_page or 12)))
    page = max(1, int(page or 1))
    if kind == "video":
        data = _get(api_key, "/videos/search",
                    {"query": query, "per_page": per_page, "page": page})
        items = []
        for v in data.get("videos", []) or []:
            f = _best_video_file(v.get("video_files"))
            if not f:
                continue
            items.append({
                "id": v.get("id"), "kind": "video",
                "thumb": v.get("image"), "url": f["link"],
                "w": f.get("width"), "h": f.get("height"),
                "photographer": (v.get("user") or {}).get("name", ""),
            })
        return {"items": items, "total": data.get("total_results", 0)}
    data = _get(api_key, "/v1/search",
                {"query": query, "per_page": per_page, "page": page})
    items = []
    for p in data.get("photos", []) or []:
        src = p.get("src") or {}
        if not src.get("large"):
            continue
        items.append({
            "id": p.get("id"), "kind": "photo",
            "thumb": src.get("medium"), "url": src.get("large"),
            "w": p.get("width"), "h": p.get("height"),
            "photographer": p.get("photographer", ""),
        })
    return {"items": items, "total": data.get("total_results", 0)}


def download(url, out_path, timeout=300):
    """Download a Pexels CDN file (streamed). Host-allowlisted."""
    host = (urllib.parse.urlparse(url).hostname or "").lower()
    if not any(host == h or host.endswith("." + h) for h in ALLOWED_HOSTS):
        raise PexelsError("That download host is not allowed.")
    req = urllib.request.Request(url, headers={"User-Agent": "AzCut"})
    with urllib.request.urlopen(req, timeout=timeout) as r, \
            open(out_path, "wb") as f:
        while True:
            chunk = r.read(1024 * 256)
            if not chunk:
                break
            f.write(chunk)
    return out_path
