=============================================================
AZ CUT — GITHUB SE SETUP.EXE BANANE KA TAREEQA (ROMAN URDU)
=============================================================
Aapka kaam: ~10 minute | GitHub ka automatic kaam: ~30-45 minute

Is zip mein 3 files hain:
  1. narrasync-app.zip  -> aapka poora Az Cut v2.0 software (Rank Cut naya!)
  2. build.yml          -> GitHub ko batata hai Setup.exe kaise banana hai
  3. README-URDU.txt    -> ye hidayat (jo aap parh rahe hain)

-------------------------------------------------------------
STEP 1: GitHub repo kholein
-------------------------------------------------------------
1. Browser (Chrome) mein jayein:  github.com/abrarfriend0/Azcut
2. Agar login maange to login karein.

-------------------------------------------------------------
STEP 2: narrasync-app.zip upload karein
-------------------------------------------------------------
1. Repo page par oopar "Add file" ka button hai, usay dabayein.
2. "Upload files" par click karein.
3. Apne PC se "narrasync-app.zip" file ko drag karke
   browser wali jagah par chhorein.
4. Neeche green "Commit changes" button dabayein.
   (2-3 second mein upload ho jayegi, file chhoti hai)

-------------------------------------------------------------
STEP 3: build.yml UPDATE karein (zaroori!)
-------------------------------------------------------------
Is version mein build.yml BADAL GAYA hai (nayi cheezon ke liye),
is liye purani wali ko nayi wali se replace karna LAZMI hai:

1. Repo mein jayein:  .github/workflows/build.yml  file kholein
   (repo page par folders mein click karte jayein:
    .github > workflows > build.yml).
2. Oopar pencil wala icon (Edit) dabayein.
3. Purana saara text select karke DELETE kar dein.
4. Apne PC par is zip wali "build.yml" file ko Notepad mein kholein.
5. Ctrl+A (select), Ctrl+C (copy), phir GitHub wale khaali box
   mein Ctrl+V (paste) karein.
6. Neeche green "Commit changes" button dabayein.

(Agar build.yml update na kiya to naya Rank Cut kaam nahi karega!)

-------------------------------------------------------------
STEP 4: Build chalaye (Setup.exe banana shuru)
-------------------------------------------------------------
1. Repo page par oopar wale menu mein "Actions" tab dabayein.
2. Left side mein "Build AzCut Setup.exe" nazar ayega,
   us par click karein.
3. Right side mein "Run workflow" ka button ayega,
   usay dabayein, phir dobara "Run workflow" dabayein.
4. Bas! Ab GitHub ke computer par kaam shuru ho gaya.
   ~30-45 minute lageinge. Beech mein page refresh karke
   progress dekh sakte hain (peela = chal raha, sabz = ho gaya).
   Kaam khatam hone par aapko email bhi aa jayega.

-------------------------------------------------------------
STEP 5: Setup.exe download aur install karein
-------------------------------------------------------------
1. Repo page ki RIGHT side mein "Releases" likha hoga, usay dabayein.
2. "Az Cut v2.0" release khulegi.
3. "AzCut-Setup-2.0.exe" download karein (~400-500 MB, thoda time lagega).
4. Download hone ke baad file par double-click > Install.
5. Desktop par "Az Cut" ka icon ban jayega. Kholein aur maza karein!

-------------------------------------------------------------
ZAROORI NOTE (agli baar ke liye)
-------------------------------------------------------------
Jab bhi main aapko software ka naya version dun:
  - Sirf naya "narrasync-app.zip" repo mein upload karein
    (purani file khud replace ho jayegi).
  - Phir Actions > "Build AzCut Setup.exe" > "Run workflow".
  - Nayi Release khud ban jayegi, aur Az Cut ka auto-updater
    aapke doston ke PC par khud update de dega!

Agar kahin atak jayein to us page ka SCREENSHOT bhej dein,
main bata dunga agla click kahan karna hai.
=============================================================
